# Thực thi và đối chiếu FullText — 04/11/2026

**Bản nền đã đối chiếu.** Sau báo cáo này, người dùng chấp thuận phần mở rộng luồng chuyến đi ngày 05/11. Lược đồ hiện hành có thêm một cột tùy chọn, một FK và một query index; toàn bộ cột/ràng buộc/API nền được giữ. Xem [thiết kế mở rộng và kiểm chứng hiện hành](LUONG_CHUYEN_DI_2026-11-05.md). Tiếp đó, phần lưu/so sánh, chuẩn bị, thực chi và metadata/ảnh dịch vụ được triển khai; hồ sơ hiện hành là [MO_RONG_SAN_PHAM_2026-11-05.md](MO_RONG_SAN_PHAM_2026-11-05.md), 28 bảng/302 cột. Các số lượng và kết quả phía dưới thuộc bản nền ngày 04/11.

Bản web đã được cập nhật theo hợp đồng dữ liệu, action và vòng đời nghiệp vụ ở Chương 4 của **26271.3-FullText-XayDungHeThongHoTroKhachDuLichTuTuc (4).docx**, đồng thời làm mới giao diện bằng ui-ux-pro-max. Database chính đã được nâng cấp có sao lưu, kiểm tra trước/sau và chạy lại website tại `http://localhost:5216`.

Báo cáo [DOI_CHIEU_THIET_KE_2026-11-04.md](DOI_CHIEU_THIET_KE_2026-11-04.md) mô tả tình trạng **trước khi sửa**. Kết quả dưới đây thay thế phần kết luận hiện trạng của báo cáo cũ; không dùng số kiểm thử cũ để xác nhận phiên bản mới.

## Dữ liệu và API

| Thiết kế | Hiện thực và bằng chứng |
| --- | --- |
| 25 bảng, 267 cột | `Domain/Entities.cs`, `Data/Configurations/`, `Database/schema.sql`; đã đối chiếu kiểu SQL, NULL, identity, DEFAULT và khóa chính trên database chính |
| 38 FK, NO ACTION | Navigation hai phía và cấu hình FK có tên; kiểm tra cả bảng/cột đích, cập nhật/xóa NO ACTION, trạng thái enabled/trusted |
| 117 CHECK | Kiểm tra định nghĩa vật lý bằng SQL Server chuẩn hóa trên bảng tạm; 41 CHECK liên thuộc tính được trích độc lập từ Bảng 4.161 để so sánh với script và database |
| 18 unique index | Trích định nghĩa từ Bảng 4.162; kiểm tra cột khóa và điều kiện lọc |
| 34 index truy vấn | Đối chiếu Bảng 4.163, gồm thứ tự cột, ASC/DESC, INCLUDE và bộ lọc |
| 4 view và 49 DEFAULT | Đối chiếu SELECT của view, tên/biểu thức DEFAULT và các cột liên quan |
| Cấu hình SQL | Vietnamese_100_CI_AS_SC; RCSI ON; snapshot isolation OFF; FULL; CHECKSUM; AUTO_CLOSE OFF |
| 43 Controller, 91 action | `Controllers/FullText/`, tên/GET–POST/route/policy theo Bảng 4.86; dữ liệu chuẩn trong `fulltext-contract.json` |
| 43 ViewModel đầu vào | `Models/FullTextViewModels.cs`; trường tiếng Việt được tiếp nhận qua bộ ánh xạ tên, Data Annotations và kiểm tra nghiệp vụ |
| 19 component, 11 giao diện liên component | Interface/Service Scoped, cùng DbContext trong một request; các phương thức Service đối chiếu Bảng 4.88; có 24 enum miền |
| Giao dịch và đồng thời | Serializable, retry tối đa ba lần cho 1205/-2, RowVersion và số phiên bản nghiệp vụ; ràng buộc duy nhất là hàng rào cuối cho gửi đồng thời |

SQL là nguồn chuẩn. Khởi tạo database rỗng đọc `schema.sql`; database đang có dữ liệu nâng cấp bằng `001_CanChinh_FullText.sql`, không để EF tự sinh lại lược đồ.

## Những sai khác nghiệp vụ của bản audit đã xử lý

| Mã audit | Thay đổi đã thực hiện |
| --- | --- |
| F01, F05 | Thỏa thuận có phiên bản cơ sở MAX; thay bản chờ trong cùng giao dịch; xác nhận đúng phiên bản; rút một bên hủy đề nghị chờ; thỏa thuận kết thúc chặn đề xuất mới |
| F02 | Sửa thông tin/hoạt động, xóa và sắp xếp hoạt động đưa kế hoạch về nháp; xác nhận lịch trình là bước riêng |
| F03, F04 | Chặn ngày tạo trong quá khứ; bỏ nhu cầu hết hạn; chỉ thay đổi/hủy dịch vụ trước ngày bắt đầu khi chưa có kết quả và không có đề nghị chờ |
| F06, F07 | Có lưu nháp/gửi đăng, kiểm tra lịch tạm ngừng và lý do; không cho tự bật nhận yêu cầu ngoài luồng duyệt/quyền hoạt động |
| F08 | Đề xuất đặt dịch vụ và điều chỉnh cập nhật ngày, quy mô, chi phí/điều kiện có cấu trúc; giữ bằng chứng điều kiện cũ và xác nhận đúng phiên bản |
| F09 | Kết quả theo hạng mục chính cùng các lựa chọn bổ sung; kiểm tra đủ hạng mục chưa chốt, trạng thái tổng hợp, phản ánh và đối chiếu có lịch sử |
| F10 | Đăng ký NCC đủ thông tin cơ sở/người liên hệ/người đại diện/tệp; đăng nhập email hoặc số điện thoại, băm giả khi không thấy tài khoản, đổi mật khẩu Admin mới |
| F11 | Mặc định chia sẻ hạn chế; chiếu đúng trường trước/sau kết nối; tên hiển thị công khai, email/số điện thoại chỉ sau chấp nhận kết nối |
| F12 | Ngừng tài khoản có xác thực lại, nghĩa vụ kèm liên kết, xem hệ quả, token 5 phút gắn tài khoản/dấu phiên; kiểm tra lại trong giao dịch cuối |
| F13 | Có xem trước nhu cầu/đặt dịch vụ/quyền hoạt động; lỗi 400/422 giữ dữ liệu và thông báo kiểm tra; 409 yêu cầu tải lại phiên bản mới |
| F14 | Tình huống gắn nhiều hoạt động, loại cố định, phương án tùy chọn và kết quả thực tế; giữ lịch sử phương án |
| F15 | Xem dịch vụ/yêu cầu/phản ánh liên quan trước quyết định; đình chỉ/thu hồi/khôi phục đúng nguyên nhân, giải trình cho quyết định hiện hành, xác minh lại và duyệt lại dịch vụ |

Các bổ sung kỹ thuật liên quan T01–T12: tách Service/contracts, enum/navigation/cấu hình riêng, danh mục 98 mã lỗi, vùng lưu tệp riêng và xóa bù, hồ sơ có ảnh đại diện, phân trang route chuẩn 20 dòng, khóa sắp xếp phụ cho bản ghi trùng thời điểm, khu vực động, thông báo theo loại và huy hiệu chưa đọc.

Nhật ký theo Bảng 4.40 gồm đăng nhập thành công/thất bại, đăng xuất, đăng ký, duyệt dịch vụ, xác minh, đổi quyền, từ chối quyền, CSRF/tần suất, ngừng tài khoản, đề xuất điều kiện và lỗi hệ thống. Nhật ký quyết định đi cùng transaction; sự kiện thất bại/quyền/CSRF dùng ngữ cảnh riêng. Định danh thất bại được che, không ghi mật khẩu/cookie/nội dung tệp.

## Giao diện và thao tác

Trang chủ dùng bố cục hai cột ở desktop, ảnh du lịch lớn, nền kem/xanh rừng/cam đất và điểm nhấn serif. Tìm kiếm, loại hình và ba lối vào khám phá–kế hoạch–đồng hành rõ ràng. Trên điện thoại, menu và biểu mẫu thu gọn, danh sách đặt dịch vụ dùng thẻ có nhãn, nút/ô nhập đủ lớn và có focus bàn phím.

Biểu mẫu đăng nhập nhận được số điện thoại ngay trong trình duyệt. Bộ lọc đồng hành gửi đúng action, giữ các giá trị sau tìm kiếm. Các nút ghi của khách được ẩn khi NCC/Admin xem nội dung công khai. Thông báo mở bằng POST rồi chuyển tới đối tượng. Thay đổi/hủy dịch vụ chỉ hiện thao tác hợp lệ của đúng bên ở đúng trạng thái.

Ảnh bằng chứng: `preview/fulltext-home-desktop.jpg`, `fulltext-home-mobile.jpg`, `fulltext-plans-mobile.jpg`, `fulltext-plan-form-mobile.jpg` cùng các ảnh QA cuối trong thư mục preview. Các màn hình đã được quan sát ở 375 px, 812 px ngang và desktop; kiểm tra này không thay thế đánh giá khả năng tiếp cận đầy đủ với người dùng thực.

## Kết quả kiểm chứng

| Bộ | Đạt | Giới hạn của bằng chứng |
| --- | ---: | --- |
| C# / EF / API contract | 1697 | Kiểu/thuộc tính/enum, route/verb/policy/VM, tên phương thức; không chứng minh mọi đường đi bên trong từng hàm |
| SQL vật lý chính | 1472 | Schema/config, định nghĩa CHECK/index/FK/view/default; không phải kiểm thử tải |
| HTTP nghiệp vụ | 169 | Ca thành công/lỗi qua các vai trò, kiểm tra SQL sau ghi; có gửi đồng thời và phiên bản cũ |
| Ma trận 91 action × 4 nhóm | 364 | Chặn vai trò, CSRF; POST được chặn trước ghi, route xác thực có thể trả 429 |
| Trang chức năng | 41 | Trang đọc theo vai trò và các lỗi truy cập cụ thể |
| Luồng biểu mẫu | 35 | Nút theo vai trò, đăng nhập, bộ lọc, kế hoạch, thông báo |
| Bảo mật/nhật ký | 23 | Nhật ký độc lập, che thông tin, headers, tần suất và đăng xuất |

Build cuối không có lỗi hoặc cảnh báo. Kết quả JSON nằm trong `tests/`; hướng dẫn chạy lại tại [tests/README.md](../tests/README.md). Các ca ghi nghiệp vụ chỉ chạy trên database FullText riêng ở cổng 5219.

Database chính đã sao lưu trước nâng cấp; bản nâng cấp thử trên database phục hồi riêng trước khi áp dụng. Sau ALTER, cả 25 bảng giữ nguyên số dòng. Full backup/log backup sau hoàn thiện đã được thử phục hồi sang `HoTroDuLich_FullTextRestore_20261104`, database ONLINE, CHECKDB đạt và 25 bảng khớp số dòng tại thời điểm đối chiếu. Bằng chứng: `tests/fulltext-restore-results.json`, `preview/backups/fulltext-restore-final-verification.txt`.

## Các quyết định khi tài liệu có mâu thuẫn hoặc ký hiệu khái quát

- **Quyền công khai/hồ sơ Admin:** theo policy action của Chương 4. NCC/Admin đọc nội dung công khai; hồ sơ cá nhân cho mọi tài khoản đã xác thực; Admin không tự ngừng tài khoản qua SUC14.01.
- **Kiểu dữ liệu ở Bảng 4.87:** mật khẩu và mã xác nhận được xử lý như chuỗi; số điện thoại giữ dạng chuỗi để không mất số 0. Các ô ghi `long/int` nhưng mô tả độ dài/định dạng chuỗi được hiểu theo ý nghĩa dữ liệu và các bảng vật lý.
- **CONTROL trong phần quyền SQL:** không cấp CONTROL; dùng các DENY cụ thể. Thử nghiệm cho thấy DENY CONTROL rộng phủ luôn SELECT/INSERT (và CONNECT ở mức database), làm các GRANT ứng dụng mất tác dụng. Vai trò tối thiểu đã kiểm tra SELECT/INSERT được, DELETE tài khoản và UPDATE nhật ký bị chặn, DELETE hoạt động được phép, CONTROL không có.
- **Ảnh chụp điều kiện dài trong nhật ký:** giữ nguyên cột 200/200/500 như FullText. Dữ liệu dài được chia thành các mảnh đánh số trong cùng giao dịch, giữ đủ nội dung để đối chiếu, không cắt bỏ hoặc tự nới cột.
- **Tổ chức mã:** giữ `Controllers/FullText`, `Services/Components`, `Services/Contracts`, `Domain`, `Views` trong cấu trúc dự án hiện có. Các URL cũ dùng lớp facade tương thích. Thông điệp truy vấn/chuyển trạng thái trong UML được hiện thực ở Service sở hữu dữ liệu và 11 giao diện liên component; entity EF chứa thuộc tính/navigation.
- **Mô hình trình bày/kiểm thử:** 43 ViewModel đầu vào dùng chung các lớp input đã kiểm tra; một số Razor dùng entity đã được giới hạn dữ liệu cùng ViewBag cho phần hiển thị. Bộ kiểm thử hiện hành dùng HTTP + SQL Server thật + chương trình kiểm chứng C#, chưa chuyển sang xUnit/WebApplicationFactory. Đây là các thích nghi kỹ thuật cần biết khi so sánh nguyên văn sơ đồ lớp và cấu trúc thư mục.

## Phạm vi vận hành đã xác minh

Đã xác minh bản Development trên localhost và LocalDB, các backup thực tế, cùng quy trình phục hồi tách biệt. Cấu hình/script Production đã chuẩn bị; chưa triển khai lên Internet hoặc cài Windows Service/Task Scheduler/TLS/tài khoản SQL trên máy Production. Các bước này và lịch sao lưu/kiểm tra phục hồi được ghi trong [VAN_HANH.md](VAN_HANH.md).

Kết quả trên xác nhận những hợp đồng và ca đã đối chiếu, không phải tuyên bố phần mềm đã được chứng nhận đúng tuyệt đối mọi tổ hợp nghiệp vụ trong tài liệu.
