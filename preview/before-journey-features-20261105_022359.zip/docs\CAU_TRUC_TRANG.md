# Điều hướng và các trang chức năng

Hợp đồng đủ 91 action nằm trong [fulltext-contract.json](fulltext-contract.json), trích từ Bảng 4.86. Các route chuẩn dưới đây dùng chung nghiệp vụ với những URL giao diện tương thích như `/Plans`, `/Bookings`, `/Provider`, `/Admin`.

| Khu vực | Trang chính | Chi tiết và bước tiếp theo |
| --- | --- | --- |
| Khám phá | `/` hoặc `/thong-tin/mo-tim-kiem` | `/thong-tin/tra-cuu`, `/thong-tin/xem-chi-tiet?loai=DiaDiem&maMuc=1` |
| Lựa chọn đã lưu | `/Saved` trong nhóm Khám phá | Chọn 2–3 dịch vụ → `/Saved/Compare` → chi tiết hoặc chọn chuyến đi |
| Chuẩn bị chuyến đi | `/Preparation?planId={id}` từ từng chuyến | Thêm bộ gợi ý, việc riêng, hạn/nhắc, đánh dấu xong/mở lại |
| Chi tiêu thực tế | `/Expenses?planId={id}` từ từng chuyến | Ghi/sửa/xóa khoản đã trả, tổng theo ngày/loại, ngân sách còn lại |
| Đồng hành công khai | `/dong-hanh/tim-kiem/mo-tim-kiem` | Bộ lọc gửi `/dong-hanh/tim-kiem/tim-nhu-cau`; chi tiết `/dong-hanh/tim-kiem/xem-chi-tiet/{maNhuCau}` |
| Kế hoạch cá nhân | `/ke-hoach` | `/ke-hoach/{maKeHoach}`, `/ke-hoach/mo-ke-hoach-moi`; xác nhận là thao tác riêng sau khi xem lịch trình |
| Nhu cầu cá nhân | `/Companions/Mine` | `/dong-hanh/nhu-cau/mo-bieu-mau` → xem trước → công bố |
| Kết nối | `/dong-hanh/de-nghi` | Chi tiết đề nghị, thông tin sau kết nối và các phiên bản thỏa thuận |
| Tình huống | `/ke-hoach/{maKeHoach}/tinh-huong` | Tạo mới, chọn phương án, ghi kết quả và lịch sử |
| Dịch vụ của NCC | `/nha-cung-cap/dich-vu` | Chi tiết dịch vụ, lưu nháp/gửi đăng, bản cập nhật và lịch sử duyệt |
| Đặt dịch vụ | `/yeu-cau/cua-toi` hoặc `/nha-cung-cap/yeu-cau` | Xem trước yêu cầu, chi tiết, phản hồi có cấu trúc, xác nhận điều kiện |
| Thay đổi/hủy | `/Bookings/Adjustments` | `/Bookings/Changes/{id}`; một đề nghị đang chờ và các nút theo đúng trạng thái/bên tham gia |
| Kết quả | `/Bookings/Results` | `/Bookings/Outcome/{id}`; hạng mục chưa chốt, phản ánh và đối chiếu |
| Xác minh NCC | `/nha-cung-cap/ho-so-xac-minh` | Bổ sung/nộp lại theo trạng thái, lịch sử tài liệu và quyết định |
| Quyền của NCC | `/nha-cung-cap/quyen-hoat-dong` | Quyết định hiện hành, lịch sử và giải trình |
| Admin xét duyệt | `/quan-tri/xet-duyet-dich-vu/mo-danh-sach-cho-duyet` | So sánh bản đang công bố và bản gửi, quyết định đúng phiên bản |
| Admin xác minh | `/quan-tri/xac-minh/mo-danh-sach` | Hồ sơ, tệp, lịch sử và quyết định xác minh |
| Admin quyền hoạt động | `/quan-tri/quyen-hoat-dong/mo-danh-sach` | Dịch vụ/yêu cầu/phản ánh liên quan → xem hệ quả → quyết định |
| Hồ sơ | `/ho-so/xem-ho-so` | Thông tin chỉ đọc, thông tin được sửa, ảnh và phạm vi chia sẻ |
| Thông báo | `/thong-bao` | Nút mở gửi POST `/thong-bao/{maThongBao}/mo`, đánh dấu đã đọc rồi tới đối tượng |
| Ngừng tài khoản | `/tai-khoan/ngung-su-dung/mo-ngung` | Xác thực lại → danh sách nghĩa vụ hoặc hệ quả → xác nhận cuối |

Các danh sách route chuẩn nhận `trang`, mặc định 20 bản ghi. Các biểu mẫu giữ dữ liệu khi lỗi 400/422; xung đột 409 yêu cầu tải lại phiên bản mới. Nút thao tác được hiển thị theo vai trò và trạng thái; Service vẫn kiểm tra lại khi ghi.

Menu hiện hành gom theo nhóm **Khám phá**, **Chuyến đi**, **Đồng hành**. Trong Chuyến đi có lịch trình, đặt dịch vụ và hỗ trợ; trong Đồng hành có tìm người, bài đăng và kết nối. Danh sách đặt dịch vụ có ba tab yêu cầu, thay đổi/hủy và kết quả. Chi tiết từng yêu cầu tiếp tục có tab theo cùng đối tượng.

Trang `/Plans/Detail/{id}` và `/ke-hoach/{maKeHoach}` là trung tâm từng chuyến đi: tổng quan, lịch trình, dịch vụ đã gắn, ngân sách và hỗ trợ, cùng lối tắt chuẩn bị/thực chi. Các phần dùng liên kết tới vùng trên cùng trang. Chọn trải nghiệm từ chuyến đi giữ `planId` qua tra cứu/chi tiết/đặt dịch vụ. Thiết kế mở rộng được ghi tại [LUONG_CHUYEN_DI_2026-11-05.md](LUONG_CHUYEN_DI_2026-11-05.md).

Desktop dùng thanh bên thu gọn theo nhóm và vai trò; điện thoại mở cùng menu bằng nút điều hướng. Các liên kết sâu trong bảng trên vẫn giữ nguyên. Mô tả bố cục và tương tác ở [GIAO_DIEN.md](GIAO_DIEN.md).

Phần mở rộng sản phẩm có 13 điểm vào mới (MVC GET/POST và ảnh dịch vụ), giữ 91 action chuẩn FullText. Các trang cá nhân kiểm tra chủ sở hữu ở server. API, hàm và lược đồ mới được ghi tại [MO_RONG_SAN_PHAM_2026-11-05.md](MO_RONG_SAN_PHAM_2026-11-05.md).
