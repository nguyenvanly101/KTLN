# Chạy, sao lưu và nâng cấp

## Trạng thái bàn giao trên máy này

Website chính dùng `http://localhost:5216`, môi trường Development, LocalDB `HoTroDuLich`. Bản nền FullText đạt 1472 kiểm tra vật lý. Sau phần mở rộng chuyến đi được chấp thuận ngày 05/11, bản chính đạt 1479 kiểm tra (`tests/trip-main-schema-results.json`); cả 25 bảng giữ nguyên số bản ghi qua bước nâng cấp (`preview/trip-main-rows-before.json`, `preview/trip-main-rows-after.json`). Xem [thiết kế và vận hành phần mở rộng](LUONG_CHUYEN_DI_2026-11-05.md). Khởi động bằng `start.ps1` hoặc `start.ps1 -Dev` như README.

Bản hiện hành đã áp dụng 003 và cập nhật `Quyen_CSDL.sql`: 28 bảng/302 cột, đạt **1629 kiểm tra SQL vật lý** trên database chính. Đối chiếu số dòng và SHA-256 trên toàn bộ cột cũ của 25 bảng đều khớp; ba bảng mới bắt đầu rỗng. Kết quả ở `tests/product-upgrade-results.json`, thiết kế bổ sung ở [MO_RONG_SAN_PHAM_2026-11-05.md](MO_RONG_SAN_PHAM_2026-11-05.md).

Sao lưu của đợt mới: `preview/backups/HoTroDuLich_before_product_20261105_015725.bak` (COPY_ONLY/CHECKSUM, VERIFYONLY, đã phục hồi vào `HoTroDuLich_ProductUpgrade_20261105` dùng MDF/LDF riêng) và `preview/backups/App_Data_before_product_20261105_021127.zip` (21 tệp, đã kiểm số tệp trong ZIP). Không ghi dữ liệu thử vào bản chính. Cả `start.ps1` và `start.ps1 -Dev` đã khởi động được ở cổng 5216; các tiến trình do đợt kiểm thử tạo được dừng sau khi kiểm tra.

Các bản sao lưu trước cập nhật:

- `preview/backups/HoTroDuLich_before_apply_20261104_140553.bak`: COPY_ONLY, CHECKSUM, VERIFYONLY đã đạt.
- `preview/backups/App_Data_before_apply_20261104_140553.zip`: tệp tải lên và khóa trước khi nâng cấp.
- `preview/backups/HoTroDuLich_fulltext_full_20261104_140739.bak`: full backup sau nâng cấp, bắt đầu chuỗi log ở recovery FULL.

Bản full/log sau hoàn thiện: `HoTroDuLich_20261104_144310_full.bak`, `HoTroDuLich_20261104_144311_log.trn`, kèm `HoTroDuLich_20261104_144310_App_Data.zip`. Các bản SQL đã qua VERIFYONLY. Kết quả thử phục hồi tách biệt nằm ở `tests/fulltext-restore-results.json`; chỉ kết quả có `passed: true` mới xác nhận toàn bộ thử nghiệm đã hoàn thành.

## Khởi động và dừng

Chạy `D:\KLTN\start.ps1` từ PowerShell; Ctrl+C trong terminal máy chủ để dừng. Không khởi động thêm một bản cùng cổng 5216. Khi chỉ cần sử dụng, mở URL đang chạy.

Dùng `D:\KLTN\start.ps1 -Dev` để theo dõi thay đổi mã. Cách tự nhận diện và xử lý các lỗi đã gặp nằm trong [TU_XU_LY_LOI_KHOI_DONG.md](TU_XU_LY_LOI_KHOI_DONG.md).

Ở Development, website tạo schema nền khi database rỗng, rồi chạy lại được các phần mở rộng 002/003. Với database cũ cần căn chỉnh nền, script 001 vẫn là bước quản trị riêng. Production áp dụng SQL có kiểm soát trước khi chạy web; ứng dụng không dùng EnsureCreated hay EF migrations để thay thế SQL thiết kế. `start.ps1` kiểm tra LocalDB hiện có, thử start nếu Stopped và dừng với chẩn đoán nếu chưa Running; không tự xóa/tạo lại instance hoặc đổi cấu hình bảo mật Windows.

## Nâng cấp database đã có

1. Dừng mọi tiến trình web dùng database đó; sao lưu database CHECKSUM/VERIFYONLY cùng tệp và khóa ứng dụng.
2. Thử phục hồi bản sao lưu sang database khác, chạy script nâng cấp và bộ kiểm tra trên bản sao trước.
3. Từ `src/HoTroDuLich.Web/Database`, chạy bằng tài khoản triển khai:

```powershell
sqlcmd -S '(localdb)\MSSQLLocalDB' -d HoTroDuLich -E -C -b -t 120 -i 001_CanChinh_FullText.sql
sqlcmd -S '(localdb)\MSSQLLocalDB' -d HoTroDuLich -E -C -b -i 002_LienKetYeuCauChuyenDi.sql
sqlcmd -S '(localdb)\MSSQLLocalDB' -d HoTroDuLich -E -C -b -i 003_ChuanBi_ChiTieu_LuaChon.sql
sqlcmd -S '(localdb)\MSSQLLocalDB' -d HoTroDuLich -E -C -b -i Quyen_CSDL.sql
```

4. Kiểm tra `KiemTra_FullText.sql`, rồi chạy bộ `tests/fulltext-schema.cjs` với database tương ứng và `TRAVEL_PRODUCT_EXTENSION=1`. Đối chiếu dữ liệu trước/sau, tạo một full backup thường sau khi chuyển recovery FULL, rồi khởi động bản ứng dụng mới.

Script 001 có kiểm tra dữ liệu vượt độ dài/NULL và dừng thay vì cắt dữ liệu. Việc đổi collation phải chạy ngoài transaction SQL Server nên script có nhiều pha; giữ web dừng đến khi tất cả các pha hoàn tất. Nếu có lỗi giữa các pha, dùng bản sao lưu đã kiểm tra để phục hồi vào database khác trước khi quyết định chuyển lại kết nối. Không tiếp tục phục vụ trên schema nâng cấp dở.

## Sao lưu theo thiết kế 4.8.8

Công cụ `tools/SaoLuu.ps1` chạy được các khối A/B/C bằng Windows Authentication:

```powershell
.\tools\SaoLuu.ps1 -Khoi A  # full + VERIFYONLY + App_Data ZIP
.\tools\SaoLuu.ps1 -Khoi B  # transaction log + VERIFYONLY
.\tools\SaoLuu.ps1 -Khoi C  # CHECKDB
```

Có thể truyền `-Server`, `-DatabaseName`, `-BackupDirectory`. Đây là đường dẫn trên máy SQL Server; SQL Server cần quyền ghi thư mục đó. Thư mục mặc định là `D:\KLTN\preview\backups`. `-DonDep` là tùy chọn dọn bản cũ: giữ full backup làm mốc ở biên 14 ngày và mọi log sau đó, chỉ xóa các tên tệp do công cụ tạo trong đúng thư mục sao lưu; có thể xem trước bằng `-WhatIf` kết hợp `-DonDep` cho phần dọn dẹp.

Trên máy vận hành, quản trị viên cấu hình Task Scheduler: full lúc 01:00 hằng ngày, log mỗi 30 phút, CHECKDB Chủ nhật 02:00; sao lưu thư mục tải lên/khóa cùng đợt full và thử phục hồi hằng tháng. Các tác vụ hệ thống này chưa được cài trên máy Development.

Công cụ mặc định sao lưu `App_Data` của dự án. Nếu Production đặt `UploadFiles__ThuMuc` hoặc `DataProtection__ThuMucKhoa` ra ngoài, phải bổ sung các thư mục thực tế vào tác vụ sao lưu. Để có một bộ database/tệp cùng thời điểm, tạm dừng ghi hoặc dùng snapshot lưu trữ thích hợp. Khóa bảo vệ bằng DPAPI gắn với tài khoản Windows đang chạy; không giả định có thể mang nguyên khóa sang một tài khoản/máy khác.

## Phục hồi tách biệt

Dùng `RESTORE FILELISTONLY` để xác nhận tên logic. Đích thử nghiệm phải có tên database và đường dẫn MDF/LDF riêng. Phục hồi full với `NORECOVERY`, áp dụng **đủ các log theo thứ tự** với `NORECOVERY`, log cuối dùng `RECOVERY` (và `STOPAT` nếu cần thời điểm cụ thể). Sau đó CHECKDB và kiểm tra dữ liệu/ứng dụng trước khi đổi kết nối.

Khối D trong `SaoLuu_PhucHoi.sql` là mẫu full + một log. Khi khoảng phục hồi gồm nhiều log, phải thêm toàn bộ chuỗi; không bỏ qua các tệp ở giữa. Không dùng `WITH REPLACE` lên database chính trong quy trình thử.

## Production

`appsettings.Production.json` tắt demo và để trống bí mật. Cung cấp từ môi trường: `ConnectionStrings__HoTroDuLich`, `QuanTriBanDau__Email`, `QuanTriBanDau__MatKhau`; chạy bước `--initialize` có kiểm soát để khởi tạo Admin rồi xóa mật khẩu khởi tạo khỏi môi trường. Admin mới bắt buộc đổi mật khẩu.

Ứng dụng hỗ trợ thư mục tệp/khóa qua `UploadFiles__ThuMuc`, `DataProtection__ThuMucKhoa`, chặn thư mục tải lên bên trong wwwroot. Cookie Production là `__Host-`, Secure, HttpOnly, SameSite=Lax; HSTS 365 ngày, chuyển hướng HTTPS, tắt header Server và giới hạn request 30 MB. Windows Production thêm provider Event Log. TLS, DNS, tài khoản dịch vụ, chứng chỉ, quyền thư mục và cấu hình máy chủ cần được thiết lập trên máy triển khai.

`Quyen_CSDL.sql` tạo vai trò `r_ungdung`, chỉ gắn `htdl_app` nếu login đã được quản trị viên tạo. Không lưu mật khẩu SQL trong mã nguồn. LocalDB Development vẫn dùng Windows Authentication của người phát triển; việc có script quyền tối thiểu không tự biến tài khoản này thành tài khoản Production tối thiểu quyền.

Phần mở rộng cho phép vai trò ứng dụng DELETE trên ba bảng dữ liệu cá nhân mới (`LuaChonDaLuu`, `MucChuanBi`, `KhoanChiChuyenDi`); quyền xóa/cập nhật bị cấm trên các bảng lịch sử FullText vẫn giữ nguyên. Chạy `Quyen_CSDL.sql` sau 003 khi triển khai. Đã xác minh 22 quyền bằng người dùng tạm WITHOUT LOGIN trên database thử nghiệm, rollback người dùng sau kiểm tra. Worker chuẩn bị chạy lúc khởi động và mỗi 5 phút khi web đang chạy; lời nhắc nằm trong Thông báo, không gửi email/push.
