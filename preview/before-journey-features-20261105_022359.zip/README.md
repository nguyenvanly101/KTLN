# Hành Trình — Hệ thống hỗ trợ khách du lịch tự túc

ASP.NET Core MVC .NET 10, Razor, Bootstrap 5, Entity Framework Core 10 và SQL Server. Nguồn thiết kế hiện hành là bản **26271.3-FullText-XayDungHeThongHoTroKhachDuLichTuTuc (4).docx** người dùng cung cấp. Hợp đồng triển khai lấy từ Chương 4; các điểm mâu thuẫn trong tài liệu được ghi tại [báo cáo thực thi](docs/THUC_THI_FULLTEXT_2026-11-04.md).

Luồng mới đặt chuyến đi làm trung tâm: tổng quan việc cần xử lý, lịch trình, dịch vụ đã gắn, dự trù và bản đồ. Phần liên kết dữ liệu/API bổ sung sau thiết kế gốc được mô tả riêng tại [thiết kế luồng chuyến đi](docs/LUONG_CHUYEN_DI_2026-11-05.md). Đợt tiếp theo bổ sung lưu/so sánh, chuẩn bị, thực chi và thông tin/ảnh dịch vụ: [thiết kế và kết quả bàn giao](docs/MO_RONG_SAN_PHAM_2026-11-05.md).

## Mở website

Bản chính chạy tại **[http://localhost:5216](http://localhost:5216)**, database `HoTroDuLich`. Khi cần khởi động lại, mở PowerShell tại `D:\KLTN` và chạy:

```powershell
.\start.ps1
```

Hoặc chỉ rõ dự án khi đang ở thư mục `D:\KLTN`:

```powershell
dotnet run --project .\src\HoTroDuLich.Web --launch-profile http
```

Muốn tự cập nhật khi sửa mã, dùng:

```powershell
.\start.ps1 -Dev
```

Lệnh tương đương:

```powershell
dotnet watch --project .\src\HoTroDuLich.Web run --launch-profile http
```

Profile `http` đã cấu hình môi trường `Development`. Không cần thêm `dev` sau `dotnet run`; từ này chỉ được truyền vào ứng dụng như một tham số. Thư mục gốc `D:\KLTN` không chứa file `.csproj`, nên cần dùng `start.ps1`, chỉ rõ `--project`, hoặc chuyển vào `src\HoTroDuLich.Web` trước khi chạy.

Dừng tiến trình đang dùng cổng 5216 trước khi chạy thêm một bản. Nhấn Ctrl+C trong terminal chạy máy chủ để dừng. Máy cần .NET 10 SDK và SQL Server Express LocalDB.

Nếu không chạy được, làm theo [hướng dẫn tự xử lý lỗi khởi động](docs/TU_XU_LY_LOI_KHOI_DONG.md): nhận diện sai thư mục/lệnh, cổng bị chiếm, LocalDB và lỗi Application Control; có lệnh kiểm tra và dấu hiệu thành công cho từng trường hợp.

Ở Development, ứng dụng tạo lược đồ nền bằng `Database/schema.sql` khi database rỗng, sau đó chạy các phần mở rộng 002/003 có thể chạy lại; dữ liệu mẫu chỉ thêm nếu chưa có tài khoản. Script căn chỉnh nền 001 vẫn là bước nâng cấp riêng. Database chính trên máy đã áp dụng 001–003 với sao lưu và đối chiếu dữ liệu. `start.ps1` kiểm tra instance LocalDB hiện có trước khi chạy web; không tự xóa/tạo lại instance khi có lỗi.

## Tài khoản mẫu

Mật khẩu ban đầu: `HanhTrinh@2026`.

| Vai trò | Email |
| --- | --- |
| Khách du lịch | khach@hanhtrinh.vn |
| Khách thứ hai | linh@hanhtrinh.vn |
| Nhà cung cấp | nhacungcap@hanhtrinh.vn |
| Quản trị viên | admin@hanhtrinh.vn |

Quản trị viên được khởi tạo mới phải đổi mật khẩu ở lần đăng nhập đầu tiên. Dữ liệu mẫu, ảnh và giá phục vụ trình diễn. Mật khẩu Admin ở database kiểm thử 5219 đã được đổi riêng bởi bộ kiểm thử; database chính và database thử nghiệm tách biệt.

## Kiến trúc và hợp đồng FullText

Các số lượng 25 bảng/267 cột dưới đây mô tả thiết kế FullText nền. Bản hiện hành gồm phần mở rộng đã được chấp thuận: **28 bảng, 302 cột, 44 FK, 123 CHECK, 22 unique index, 38 query index và 4 view**. Các mục bổ sung được khai báo cụ thể trong [product-extension-schema.json](docs/product-extension-schema.json); 91 action chuẩn được giữ. Mã kiểm chứng hiện hành dùng hồ sơ `--product-extension`.

- **43 Controller chuẩn, 91 action GET/POST** theo Bảng 4.86, cùng 43 lớp ViewModel đầu vào. Danh sách route, query và policy: [fulltext-contract.json](docs/fulltext-contract.json).
- **19 component nghiệp vụ** có interface Service và đăng ký Scoped, cùng **11 giao diện liên component**. Các interface nằm ở `Services/Contracts/`; hiện thực ở `Services/Components/`.
- `TravelService` là lớp chuyển tiếp cho các đường dẫn giao diện cũ. Xử lý nghiệp vụ đã tách sang component; những URL tương thích gọi cùng Service và cùng kiểm tra quyền.
- **25 lớp miền, 267 thuộc tính vô hướng, 38 quan hệ và 24 enum**, ánh xạ qua 25 `IEntityTypeConfiguration`. RowVersion kiểm soát cập nhật đồng thời.
- **SQL là nguồn chuẩn**: 25 bảng, 117 CHECK, 18 chỉ mục duy nhất, 34 chỉ mục tra cứu, 4 view và 49 DEFAULT có tên. Collation `Vietnamese_100_CI_AS_SC`, RCSI ON, snapshot isolation OFF, recovery FULL, PAGE_VERIFY CHECKSUM, AUTO_CLOSE OFF.
- `IGiaoDich` dùng Serializable, thử lại toàn bộ thao tác tối đa ba lần khi deadlock/timeout. Thông báo và nhật ký quyết định đi cùng giao dịch; tệp vừa lưu được xóa bù khi thất bại.

Các API dùng biểu mẫu MVC, antiforgery token và trường tiếng Việt theo FullText. Bộ tiếp nhận dữ liệu hỗ trợ các tên trường của giao diện cũ. POST thành công dùng Post–Redirect–Get; lỗi có mã nghiệp vụ trong danh mục 98 mã.

## Chức năng mở rộng mới

- **Lưu và so sánh:** lưu địa điểm/dịch vụ vào bộ sưu tập riêng, so sánh 2–3 dịch vụ rồi xếp lựa chọn vào chuyến đi. Mục đã lưu nằm trong nhóm Khám phá.
- **Chuẩn bị chuyến đi:** checklist có nhóm, hạn, đánh dấu xong/mở lại; bộ gợi ý không trùng và lời nhắc trong ứng dụng khi web đang chạy.
- **Chi tiêu thực tế:** ghi/sửa/xóa khoản đã trả, tổng theo ngày/loại và ngân sách còn lại; tách riêng với dự trù và giá yêu cầu đặt.
- **Thông tin dịch vụ:** địa chỉ cụ thể, đơn vị giá, chính sách hủy và tối đa 5 ảnh thực tế. Nội dung/ảnh được công bố sau khi duyệt đúng phiên bản.

Mở từng chuyến đi để vào Chuẩn bị hoặc Chi tiêu; không thêm menu cấp cao. [Xem luồng, API, database và bằng chứng kiểm thử](docs/MO_RONG_SAN_PHAM_2026-11-05.md).

## Chức năng FullText đã triển khai

| SUC | Hành vi chính |
| --- | --- |
| 01.01 | Tra cứu công khai theo tên/mô tả, khu vực động, loại, giá; chi tiết địa điểm kèm dịch vụ liên quan |
| 02.01 | Kế hoạch riêng, hoạt động theo ngày/giờ/thứ tự, cảnh báo giờ và chi phí; sửa nội dung trả về nháp; xác nhận riêng |
| 03.01–03.02 | Tìm nhu cầu còn hiệu lực, lọc và phân trang; xem trước hai phạm vi người xem; công bố/sửa/dừng, che nội dung theo phạm vi chia sẻ |
| 04.01–04.02 | Kết nối có lời nhắn tùy chọn; thông tin liên hệ sau kết nối; thỏa thuận có phiên bản cơ sở, xác nhận đúng phiên bản, thay thế/rút/cùng ngừng và lịch sử |
| 05.01 | Tình huống gắn nhiều hoạt động, phương án và lịch sử, trạng thái xử lý cùng kết quả thực tế |
| 06.01–06.02 | Lưu nháp/gửi dịch vụ, bản cập nhật riêng, thời gian tạm ngừng; Admin duyệt đúng phiên bản, giữ bản công bố đến khi bản mới được duyệt |
| 07.01 | Xem trước yêu cầu và cảnh báo; gửi chống trùng bằng mã lượt; nhà cung cấp đề xuất ngày, số người, số lượng, chi phí và điều kiện để khách xác nhận |
| 08.01 | Sửa/rút yêu cầu đang chờ; thay đổi/hủy trước ngày phục vụ, một đề nghị đang chờ; giữ điều kiện cũ đến khi được chấp nhận |
| 09.01 | Kết quả từng hạng mục, trạng thái tổng hợp; phản ánh trong thời hạn, đối chiếu có nhật ký và bảo toàn kết quả đã chốt |
| 10.01–10.02 | Đăng ký khách/nhà cung cấp với hồ sơ và tệp; bổ sung/nộp lại; quyết định xác minh có lịch sử |
| 11.01 | Đăng nhập email/số điện thoại, phiên trượt 30 phút/tối đa 8 giờ, dấu phiên, đổi mật khẩu Admin, giới hạn 10 lần/phút/IP |
| 12.01 | Hồ sơ riêng cho cả ba vai trò, ảnh đại diện, phạm vi chia sẻ, liên hệ nhà cung cấp có RowVersion riêng |
| 13.01 | Xem hệ quả trước đình chỉ/khôi phục/thu hồi; xử lý đúng các dịch vụ/yêu cầu liên quan, giải trình và nhắc hạn quyết định hiện hành |
| 14.01 | Xác thực lại, liệt kê nghĩa vụ, mã xác nhận 5 phút gắn tài khoản/dấu phiên; kiểm tra lại khi ghi, đồng bộ ngừng và bảo toàn lịch sử |

Không có thanh toán trực tuyến hoặc đặt chỗ tự động bên ngoài phạm vi FullText. Phân quyền cụ thể: [MA_TRAN_QUYEN_SUC.md](docs/MA_TRAN_QUYEN_SUC.md). Điều hướng: [CAU_TRUC_TRANG.md](docs/CAU_TRUC_TRANG.md).

## Giao diện

Giao diện Open Atlas áp dụng ui-ux-pro-max: xanh biển, xanh đậm, nền sáng và điểm nhấn vàng xanh; ảnh du lịch lớn; phân cấp rõ thao tác chính, bộ lọc và trạng thái. Các khu vực cá nhân, đối tác và quản trị giữ bố cục nhất quán. Điện thoại dùng menu thu gọn, biểu mẫu một cột, danh sách đặt dịch vụ dạng thẻ, ô nhập 16 px và vùng chạm rộng.

Quy tắc trình bày: [GIAO_DIEN.md](docs/GIAO_DIEN.md). CSS nền nằm ở `wwwroot/css/experience.css`; các không gian mới dùng thêm `trip-workspace.css` và `product-features.css`. Ảnh và ghi công nằm trong `wwwroot/images/CREDITS.md`. Ảnh kiểm tra nằm ở `preview/fulltext-*.jpg`.

## Kiểm chứng

Các kết quả thực tế và giới hạn kiểm chứng được tổng hợp trong [báo cáo thực thi](docs/THUC_THI_FULLTEXT_2026-11-04.md) và [hướng dẫn kiểm thử](tests/README.md). Bộ mới gồm kiểm tra hợp đồng C#/API, lược đồ SQL vật lý, HTTP nghiệp vụ, quyền/CSRF, biểu mẫu và nhật ký bảo mật. Đợt mở rộng mới kiểm tra trên database riêng `HoTroDuLich_Product_20261105`, cổng 5221, tách thư mục ảnh và khóa. Các bộ nền trước đó dùng cổng 5219. Bản mới đạt 90 kiểm tra chức năng, 82 kiểm tra luồng chuyến đi, 102 điều hướng, 41 trang theo vai trò, 108 trình duyệt, 1807 hợp đồng C#/API và 1629 lược đồ SQL trên cả bản thử và bản chính. Số assertion của từng bộ không phải số yêu cầu thiết kế độc lập.

Các bộ `http-workflows.cjs`, `actor-access.cjs`, `function-pages.cjs` và báo cáo audit ban đầu là tư liệu của phiên bản trước, có kỳ vọng đã được thay đổi bởi FullText; không dùng chúng để chứng nhận bản hiện hành.

## Database và vận hành

Các script nằm ở `src/HoTroDuLich.Web/Database/`:

| Tệp | Mục đích |
| --- | --- |
| `CSDL_HoTroDuLichTuTuc.sql` | Tạo database và thiết lập cấu hình cho môi trường mới |
| `schema.sql` | Lược đồ chuẩn, chạy trên database rỗng |
| `001_CanChinh_FullText.sql` | ALTER database 25 bảng cũ; dừng web và sao lưu trước khi chạy |
| `002_LienKetYeuCauChuyenDi.sql` | Liên kết tùy chọn giữa yêu cầu đặt và chuyến đi |
| `003_ChuanBi_ChiTieu_LuaChon.sql` | Lưu lựa chọn, chuẩn bị, thực chi và metadata/ảnh dịch vụ |
| `KiemTra_FullText.sql` | Kiểm tra điều kiện tối thiểu khi triển khai |
| `Quyen_CSDL.sql` | Vai trò ứng dụng tối thiểu quyền, giới hạn DELETE/UPDATE |
| `SaoLuu_PhucHoi.sql` | Các khối mẫu full backup, log backup, CHECKDB và phục hồi tách biệt |

Hướng dẫn và trạng thái triển khai: [VAN_HANH.md](docs/VAN_HANH.md). Bản hiện hành chạy Development trên localhost. Cấu hình Production tắt dữ liệu mẫu, yêu cầu chuỗi kết nối và thông tin Admin ban đầu từ môi trường, bật HTTPS/HSTS/cookie Secure và Windows Event Log. Có thể cấu hình `UploadFiles__ThuMuc` và `DataProtection__ThuMucKhoa`; mặc định cục bộ là `App_Data/uploads` và `App_Data/keys`.
