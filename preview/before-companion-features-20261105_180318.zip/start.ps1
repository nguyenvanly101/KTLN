[CmdletBinding()]
param([switch]$Dev)

$ErrorActionPreference = 'Stop'
$travelProject = Join-Path $PSScriptRoot 'src\HoTroDuLich.Web\HoTroDuLich.Web.csproj'
$travelConfig = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'src\HoTroDuLich.Web\appsettings.json') | ConvertFrom-Json
$travelConnection = $env:ConnectionStrings__HoTroDuLich
if ([string]::IsNullOrWhiteSpace($travelConnection)) { $travelConnection = $travelConfig.ConnectionStrings.HoTroDuLich }
if ($travelConnection -match '(?i)(?:Server|Data Source)\s*=\s*\(localdb\)\\([^;]+)') {
    $travelInstance = $Matches[1].Trim()
    $travelLocalDb = Get-Command SqlLocalDB.exe -ErrorAction SilentlyContinue
    if (-not $travelLocalDb) { throw 'Không tìm thấy SqlLocalDB.exe. Kiểm tra cài đặt SQL Server Express LocalDB trước khi chạy web.' }
    Write-Host "Kiểm tra LocalDB $travelInstance bằng $($travelLocalDb.Source)"
    $travelInstanceInfo = & $travelLocalDb.Source info $travelInstance 2>&1 | Out-String
    if ($travelInstanceInfo -notmatch '(?im)^Name:\s*') { throw "Không đọc được instance $travelInstance. Giữ nguyên database cũ và xem docs\TU_XU_LY_LOI_KHOI_DONG.md.`n$travelInstanceInfo" }
    if ($travelInstanceInfo -notmatch '(?im)^State:\s*Running\s*$') {
        $travelStartResult = & $travelLocalDb.Source start $travelInstance 2>&1 | Out-String
        Write-Host $travelStartResult.Trim()
        $travelInstanceInfo = & $travelLocalDb.Source info $travelInstance 2>&1 | Out-String
        if ($travelInstanceInfo -notmatch '(?im)^State:\s*Running\s*$') { throw "LocalDB chưa khởi động được. Web chưa được chạy. Xem log SQL theo docs\TU_XU_LY_LOI_KHOI_DONG.md.`n$travelStartResult`n$travelInstanceInfo" }
    }
}
if ($Dev) {
    dotnet watch --project $travelProject run --launch-profile http
} else {
    dotnet run --project $travelProject --launch-profile http
}
exit $LASTEXITCODE
