# Lựa chọn đã lưu, chuẩn bị chuyến đi, thực chi và thông tin dịch vụ

Đây là mốc thiết kế/kiểm chứng **003 (product)**. Bản hiện hành đã có thêm 004, dùng hồ sơ journey với 31 bảng/335 cột; xem [bàn giao tiếp theo](HANH_TRINH_MO_RONG_2026-11-05.md). Các con số và sao lưu dưới đây thuộc riêng mốc 003.

Đợt mở rộng được người dùng chấp thuận sau khi rà lại luồng sản phẩm. Đây là thiết kế bổ sung cho FullText: giữ các bảng/cột và 91 action chuẩn, bổ sung dữ liệu và action cho bốn nhóm chức năng dưới đây. Hợp đồng lược đồ bổ sung nằm tại `product-extension-schema.json`; SQL áp dụng là `003_ChuanBi_ChiTieu_LuaChon.sql` sau script 002.

## Luồng người dùng

### Lưu và so sánh

- Khách du lịch lưu dịch vụ từ thẻ kết quả hoặc trang chi tiết; lưu địa điểm từ trang địa điểm. Không cần chọn chuyến/ngày trước khi lưu.
- Mục **Lựa chọn đã lưu** nằm trong nhóm Khám phá. Từ đây mở chi tiết hoặc chọn/tạo chuyến để xếp mục đã lưu vào lịch.
- Chọn 2–3 dịch vụ của chính mình để so sánh giá, đơn vị tính, vị trí, thời gian, tình trạng tiếp nhận và điều kiện phục vụ/thay đổi/hủy. Không suy ra dịch vụ rẻ nhất khi khác đơn vị/loại hình.
- Lưu lại cùng mục không tạo bản ghi trùng. Người dùng có thể bỏ lưu. Khi mục ngừng công bố, chỉ hiển thị tên đã lưu trước đó và trạng thái không còn công khai; không lộ bản sửa chưa duyệt.

### Chuẩn bị chuyến đi

- Từ từng chuyến đi mở **Chuẩn bị**: thêm việc theo nhóm giấy tờ, hành lý, di chuyển, đặt dịch vụ hoặc việc khác.
- Có thể thêm bộ gợi ý gồm bốn việc khởi đầu; bấm lại chỉ thêm những việc còn thiếu.
- Đặt hạn tùy chọn; bật lời nhắc thì phải có hạn. Đánh dấu xong, mở lại, sửa hoặc bỏ việc bằng thao tác riêng.
- Tổng quan chuyến đi hiển thị số việc đã hoàn thành/tổng số; đưa việc chưa xong quá hạn vào danh sách cần xử lý.
- Lời nhắc trong mục Thông báo được tạo khi đến hạn và việc chưa xong. Worker kiểm tra mỗi 5 phút khi ứng dụng đang chạy. Mỗi việc được nhắc một lần cho hạn hiện hành; đổi hạn/bật lại nhắc sau khi tắt sẽ cho phép nhắc theo lựa chọn mới. Không triển khai email/push ngoài ứng dụng trong đợt này.

### Chi tiêu thực tế

- Mở **Chi tiêu** trong chuyến đi và ghi nội dung, loại chi, số tiền đã trả, ngày chi, ghi chú tùy chọn.
- Ngày chi không sau hôm nay; cho phép khoản đặt trước chuyến đi. Các khoản dự định trả tiếp tục nằm trong dự trù hoạt động.
- Hiển thị tổng thực chi, dự trù hoạt động, số tiền còn lại/vượt ngân sách và tổng theo loại chi/ngày. Giá yêu cầu đặt và dự trù không tự cộng vào thực chi.
- Số tiền lưu `decimal(18,2)`, lớn hơn 0, tối đa 1 tỷ/khoản. API/form dùng dấu chấm thập phân, không dùng dấu phân cách hàng nghìn; từ chối giá trị cần làm tròn quá 2 chữ số. Giao diện định dạng tiếng Việt, giữ phần lẻ khi có.
- Gửi lại cùng mã lượt ghi không thêm khoản lần hai. Sửa/xóa kiểm tra chủ chuyến và `RowVersion`; xung đột yêu cầu tải lại bản hiện tại.

### Nội dung dịch vụ

- Nhà cung cấp bổ sung địa chỉ phục vụ, đơn vị giá, chính sách thay đổi/hủy riêng và tối đa 5 ảnh JPG/PNG, mỗi ảnh tối đa 5 MB. Kiểm tra phần mở rộng, chữ ký tệp; lưu tên ngẫu nhiên ngoài `wwwroot`.
- Nội dung/ảnh đi cùng phiên bản gửi duyệt. Trong lúc chờ, trang công khai tiếp tục dùng bản được duyệt trước đó. Chỉ duyệt đúng phiên bản mới công bố dữ liệu mới.
- Đường dẫn ảnh được sinh và giữ ở máy chủ; `PhotoPaths` không được bind từ người dùng. Tải bộ ảnh mới thay bộ ảnh trong phiên bản mới, không xóa ảnh của lịch sử.
- Nhà cung cấp xem được ảnh/lịch sử của mình; Admin xem được ảnh xét duyệt. Khách/nhà cung cấp khác không được mở ảnh chờ duyệt.
- Thẻ kết quả, chi tiết và so sánh dùng ảnh đã duyệt; khi chưa có ảnh riêng thì ghi rõ ảnh minh họa. Các dịch vụ cũ thiếu địa chỉ/đơn vị/chính sách riêng được hiển thị là chưa công bố, không tự điền dữ kiện giả.

## Dữ liệu

| Bảng bổ sung | Cột và ràng buộc chính |
|---|---|
| `LuaChonDaLuu` | ID, chủ tài khoản, dịch vụ hoặc địa điểm, tên tại lúc lưu, thời điểm. CHECK bắt buộc đúng một loại mục; unique có lọc theo chủ+dich vụ/địa điểm |
| `MucChuanBi` | ID, chuyến đi, nội dung, nhóm, hạn, trạng thái hoàn thành, chọn nhắc, ngày đã nhắc, thời điểm, rowversion. Unique nội dung trong chuyến; CHECK nhóm |
| `KhoanChiChuyenDi` | ID, chuyến đi, nội dung, loại, số tiền, ngày, ghi chú, GUID lượt ghi, thời điểm, rowversion. Unique chuyến+lượt ghi; CHECK số tiền/loại |

`Quyen_CSDL.sql` cho phép DELETE trên ba bảng dữ liệu cá nhân mới để thực hiện thao tác bỏ/xóa đã được người dùng chọn. Các hạn chế DELETE/UPDATE của bảng lịch sử FullText vẫn giữ nguyên; sở hữu bản ghi được kiểm tra lại trong Service.

Mỗi bảng `DichVuDuLich`, `BanCapNhatDichVu` bổ sung bốn cột nullable: `DiaChiPhucVu nvarchar(300)`, `DonViGia nvarchar(50)`, `ChinhSachHuy nvarchar(2000)`, `AnhJson nvarchar(2000)`; CHECK JSON nếu có ảnh. Chúng được thêm vào bộ `ServiceFields` chung để tạo phiên bản, kiểm tra thay đổi và công bố theo cùng quy trình.

Tổng lược đồ sau 002+003: **28 bảng, 302 cột, 44 FK NO ACTION, 123 CHECK, 22 unique index, 38 query index, 4 view gốc**. Các bảng/cột/ràng buộc gốc không bị đổi tên/xóa; các bản ghi cũ giữ giá trị và ID.

## API/hàm

Các action dùng form MVC và trả trang HTML hoặc chuyển hướng sau khi lưu, cùng cách làm của các action FullText hiện có. POST bắt buộc CSRF, kiểm tra ở server; GET không ghi dữ liệu.

| Điểm vào | Chức năng/quyền |
|---|---|
| `GET /Saved` | Danh sách lựa chọn của khách đang đăng nhập |
| `POST /Saved/Add` | `ServiceId` hoặc `PlaceId`, `ReturnUrl` nội bộ tùy chọn; kiểm tra mục công khai, lưu không trùng |
| `POST /Saved/Remove` | `Id` thuộc khách đang đăng nhập |
| `GET /Saved/Compare?ids=…&ids=…` | 2–3 ID lựa chọn dịch vụ thuộc khách; mục phải còn công bố |
| `GET /Preparation?planId=…&edit=…` | Danh sách/biểu mẫu của chủ chuyến |
| `POST /Preparation/Save` | `ChecklistInput`: PlanId, Id/Version khi sửa, Title, Category, Due, Remind |
| `POST /Preparation/Action` | planId, Id, Version, Decision=`Done/Undo/Delete` |
| `POST /Preparation/Defaults` | planId; thêm bộ việc gợi ý không trùng |
| `GET /Expenses?planId=…&edit=…` | Tổng hợp/biểu mẫu thực chi của chủ chuyến |
| `POST /Expenses/Save` | `ExpenseInput`: PlanId, Id/Version khi sửa, Title, Category, Amount, SpentOn, Notes, SubmissionId |
| `POST /Expenses/Delete` | planId, Id, Version; chủ chuyến |
| `GET /service-photos/{serviceId}/{index}` | Chỉ ảnh từ bản công khai của dịch vụ còn được phép hiển thị |
| `GET /service-photos/review/{serviceId}/{index}?revision=…` | Admin hoặc NCC sở hữu dịch vụ; phiên bản phải thuộc đúng dịch vụ |
| API gửi/cập nhật dịch vụ hiện có | Bổ sung Address, PriceUnit, CancellationPolicy, Photos (multipart), RemovePhotos; các trường mới tùy chọn để tương thích yêu cầu cũ |

`ProductService` xử lý các luật mới; `TripWorkspaceService` tổng hợp số chuẩn bị/thực chi. Dịch vụ ảnh dùng `ILuuTep` hiện có để kiểm tra/lưu tệp và dọn bù khi transaction thất bại. Phản hồi/xác nhận/điều chỉnh/hủy dịch vụ giữ nguyên component FullText.

Vai trò NCC/Admin không được dùng chức năng lưu lựa chọn, checklist hay thực chi của khách. Ngay cả ID hợp lệ của người khác cũng không đủ để xem/sửa/xóa. Lỗi dữ liệu trả 400/422 kèm giá trị đã nhập; lỗi quyền 403, không tìm thấy/khác chủ 404, xung đột phiên bản 409.

## Giao diện và khởi động

Tiếp tục dùng Open Atlas và ui-ux-pro-max; không thêm menu cấp cao. Biểu mẫu có nhãn, lỗi cạnh trường và tổng hợp lỗi có liên kết/focus; khi tạo mới không gửi mã phiên bản rỗng, khi sửa vẫn kiểm tra RowVersion; nút thao tác chạm tối thiểu 44px. So sánh có kiểm tra lựa chọn trên trình duyệt lẫn server. Điện thoại ưu tiên danh sách và có đường đến nhanh biểu mẫu.

`start.ps1` kiểm tra instance LocalDB theo chuỗi kết nối môi trường/cấu hình cơ sở, hiển thị bản utility đang dùng, thử start khi Stopped và chỉ chạy web nếu đọc được Running. Không tự xóa/tạo lại instance, cưỡng bức dừng SQL hoặc sửa registry/chính sách Windows. Đây là kiểm tra trước khi chạy; không thay thế chẩn đoán nguyên nhân nếu LocalDB trên máy vẫn không start được.

## Kiểm chứng

Các bộ ghi thử chỉ dùng `HoTroDuLich_Product_20261105`, cổng `5221`, khóa `preview/product-test-keys` và thư mục ảnh `preview/product-test-uploads`. Không chạy bộ ghi lên database chính.

| Kết quả thực tế | Assertion đạt | Phạm vi |
|---|---:|---|
| [product-features-results.json](../tests/product-features-results.json) | 90 | Lưu/so sánh, CRUD, sở hữu, CSRF, RowVersion, chống gửi trùng, số tiền/thập phân, duyệt và ảnh riêng/công khai |
| [trip-workflow-results.json](../tests/trip-workflow-results.json) | 82 | Giữ ngữ cảnh chọn trải nghiệm, chuyến đi, đặt dịch vụ và phân quyền |
| [navigation-redesign-results.json](../tests/navigation-redesign-results.json) | 102 | Menu/nhóm, tìm kiếm, quyền và dựng trang |
| [fulltext-smoke-results.json](../tests/fulltext-smoke-results.json) | 41 | Trang FullText theo các vai trò |
| [product-browser-results.json](../tests/product-browser-results.json) | 108 | Thao tác thật, lỗi giữ dữ liệu/focus, nhập phần lẻ, lưu nháp NCC; 31 tổ hợp trang/kích thước, không phát hiện tràn ngang/nhãn thiếu/lỗi console |
| [product-contract-results.json](../tests/product-contract-results.json) | 1807 | Hợp đồng C#/EF và 91 action nền; chọn `--product-extension` |
| [product-schema-results.json](../tests/product-schema-results.json), [product-main-schema-results.json](../tests/product-main-schema-results.json) | 1629 mỗi DB | Lược đồ SQL vật lý, kiểu/null/FK/CHECK/index/view/cấu hình; chọn `TRAVEL_PRODUCT_EXTENSION=1` |
| [preparation-reminder-results.json](../tests/preparation-reminder-results.json) | 3 | Việc đến hạn tạo đúng một thông báo; giữ một sau lần khởi động lại thứ hai |
| [product-database-permissions-results.json](../tests/product-database-permissions-results.json) | 22 | Quyền dữ liệu mới và các hạn chế lịch sử; người dùng thử WITHOUT LOGIN được rollback |
| [product-upgrade-rehearsal-results.json](../tests/product-upgrade-rehearsal-results.json) | 80 | Phục hồi backup sang DB riêng, dữ liệu trùng bản chính; tạo mới/lặp 003 với QUOTED_IDENTIFIER OFF trước script |
| [product-upgrade-results.json](../tests/product-upgrade-results.json) | 63 | Nâng cấp bản chính, số dòng/SHA-256 cột cũ giữ nguyên, ba bảng mới rỗng, các trường bổ sung của dữ liệu cũ vẫn NULL |
| [product-startup-results.json](../tests/product-startup-results.json) | 14 | Cả `start.ps1` và `start.ps1 -Dev`, HTTP 5216, tài nguyên mới, chuyển tới đăng nhập và LocalDB Running |

Build cuối: 0 lỗi, 0 cảnh báo. Số assertion của từng bộ không tương đương số yêu cầu thiết kế độc lập. Kiểm tra trình duyệt dùng 375×812, 768×1024, 1024×768, 1280×900 và 812×375 cho năm trang chính; biểu mẫu/danh sách NCC được xem thêm ở 375/768/1280.

## Bản chính và sao lưu

Đã áp dụng 003 cùng `Quyen_CSDL.sql` trên `HoTroDuLich`. Toàn bộ cột cũ của 25 bảng được sắp theo khóa chính và băm SHA-256 trước/sau; số dòng và giá trị đều khớp. Các dữ liệu thử và chuyến đi minh họa không được sao chép sang bản chính.

- Mã nguồn trước đợt mới: `preview/before-product-features-20261105-011553.zip`.
- SQL COPY_ONLY/CHECKSUM: `preview/backups/HoTroDuLich_before_product_20261105_015725.bak`; VERIFYONLY WITH CHECKSUM đã đạt, đã phục hồi sang `HoTroDuLich_ProductUpgrade_20261105` với MDF/LDF riêng.
- Tệp tải lên/khóa: `preview/backups/App_Data_before_product_20261105_021127.zip`, 21 tệp đã đối chiếu; checksum ZIP ở `preview/product-appdata-backup.json`.
- Bằng chứng dữ liệu: `preview/product-main-values-before.json`, `preview/product-main-values-after.json` (metadata, số dòng và hash; không ghi nội dung bản ghi).

Script 003 tự đặt các SET option cần cho filtered index; không phụ thuộc vào việc sqlcmd mở sẵn QUOTED_IDENTIFIER. Các script có transaction và khóa nâng cấp, chạy lại được. Bản chính đã được khởi động bằng hai lệnh chuẩn rồi dừng các tiến trình kiểm thử để nhường cổng.

Mở website:

```powershell
cd D:\KLTN
.\start.ps1 -Dev
```

Vào [http://localhost:5216](http://localhost:5216). Menu **Khám phá → Lựa chọn đã lưu** dùng cho bộ sưu tập; mở **Chuyến đi của tôi → một chuyến đi → Chuẩn bị / Chi tiêu thực tế** để dùng các phần còn lại. Nhà cung cấp mở dịch vụ, bổ sung thông tin/ảnh và gửi xét duyệt.

Ảnh bàn giao dùng dữ liệu minh họa trên database kiểm thử riêng: [so sánh desktop](../preview/product-compare-desktop.png), [chi tiêu desktop](../preview/product-expenses-desktop.png), [chuẩn bị điện thoại](../preview/product-preparation-mobile.png), [biểu mẫu nhà cung cấp](../preview/product-provider-form.png).

Chế độ FullText nền và chế độ chỉ thêm liên kết chuyến đi vẫn giữ kỳ vọng riêng; cần chọn hồ sơ product cho mã hiện hành. Phần mở rộng được khai báo theo tên/kiểu cột, FK, CHECK và index cụ thể, không bỏ qua tùy ý những sai khác.
