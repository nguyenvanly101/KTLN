# Giao diện Hành Trình — Open Atlas

Bản hiện hành cập nhật ngày 05/11/2026 dùng xanh biển, xanh đậm, nền trắng và điểm nhấn vàng xanh. Trang khám phá kết hợp ảnh lớn, bưu thiếp điểm đến, tuyến đi ba bước và tìm kiếm ngay phần đầu. Trang quản lý dùng thẻ, lưới, trạng thái và thao tác rõ ràng cùng một hệ thống thiết kế.

Quy tắc đầy đủ và các truy vấn ui-ux-pro-max đã sử dụng nằm trong [MASTER.md](../design-system/hanh-trinh/MASTER.md). CSS hiện hành nằm ở `wwwroot/css/experience.css`, `trip-workspace.css`, `product-features.css` và `journey-features.css`; không tải font hay thư viện giao diện ngoài.

## Menu theo nhóm

| Nhóm | Chức năng |
|---|---|
| Khám phá | Điểm đến; lưu trú; ăn uống; di chuyển; hoạt động; lựa chọn đã lưu |
| Chuyến đi | Lịch trình cá nhân; đặt dịch vụ; hỗ trợ chuyến đi |
| Đặt dịch vụ | Tab yêu cầu đặt; thay đổi/hủy; kết quả phục vụ; đánh giá của khách |
| Đồng hành | Tìm người; bài đăng của tôi; kết nối của tôi |
| Nhà cung cấp | Dịch vụ & đặt chỗ; hồ sơ đối tác; tài khoản |
| Quản trị | Tổng quan; duyệt & xác minh; quyền nhà cung cấp; nhật ký; tài khoản |

Trang công khai có ba menu nhóm. Trong không gian cá nhân, nhà cung cấp và quản trị, thanh bên tự mở nhóm đang sử dụng. Các bước xử lý của đặt dịch vụ được gom trong cùng một trang có tab; không tách chúng thành mục ngang hàng trên menu chính. Chi tiết một yêu cầu vẫn giữ tab riêng theo đúng mã yêu cầu.

## Các bố cục chính

- Khám phá: hero và tìm kiếm; điểm đến; hướng dẫn xây lịch trình; dịch vụ; kết nối đồng hành. Kết quả tìm kiếm bỏ hero để dành chỗ cho bộ lọc và kết quả. Chuyển loại dịch vụ giữ từ khóa, khu vực và khoảng giá.
- Chuyến đi: banner, lối tắt công việc liên quan, số liệu thật, tìm theo tên/điểm đến không dấu, lọc bản nháp/đã xác nhận, thẻ có ảnh và ngày khởi hành. Không có JavaScript thì vẫn xem được toàn bộ danh sách.
- Đồng hành: ảnh điểm đến, nơi đến và ngày đi hiển thị trước; ngân sách và hình thức đi nằm trong bộ lọc mở thêm. Nút tìm người dẫn thẳng tới biểu mẫu; sau tìm kiếm bỏ phần giới thiệu lớn để ưu tiên bộ lọc và kết quả. Bộ lọc phụ đã dùng tự mở và giữ giá trị. Thẻ vẫn tuân thủ phạm vi chia sẻ của từng nhu cầu.
- Lựa chọn đã lưu: thẻ ảnh, thao tác xếp vào chuyến đi, checkbox chọn 2–3 dịch vụ và so sánh cạnh nhau; trên điện thoại xếp thành danh sách dọc.
- Chuẩn bị: số việc đã xong, danh sách theo nhóm, đánh dấu/mở lại và biểu mẫu có nhãn. Điện thoại ưu tiên danh sách, nút đầu trang dẫn thẳng tới biểu mẫu.
- Chi tiêu: tổng thực chi, dự trù và phần ngân sách còn lại; khoản chi theo ngày và loại, biểu mẫu ở bên phải trên desktop và bên dưới trên điện thoại.
- Hôm nay: tiến độ và điểm dừng tiếp theo đứng trước lịch trong ngày; thời gian di chuyển rõ ràng, trạng thái hoàn thành có chữ và màu; cảnh báo, dịch vụ và hỗ trợ ở cột phụ trên desktop, xuống dưới trên điện thoại.
- Chia sẻ / in: thông tin công khai/hạn/đồng ý đứng trước nút tạo; URL chỉ xuất hiện một lần, có sao chép và cách sao chép thủ công. Bản snapshot độc lập, dễ in A4, không có menu tài khoản.
- Lịch phục vụ: thẻ ngày phân biệt tiếp nhận/tạm ngừng/chưa cập nhật bằng chữ; biểu mẫu cập nhật ở cột phụ, có lối tắt tới biểu mẫu trên điện thoại. Số lượng luôn ghi tham khảo.
- Đánh giá: nội dung khách và phản hồi NCC có trạng thái duyệt riêng; lý do ẩn xuất hiện trong màn hình quản lý, không đưa ra trang công khai.
- Đối tác: khu vực dịch vụ, lối tắt yêu cầu/hồ sơ/quyền, trạng thái xác minh và hoạt động; ảnh riêng đã duyệt hoặc ảnh minh họa có nhãn. Biểu mẫu hiển thị thông tin cơ bản trước phần bổ sung địa chỉ/đơn vị/chính sách/ảnh.
- Quản trị: tổng quan công việc, số liệu liên kết tới danh sách, nhóm xét duyệt/xác minh và các thẻ nghiệp vụ.

## Thao tác và khả năng truy cập

Menu dùng nhấp/bàn phím; Escape đóng và trả focus. Trên điện thoại, menu có nền phủ, khóa nội dung phía sau và giữ Tab trong vùng điều hướng; mục đang đóng không tham gia vòng Tab. Breakpoint JavaScript/CSS thống nhất 1000px. Điều khiển chính tối thiểu 44px, ô nhập văn bản trên điện thoại 16px; có focus ring, skip link, nhãn rõ ràng, trạng thái trống và hỗ trợ giảm chuyển động.

Danh sách đặt dịch vụ chuyển từ bảng sang thẻ có nhãn trên điện thoại. Các biểu mẫu, bảng quản trị, thông báo, kết quả phục vụ và vùng ngừng tài khoản dùng cùng token và khoảng cách. Không thêm số lượng người dùng, đánh giá hay xác nhận dịch vụ giả.

## Nghiệp vụ FullText

Bản cập nhật luồng ngày 05/11 thêm trung tâm từng chuyến đi, giữ ngữ cảnh chọn trải nghiệm và liên kết yêu cầu đặt với chuyến đi. Đây là phần mở rộng được ghi rõ trong [LUONG_CHUYEN_DI_2026-11-05.md](LUONG_CHUYEN_DI_2026-11-05.md); mô tả giữ nguyên database/API phía dưới là phạm vi của đợt làm giao diện ngày 04/11. Ảnh hiện hành: [trung tâm chuyến đi](../preview/trip-workspace-desktop.png), [toàn trang](../preview/trip-workspace-full.png), [điện thoại](../preview/trip-workspace-mobile.png). 13 kiểm tra trình duyệt bổ sung ở `tests/trip-browser-results.json`.

Giữ nguyên database, API, service, phân quyền và trạng thái nghiệp vụ. Lịch trình xác nhận riêng; yêu cầu đặt và nhu cầu đồng hành có bước xem trước; kết quả phục vụ, thay đổi/hủy và thỏa thuận tiếp tục làm việc theo đúng đối tượng. Chức năng ghi của khách du lịch không hiện với nhà cung cấp/quản trị. Thông báo tiếp tục dùng POST khi mở để đánh dấu đã đọc.

Kiểm tra HTTP theo bốn vai trò, giá trị tìm kiếm, tài nguyên và các trang: `tests/navigation-redesign.cjs`. Kết quả ở `tests/navigation-redesign-results.json`. Kiểm tra tương tác trình duyệt và ảnh của bản mới dùng tiền tố `preview/navigation-`.

Bản này build thành công với 0 lỗi, 0 cảnh báo; 102 kiểm tra HTTP và 23 kiểm tra tương tác trình duyệt đạt. Kết quả trình duyệt nằm ở `tests/navigation-browser-results.json`, gồm tìm kiếm không dấu, trạng thái trống, menu bàn phím, nhóm đang đóng, tab nghiệp vụ, giữ bộ lọc và bố cục ở 375px, 768px, 1024px, 1280px cùng điện thoại ngang 812×375. Các luồng được quan sát không ghi nhận lỗi/warning console.

Ảnh xem trước: [Trang chủ](../preview/navigation-home-desktop.png), [menu nhóm](../preview/navigation-menu-desktop.png), [điện thoại](../preview/navigation-home-mobile.png), [chuyến đi](../preview/navigation-plans-mobile.png), [nhà cung cấp](../preview/navigation-provider-desktop.png), [quản trị](../preview/navigation-admin-desktop.png).

## Kiểm tra phần mở rộng sản phẩm

[Thiết kế, API và bằng chứng](MO_RONG_SAN_PHAM_2026-11-05.md) ghi riêng các thay đổi database và nghiệp vụ đã được chấp thuận. Đợt mới đạt 108 assertion trình duyệt tại 31 tổ hợp trang/kích thước, gồm 375×812, 768×1024, 1024×768, 1280×900 và 812×375; không phát hiện tràn ngang, nhãn biểu mẫu thiếu hoặc lỗi console trong các luồng quan sát. Lỗi biểu mẫu chuẩn bị/thực chi giữ nội dung, đưa focus vào tổng hợp lỗi và liên kết tới trường cần sửa. Biểu mẫu tạo mới không gửi mã phiên bản rỗng; khi sửa vẫn dùng RowVersion.

Ảnh minh chứng dùng dữ liệu riêng của bản kiểm thử: [so sánh](../preview/product-compare-desktop.png), [chi tiêu](../preview/product-expenses-desktop.png), [chuẩn bị trên điện thoại](../preview/product-preparation-mobile.png). Các chức năng và dữ liệu gốc được kiểm tra theo hồ sơ product; các kết quả lịch sử phía trên thuộc đợt giao diện tương ứng.

## Kiểm tra bản mở rộng 004 hiện hành

[Thiết kế và bằng chứng](HANH_TRINH_MO_RONG_2026-11-05.md): 174 assertion trình duyệt, gồm 75 tổ hợp của 15 màn hình ở năm kích thước đã nêu. Biểu mẫu khách/NCC/Admin được thao tác thật; lỗi có tổng hợp và liên kết tới trường/dòng đúng, nội dung nhập được giữ. Đã kiểm tra tạo/sửa hoạt động, tiến độ, chia sẻ/copy, đánh giá/phản hồi/kiểm duyệt và lịch tiếp nhận/tạm ngừng. Khối điểm dừng dùng chữ trắng trên nền xanh đậm, nhãn hoàn thành dùng xanh đậm trên nền xanh nhạt. Lượt UI cuối không ghi nhận lỗi hoặc warning console.

Ảnh hiện hành: [Hôm nay desktop](../preview/journey-today-desktop.png), [Hôm nay điện thoại](../preview/journey-today-mobile.png), [chia sẻ](../preview/journey-share-desktop.png), [snapshot](../preview/journey-public-snapshot.png), [lịch NCC](../preview/journey-calendar-desktop.png). Dữ liệu ảnh chỉ ở database thử; không thêm đánh giá/tiến độ giả vào bản chính.
