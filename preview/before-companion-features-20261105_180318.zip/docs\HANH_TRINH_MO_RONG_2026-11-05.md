# Hành trình trong ngày, thời gian, chia sẻ, đánh giá và lịch phục vụ

Người dùng chấp thuận triển khai đủ năm phần sau đợt mở rộng 003. Đây là thiết kế bổ sung, giữ nguyên 91 action FullText và các cột/ràng buộc cũ. SQL 004 và `journey-extension-schema.json` mô tả những bổ sung cụ thể; hồ sơ kiểm chứng hiện hành là journey, bao gồm baseline + 002 + 003 + 004.

## Luồng và luật xử lý

1. Mở chuyến đi → **Hôm nay**. Trang ưu tiên điểm dừng chưa hoàn thành tiếp theo, giờ/thời lượng, bản đồ, các yêu cầu dịch vụ trong ngày và hỗ trợ. Có thể xem ngày khác trong chuyến. Chỉ chủ chuyến đánh dấu xong/mở lại hoạt động hôm nay hoặc ngày đã qua; cập nhật có kiểm tra RowVersion kế hoạch, không thay đổi trạng thái nháp/đã xác nhận. Đổi ngày/giờ/nội dung/đối tượng của hoạt động xóa mốc hoàn thành cũ.
2. Biểu mẫu hoạt động thêm thời lượng 1–1440 phút và di chuyển trước hoạt động 0–720 phút, đều tùy chọn. Kiểm tra theo thứ tự ngày/thứ tự người dùng đã xếp; giữ thời điểm kết thúc muộn nhất để phát hiện cả chồng lấn không liền kề và qua nửa đêm. Thiếu giờ/thời lượng được thông báo chưa đủ dữ liệu. Các giá trị do người dùng ước tính, không giả lập dữ liệu giao thông hay tự gọi API trả phí. API nền không gửi trường mở rộng thì giữ các thời lượng đã lưu.
3. **Chia sẻ / in**: chủ chuyến chọn ngân sách dự kiến, thông tin tên/ngày/trạng thái dịch vụ và hạn 1–30 ngày; xác nhận trước khi tạo. Mỗi liên kết là snapshot tại thời điểm tạo, không tự công bố sửa đổi sau đó. Không kèm thực chi, checklist, liên hệ, tin nhắn, mã yêu cầu, sự cố hay dữ liệu tài khoản. Tên/nội dung hoạt động do chủ chuyến nhập luôn nằm trong snapshot và được nêu rõ trước khi tạo. Token ngẫu nhiên 32 byte, chỉ lưu SHA-256; URL hiển thị một lần để sao chép. Tối đa 20 liên kết còn hiệu lực/chuyến. Chủ chuyến có thể thu hồi; hết hạn/thu hồi/tài khoản chủ đã ngừng trả 404. Trang chỉ xem, không gắn giao diện tài khoản hoặc tài nguyên ngoài; `no-store`, `no-referrer`, `noindex`. In/lưu PDF dùng hộp thoại trình duyệt và CSS A4, không tạo liên kết công khai khi chủ chỉ mở bản in riêng.
4. **Đánh giá** nằm trong quản lý đặt dịch vụ. Chỉ chủ yêu cầu có kết quả hoàn tất/toàn phần/một phần/không thực hiện, qua ngày phục vụ và không còn hạng mục chờ đối chiếu được viết; một đánh giá/yêu cầu. Không loại bỏ quyền đánh giá trải nghiệm không thành công. Đánh giá sửa quay lại chờ duyệt. NCC chỉ phản hồi đánh giá đã công bố của dịch vụ thuộc mình; phản hồi được duyệt riêng. Admin công bố/ẩn từng phần, bắt buộc lý do khi ẩn, kiểm tra RowVersion và lưu nhật ký. Trang công khai chỉ có nội dung/điểm đã duyệt; không lộ liên hệ, mã yêu cầu, lý do nội bộ hoặc phản hồi chờ duyệt. Không hiển thị tên riêng khách. Nếu yêu cầu mở lại đối chiếu thì đánh giá tạm không được tổng hợp công khai.
5. **Lịch phục vụ** từ từng dịch vụ của NCC: cập nhật tiếp nhận/tạm ngừng, số lượng tham khảo và ghi chú công khai cho một ngày từ hôm nay đến một năm tới; có thể đưa về chưa cập nhật. Kiểm tra NCC sở hữu/đang hoạt động và RowVersion từng dòng. Khách xem lịch theo tháng; ngày chưa cập nhật không được diễn giải là còn chỗ. Kiểm tra lại ngày tạm ngừng ở cả xem trước và transaction gửi yêu cầu mới. Lưu trú kiểm tra các đêm [nhận, trả), các loại khác gồm cả ngày kết thúc. Thay đổi lịch không tự hủy hay sửa yêu cầu đang tồn tại; lượng tham khảo không phải kho chỗ tự động.

## Dữ liệu và quyền

Thêm `ChiaSeChuyenDi` (10 cột, FK kế hoạch, unique token), `DanhGiaDichVu` (12 cột, FK/unique yêu cầu), `LichPhucVuDichVu` (8 cột, FK dịch vụ, unique dịch vụ+ngày). `HoatDongLichTrinh` thêm ba cột nullable `ThoiLuongPhut`, `DiChuyenTruocPhut`, `HoanThanhLuc`; không gán thời lượng/tiến độ giả cho bản ghi cũ.

Tổng: **31 bảng, 335 cột, 47 FK NO ACTION, 132 CHECK, 25 unique index, 40 query index, 4 view gốc**. SQL 004 có transaction, khóa nâng cấp và SET option đầy đủ; chạy lại được. Vai trò ứng dụng được DELETE bảng lịch phục vụ để đưa ngày về chưa cập nhật; chia sẻ thu hồi bằng trạng thái, đánh giá giữ lịch sử, các lệnh cấm trên bảng lịch sử gốc được giữ.

## Điểm vào bổ sung

| API MVC | Quyền / mục đích |
|---|---|
| GET `/Journey/Today?planId=&date=` | Chủ chuyến; hôm nay hoặc ngày trong chuyến |
| POST `/Journey/Complete` | Chủ chuyến, Id hoạt động, planId, Version kế hoạch, Decision Done/Undo |
| GET/POST `/Journey/Share` | Quản lý/tạo snapshot của chủ chuyến |
| POST `/Journey/Revoke` | Chủ chuyến, Id liên kết, Version, planId |
| GET `/Journey/Print?planId=&includeBudget=&includeServices=` | Bản in riêng, chủ chuyến |
| GET `/s/{token}` | Snapshot chỉ xem bằng token còn hiệu lực |
| GET `/Reviews/Mine`, GET `/Reviews/Write?bookingId=`, POST `/Reviews/Write` | Khách quản lý/viết đánh giá yêu cầu đủ điều kiện |
| GET `/Reviews/Service/{id}` | Nội dung và điểm đã duyệt của dịch vụ công khai, phân trang 20 |
| GET `/Reviews/Partner`, POST `/Reviews/Reply` | NCC sở hữu dịch vụ |
| GET `/Reviews/Moderation`, POST `/Reviews/Moderate` | Admin, phân trang/lọc trạng thái, duyệt/ẩn |
| GET `/Availability?serviceId=&month=&planId=` | Lịch tháng dịch vụ công khai; giữ ngữ cảnh chuyến của chủ khi có planId |
| GET `/Availability/Manage`, POST `/Availability/Save`, POST `/Availability/Remove` | NCC sở hữu dịch vụ, có kiểm tra phiên bản |

POST dùng CSRF; GET chỉ đọc. Sai chủ trả 404, sai vai trò 403, dữ liệu lỗi 400/422, phiên bản cũ 409. Truy cập công khai không được mở bản lịch/chia sẻ/đánh giá riêng bằng cách thay ID hay tham số.

## Hàm xử lý

| Service | Hàm và trách nhiệm |
|---|---|
| `JourneyService` | `Day` tải ngày của chủ chuyến; `Warnings` kiểm tra thời gian theo thứ tự; `Complete` cập nhật tiến độ có phiên bản; `Snapshot` chỉ chiếu trường được chia sẻ; `Shares/CreateShare/Revoke/PublicShare` quản lý snapshot, token, hạn và thu hồi |
| `ReviewService` | `Mine/Write` lọc quyền viết; `Save` ghi/sửa quay lại chờ duyệt; `PublicFeed` tổng hợp nội dung đã duyệt; `Manage` lọc/phân trang và giữ đúng dòng lỗi; `Reply` phản hồi của NCC sở hữu; `Moderate` duyệt hai phần độc lập |
| `AvailabilityService` | `Page` lịch tháng/chỉnh ngày; `Save/Remove` ghi hoặc đưa về chưa cập nhật; `LastServiceDay` phân biệt đêm lưu trú; `CheckNewRequest` chặn ngày tạm ngừng tại cả xem trước và giao dịch gửi |

Các thao tác ghi dùng giao dịch/kiểm tra nghiệp vụ chung của `TravelService`; không tạo đường ghi bỏ qua quyền/RowVersion. `LapKeHoachService` tiếp nhận thêm thời lượng tùy chọn, `DatDichVuService` gọi kiểm tra lịch tại cả hai bước. Các interface/hàm FullText nền được giữ.

## Kiểm chứng và bàn giao

Mọi ca ghi dùng `HoTroDuLich_Journey_20261105`, cổng 5222, khóa `preview/journey-test-keys`, tệp `preview/journey-test-uploads`; không chạy bộ ghi vào database chính. Build ứng dụng và công cụ kiểm chứng thành công, **0 lỗi, 0 cảnh báo**. Các kết quả JSON trong `tests/`:

Bản tổng hợp 14 bộ đạt: [journey-delivery-results.json](../tests/journey-delivery-results.json).

| Kết quả | Assertion đạt | Nội dung |
|---|---:|---|
| `journey-features-results.json` | 150 | Năm luồng mới; vòng đặt/xác nhận/kết quả thực; quyền sở hữu/vai trò, CSRF, RowVersion, gửi lặp, snapshot và lịch tạm ngừng |
| `journey-contract-results.json` | 1986 | C#/EF, hợp đồng nền, 91 action chuẩn và 19 điểm vào bổ sung |
| `journey-schema-results.json` | 1778 | SQL vật lý trên bản thử: kiểu/null/default, CHECK, PK/FK, unique/query index, view và cấu hình |
| `journey-main-schema-results.json` | 1778 | Cùng hồ sơ lược đồ trên database chính sau nâng cấp |
| `journey-database-permissions-results.json` | 29 | Quyền SQL bằng người dùng tạm WITHOUT LOGIN, rollback sau kiểm tra |
| `journey-trip-regression-results.json` | 82 | Luồng chuyến đi nền và giữ ngữ cảnh đặt dịch vụ |
| `journey-navigation-results.json` | 102 | Điều hướng, vai trò, giữ bộ lọc và render trang |
| `journey-smoke-results.json` | 41 | Trang nền theo vai trò và chặn sai vai trò |
| `journey-product-regression-results.json` | 90 | Hồi quy phần 003 trên database Journey |
| `journey-browser-results.json` | 174 | Biểu mẫu thật của ba vai trò; 15 màn hình × 5 kích thước; màu chữ, ảnh, tràn ngang và console |
| `journey-rehearsal-results.json` | 58 | Phục hồi bản sao riêng, nâng cấp mới/chạy lại và giữ dữ liệu cũ |
| `journey-upgrade-results.json` | 67 | Sao lưu, chạy 004 hai lần, quyền SQL, đối chiếu số dòng/SHA-256 trên toàn bộ cột cũ của 28 bảng |
| `journey-appdata-backup-results.json` | 22 | 21 tệp App_Data trong ZIP khớp số lượng và SHA-256 |
| `journey-startup-results.json` | 18 | Hai lệnh khởi động, 14 HTTP/resource checks; kiểm tra đọc bổ sung và trạng thái bàn giao |

Các con số là assertion của từng bộ, không phải số yêu cầu độc lập. UI kiểm tra 375×812, 768×1024, 1024×768, 1280×900 và 812×375. Không ghi nhận warning/error console trong lượt UI cuối. Kiểm tra nút in/CSS A4 không thay thế kiểm tra hộp thoại máy in của hệ điều hành; lưu PDF do người dùng chọn trong trình duyệt. Dịch vụ ngoài, giao thông trực tiếp, thanh toán, kho chỗ và push không được giả lập thành chức năng đã kết nối.

Đã sửa lỗi biểu mẫu hoạt động lấy nhầm mã kế hoạch từ route làm mã hoạt động; kiểm chứng riêng cả tạo và sửa. Luồng Hôm nay giữ thứ tự đã sắp xếp; cảnh báo giữ mốc kết thúc muộn nhất và xét cả qua ngày. Lỗi kiểm duyệt trỏ đúng dòng đang sửa, kể cả khi nội dung nằm ở trang khác; công bố không bắt nhập lý do, ẩn bắt buộc có lý do. Lưu lịch giữ ngày đang chỉnh; trang lịch công khai giữ ngữ cảnh chuyến và không hiện nút đặt cho NCC/Admin.

### Sao lưu và nâng cấp chính

SQL trước lúc áp dụng: `preview/backups/HoTroDuLich_before_journey_deploy_20261105_020630Z.bak`, **COPY_ONLY, CHECKSUM, RESTORE VERIFYONLY đạt**. App_Data: `preview/backups/App_Data_before_journey_deploy_20261105_090630.zip`; toàn bộ 21 tệp được so SHA-256 với bản gốc. Bản sao đầu đợt `HoTroDuLich_before_journey_20261105_023055.bak` đã được phục hồi vào database Journey với MDF/LDF riêng để diễn tập. Không phục hồi đè, xóa hay tạo lại database/instance chính.

Trong cửa sổ nâng cấp, cả 28 bảng cũ giữ nguyên số dòng và SHA-256 của mọi cột cũ; ba bảng mới rỗng, ba cột hoạt động mới đều NULL. Script 004 chạy lại thành công. Công cụ triển khai một lần `tools/UpgradeJourney.cjs --apply` ghi bằng chứng vào `journey-upgrade-results.json`; công cụ yêu cầu schema đầu vào 28/302 và không dùng để chạy lại trên bản 31/335 đã nâng cấp.

Một lượt quan sát chỉ đọc lúc 13:45, sau phiên `dotnet run` mới mở lúc 13:33, ghi nhận 8 bảng khác mốc sao lưu. Quan sát này được giữ tại `tests/journey-live-data-observation.json`, không dùng để suy nguyên nhân thay đổi hoặc thay thế đối chiếu trong cửa sổ nâng cấp. Không hoàn tác dữ liệu đang sử dụng để làm khớp ảnh chụp cũ.

Cả `start.ps1` và `start.ps1 -Dev` đã khởi động bản chính cổng 5216 và phục vụ trang/tài nguyên mới. Các tiến trình do agent tạo đã dừng, cổng thử 5222 đã giải phóng. Phiên `dotnet run` người dùng mở sau đó được giữ; trang chủ/lịch trả 200, pipe SQL đang kết nối được. Trong lượt kiểm tra sau đó, `SqlLocalDB info` báo Stopped trong khi tiến trình SQL và pipe thực vẫn hoạt động; không sửa registry, bảo mật hay dừng instance để xử lý sai khác quan sát này.

### Sử dụng và ảnh

Mở chuyến đi → **Hôm nay** hoặc **Chia sẻ / in**. Thời lượng/di chuyển ở biểu mẫu hoạt động. Khách vào Đặt dịch vụ → **Đánh giá**. NCC vào từng dịch vụ → **Lịch phục vụ** hoặc **Đánh giá**. Admin vào Duyệt & xác minh → **Kiểm duyệt đánh giá**.

```powershell
cd D:\KLTN
.\start.ps1 -Dev
```

Nếu website đang chạy tại [localhost:5216](http://localhost:5216), dùng phiên hiện có; dừng bằng Ctrl+C trong terminal của nó trước khi khởi động bản khác.

Ảnh dùng dữ liệu demo riêng ở database thử: [Hôm nay desktop](../preview/journey-today-desktop.png), [điện thoại](../preview/journey-today-mobile.png), [chia sẻ](../preview/journey-share-desktop.png), [bản snapshot](../preview/journey-public-snapshot.png), [lịch phục vụ](../preview/journey-calendar-desktop.png).
