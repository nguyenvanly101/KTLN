(() => {
 const toggle=document.querySelector('.menu-toggle');
 const navigation=document.querySelector(document.body.classList.contains('is-workspace')?'.workspace-sidebar':'.mainnav');
 const scrim=document.querySelector('.nav-scrim');
 const breakpoint=matchMedia(document.body.classList.contains('is-workspace')?'(max-width:1000px)':'(max-width:800px)');
 const updateAccessibility=()=>{if(navigation)navigation.inert=breakpoint.matches&&!navigation.classList.contains('open');};
 const closeMenu=()=>{navigation?.classList.remove('open');toggle?.setAttribute('aria-expanded','false');if(scrim)scrim.hidden=true;updateAccessibility();};
 toggle?.addEventListener('click',()=>{const open=navigation?.classList.toggle('open');toggle.setAttribute('aria-expanded',String(!!open));if(scrim)scrim.hidden=!open;updateAccessibility();});
 breakpoint.addEventListener('change',closeMenu);updateAccessibility();
 scrim?.addEventListener('click',closeMenu);
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){const wasOpen=navigation?.classList.contains('open');closeMenu();if(wasOpen)toggle?.focus();document.querySelectorAll('.account-menu[open]').forEach(x=>{x.removeAttribute('open');x.querySelector('summary')?.focus();});}});
 document.addEventListener('click',e=>{document.querySelectorAll('.account-menu[open]').forEach(menu=>{if(!menu.contains(e.target))menu.removeAttribute('open');});});
 document.querySelectorAll('.sidebar-nav a,.mainnav a').forEach(a=>a.addEventListener('click',closeMenu));
 document.querySelectorAll('.dismiss').forEach(b=>b.addEventListener('click',()=>b.closest('.toast-message').remove()));
 document.querySelectorAll('[data-email]').forEach(b=>b.addEventListener('click',()=>{document.querySelector('[name="Email"]').value=b.dataset.email;document.querySelector('[name="Password"]').value='HanhTrinh@2026';}));
 document.querySelectorAll('[data-confirm]').forEach(f=>f.addEventListener('submit',e=>{if(!confirm(f.dataset.confirm))e.preventDefault();}));
 document.querySelectorAll('[data-back]').forEach(b=>b.addEventListener('click',()=>history.back()));
 document.querySelectorAll('[data-password-target]').forEach(b=>b.addEventListener('click',()=>{const input=document.getElementById(b.dataset.passwordTarget);const reveal=input.type==='password';input.type=reveal?'text':'password';b.textContent=reveal?'Ẩn':'Hiện';b.setAttribute('aria-label',reveal?'Ẩn mật khẩu':'Hiển thị mật khẩu');}));
 const role=document.querySelector('[data-account-role]');
 const updateRole=()=>{const provider=role?.value==='NHA_CUNG_CAP';document.querySelectorAll('[data-provider-fields]').forEach(e=>e.hidden=!provider);['Organization','Address','OrganizationType','ContactName','ContactPhone','ContactEmail','RegistrationDescription','Representative','Documents'].forEach(name=>{const input=document.querySelector('[name="'+name+'"]');if(input)input.required=provider;});};
 role?.addEventListener('change',updateRole);if(role)updateRole();
 document.querySelectorAll('.tabs').forEach(nav=>{const current=location.pathname.replace(/\/$/,'').toLowerCase();const match=[...nav.querySelectorAll('a')].find(a=>new URL(a.href).pathname.replace(/\/$/,'').toLowerCase()===current);if(match){nav.querySelectorAll('a').forEach(a=>{a.classList.remove('active');a.removeAttribute('aria-current');});match.classList.add('active');match.setAttribute('aria-current','page');}});
 document.querySelectorAll('.sidebar-nav a.active,.mainnav a.active').forEach(a=>a.setAttribute('aria-current','page'));
})();
(() => {
 const data=document.getElementById('rejected-input');
 if(data){try{const values=JSON.parse(data.textContent);const id=values.Id?.[0];for(const form of document.querySelectorAll('form[method="post"]')){if(id&&form.querySelector('[name="Id"]')?.value!==id)continue;for(const [key,list] of Object.entries(values)){for(const input of form.elements){if(input.name!==key||['hidden','file','password','submit'].includes(input.type))continue;if(input.type==='checkbox'||input.type==='radio')input.checked=list.includes(input.value);else if(input.tagName==='SELECT'&&input.multiple)for(const option of input.options)option.selected=list.includes(option.value);else input.value=list[0]??'';}}}}catch{}}
 const summary=document.querySelector('.validation-summary-errors');
 if(summary){summary.setAttribute('role','alert');summary.tabIndex=-1;summary.focus();}
})();
