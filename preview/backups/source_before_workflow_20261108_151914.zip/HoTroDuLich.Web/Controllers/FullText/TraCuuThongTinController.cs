using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using HoTroDuLich.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.RateLimiting;
namespace HoTroDuLich.Web.Controllers;
public class TraCuuThongTinController(ITimKiemThongTinService component,TravelService read,DiscoveryService discovery):FullTextController<ITimKiemThongTinService>(component,read) {
 [AllowAnonymous,HttpGet("/thong-tin/mo-tim-kiem")]
 public async Task<IActionResult> MoTimKiem([ValidateNever] TraCuuThongTinViewModel query) { await LoadTripContext(query.PlanId);await C.MoTimKiemAsync();await C.TraCuuAsync(null,null,null,null,null);return V("Discovery/Search",await discovery.Search(new(){PlanId=query.PlanId})); }
 [AllowAnonymous,HttpGet("/thong-tin/tra-cuu")]
 public async Task<IActionResult> TraCuu([ValidateNever] TraCuuThongTinViewModel query) { await LoadTripContext(query.PlanId);await C.MoTimKiemAsync();await C.TraCuuAsync(query.TuKhoa,query.KhuVuc,query.Loai,query.GiaTu,query.GiaDen,query.Trang);return V("Discovery/Search",await discovery.Search(new(){Q=query.TuKhoa,Region=query.KhuVuc,Type=query.Loai,Min=query.GiaTu,Max=query.GiaDen,Page=query.Trang,PlanId=query.PlanId})); }
}
