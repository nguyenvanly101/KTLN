/* Google Maps loads on pages that use a map; server credentials never enter this module. */
(() => {
 'use strict';
 let configPromise, loadPromise;
 async function config() {
  if (!configPromise) configPromise = fetch('/api/maps/config', {cache:'no-store', credentials:'same-origin'})
   .then(r => { if (!r.ok) throw new Error('Chưa đọc được cấu hình bản đồ.'); return r.json(); });
  return configPromise;
 }
 async function load() {
  if (window.google?.maps?.importLibrary) return window.google.maps;
  if (!loadPromise) loadPromise = (async () => {
   const c = await config();
   if (!c.mapsReady) throw new Error('Bản đồ Google chưa sẵn sàng. Các thông tin trong danh sách vẫn có thể sử dụng.');
   await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('Google Maps phản hồi chậm. Vui lòng thử tải lại trang.')), 15000);
    window.htGoogleMapsReady = () => { clearTimeout(timer); resolve(); };
    window.gm_authFailure = () => { clearTimeout(timer); reject(new Error('Google Maps chưa được kích hoạt cho website này.')); window.dispatchEvent(new Event('ht-map-unavailable')); };
    const script = document.createElement('script');
    const url = new URL('https://maps.googleapis.com/maps/api/js');
    url.search = new URLSearchParams({key:c.browserKey, v:'weekly', loading:'async', callback:'htGoogleMapsReady', language:'vi', region:'VN'}).toString();
    script.src = url.href; script.async = true; script.referrerPolicy = 'strict-origin-when-cross-origin';
    script.nonce = document.querySelector('meta[name="maps-nonce"]')?.content || '';
    script.onerror = () => {clearTimeout(timer); reject(new Error('Chưa kết nối được Google Maps.'));};
    document.head.append(script);
   });
   await Promise.all([google.maps.importLibrary('maps'),google.maps.importLibrary('marker'),google.maps.importLibrary('geometry')]);
   return google.maps;
  })();
  return loadPromise;
 }
 async function create(element, position, zoom=15) {
  const [maps,c] = await Promise.all([load(),config()]);
  element.replaceChildren();
  return new maps.Map(element, {mapId:c.mapId, center:position || {lat:16.46,lng:107.58}, zoom:position?zoom:6, mapTypeControl:false, streetViewControl:false, gestureHandling:'cooperative', clickableIcons:false});
 }
 function marker(map,position,title,kind='branch',onClick) {
  const pin = document.createElement('span'); pin.className='pl-map-pin pl-map-pin-'+kind;
  pin.textContent=kind==='anchor'?'●':kind==='google'?'G':'●';
  const m = new google.maps.marker.AdvancedMarkerElement({map,position,content:pin,title});
  if (onClick) m.addListener('click',onClick);
  return m;
 }
 function showFailure(element,error) {
  const box=document.createElement('div');box.className='pl-map-fallback';
  const title=document.createElement('strong');title.textContent='Google Maps';
  const description=document.createElement('p');description.textContent=error.message||'Bản đồ chưa sẵn sàng.';
  box.append(title,description);element.replaceChildren(box);
 }
 window.HanhTrinhMaps={config,load,create,marker,showFailure};
})();
