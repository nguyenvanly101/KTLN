(() => {
 'use strict';
 const maps=window.HanhTrinhMaps;
 window.addEventListener('ht-map-unavailable',()=>{document.querySelectorAll('[data-location-map],[data-point-map],[data-search-map]').forEach(canvas=>maps.showFailure(canvas,new Error('Google Maps chưa được kích hoạt cho website này. Bạn vẫn có thể xem thông tin và liên kết địa điểm.')));});
 const number=v=>v==null||v===''?null:(Number.isFinite(Number(v))?Number(v):null);
 const pos=v=>v&&number(v.lat)!=null&&number(v.lng)!=null?{lat:Number(v.lat),lng:Number(v.lng)}:null;
 const set=(form,name,value)=>{const e=form.elements.namedItem(name);if(e)e.value=value??'';};
 const message=(el,text)=>{if(el)el.textContent=text;};
 const uuid=()=>window.crypto?.randomUUID?.() || '10000000-1000-4000-8000-100000000000'.replace(/[018]/g,c=>(c^crypto.getRandomValues(new Uint8Array(1))[0]&15>>c/4).toString(16));

 function autocomplete(root,onSelect) {
  const input=root.querySelector('input[type="search"]'),list=root.querySelector('[role="listbox"]'),status=root.querySelector('[data-autocomplete-status]');
  if(!input||!list)return;
  list.id='places-suggestions-'+uuid();input.setAttribute('aria-controls',list.id);
  let session=uuid(),timer,abort,items=[],active=-1;
  const close=()=>{list.hidden=true;input.setAttribute('aria-expanded','false');input.removeAttribute('aria-activedescendant');active=-1;};
  const choose=async index=>{const item=items[index];if(!item)return;close();input.value=item.name;message(status,'');try{await onSelect(item,session);session=uuid();}catch(e){message(status,e.message);}};
  function highlight(index){const options=[...list.querySelectorAll('[role="option"]')];if(!options.length)return;active=(index+options.length)%options.length;options.forEach((b,i)=>b.setAttribute('aria-selected',String(i===active)));input.setAttribute('aria-activedescendant',options[active].id);options[active].scrollIntoView({block:'nearest'});}
  input.addEventListener('input',()=>{
   clearTimeout(timer);abort?.abort();close();
   if(input.value.trim().length<2){message(status,'Nhập ít nhất hai ký tự để tìm địa điểm.');return;}
   timer=setTimeout(async()=>{
    abort=new AbortController();const captured=input.value.trim();
    try{
     message(status,'Đang tìm địa điểm…');
     const url=new URL('/api/maps/suggest',location.origin);url.search=new URLSearchParams({q:captured,session,googleOnly:String(root.dataset.autocomplete==='location')});
     const r=await fetch(url,{signal:abort.signal,cache:'no-store'});
     if(!r.ok)throw new Error(r.status===429?'Bạn tìm hơi nhanh. Chờ một lát rồi thử lại.':'Chưa lấy được gợi ý địa điểm.');
     const data=await r.json();if(input.value.trim()!==captured)return;
     items=data.items||[];list.replaceChildren();
     items.forEach((item,i)=>{const b=document.createElement('button');b.type='button';b.id=list.id+'-'+i;b.setAttribute('role','option');b.setAttribute('aria-selected','false');b.tabIndex=-1;const name=document.createElement('strong'),address=document.createElement('span'),source=document.createElement('small');name.textContent=item.name;address.textContent=item.address;source.textContent=item.source;b.append(name,address,source);b.addEventListener('mousedown',e=>e.preventDefault());b.addEventListener('click',()=>choose(i));list.append(b);});
     if(items.some(x=>x.source==='Google')){const attribution=document.createElement('div');attribution.className='pl-google-attribution';attribution.textContent='Google Maps';attribution.translate=false;list.append(attribution);}
     list.hidden=items.length===0;input.setAttribute('aria-expanded',String(items.length>0));message(status,data.notice||(!items.length?'Chưa có kết quả. Thử thêm địa chỉ hoặc chọn ghim trên bản đồ.':''));
    }catch(e){if(e.name!=='AbortError')message(status,e.message);}
   },450);
  });
  input.addEventListener('keydown',e=>{if(e.key==='Escape')close();else if(e.key==='ArrowDown'&&!list.hidden){e.preventDefault();highlight(active+1);}else if(e.key==='ArrowUp'&&!list.hidden){e.preventDefault();highlight(active-1);}else if(e.key==='Enter'&&!list.hidden&&active>=0){e.preventDefault();choose(active);}});
  input.addEventListener('blur',()=>setTimeout(close,150));
 }

 document.querySelectorAll('[data-location-picker]').forEach(async root=>{
  const form=root.closest('form'),canvas=root.querySelector('[data-location-map]'),status=root.querySelector('[data-map-status]');
  const lat=form.elements.namedItem('Latitude'),lng=form.elements.namedItem('Longitude');let map,pin;
  const current=()=>number(lat.value)!=null&&number(lng.value)!=null?{lat:Number(lat.value),lng:Number(lng.value)}:null;
  function mark(position,manual){if(!position)return;if(pin)pin.map=null;if(map){pin=maps.marker(map,position,'Vị trí bạn xác nhận','anchor');map.panTo(position);map.setZoom(17);}if(manual){set(form,'LocationSource','Provider');form.elements.namedItem('ConfirmLocation').checked=false;message(status,'Ghim do bạn cung cấp. Kiểm tra đúng điểm phục vụ trước khi xác nhận.');}}
  const ac=root.querySelector('[data-autocomplete]');
  autocomplete(ac,async(item,session)=>{
   const r=await fetch('/api/maps/place?'+new URLSearchParams({id:item.id,session}),{cache:'no-store'});const data=await r.json();if(!r.ok)throw new Error(data.message||'Chưa đọc được địa điểm Google.');
   const position=pos(data.position);if(!position)throw new Error('Địa điểm chưa có vị trí.');
   set(form,'GooglePlaceId',data.id);set(form,'LocationSource','Google');lat.value=position.lat;lng.value=position.lng;mark(position,false);
   form.elements.namedItem('ConfirmLocation').checked=false;
   const box=root.querySelector('[data-selected-place]');box.replaceChildren();const strong=document.createElement('strong'),p=document.createElement('p'),a=document.createElement('a');strong.textContent=data.name;p.textContent=data.address;a.textContent='Đối chiếu địa điểm trên Google Maps';a.href=data.mapsUrl;a.target='_blank';a.rel='noopener noreferrer';box.append(strong,p,a);
   message(status,'Đã chọn địa điểm Google. Điền tên và địa chỉ hồ sơ do bạn cung cấp, rồi kiểm tra đúng cơ sở.');
  });
  [lat,lng].forEach(input=>input.addEventListener('change',()=>mark(current(),true)));
  try{map=await maps.create(canvas,current());if(current())mark(current(),false);map.addListener('click',e=>{if(form.querySelector('fieldset:disabled'))return;if(e.latLng){lat.value=e.latLng.lat().toFixed(6);lng.value=e.latLng.lng().toFixed(6);mark(current(),true);}});}catch(e){maps.showFailure(canvas,e);message(status,'Có thể cung cấp tọa độ thủ công hoặc mở Google Maps để đối chiếu vị trí.');}
 });

 document.querySelectorAll('[data-point-map]').forEach(async canvas=>{try{const position={lat:Number(canvas.dataset.lat),lng:Number(canvas.dataset.lng)};const map=await maps.create(canvas,position);maps.marker(map,position,document.title,'anchor');}catch(e){maps.showFailure(canvas,e);}});

 const page=document.querySelector('[data-place-search]');if(!page)return;
 const form=page.querySelector('[data-place-search-form]'),anchorInput=page.querySelector('#anchor-query'),locationStatus=page.querySelector('[data-search-location-status]');
 let selectedAnchorName=anchorInput.value;
 function clearAnchor(){['AnchorKind','AnchorId','GooglePlaceId','AnchorName','Lat','Lng'].forEach(k=>set(form,k,''));anchorInput.value='';selectedAnchorName='';}
 autocomplete(page.querySelector('[data-autocomplete="anchor"]'),async(item,session)=>{
  if(item.source==='Google'){
   // Complete the autocomplete session with Place Details before applying the chosen anchor.
   const r=await fetch('/api/maps/place?'+new URLSearchParams({id:item.id,session}),{cache:'no-store'});const detail=await r.json();if(!r.ok)throw new Error(detail.message||'Chưa xác định được địa điểm Google.');
   item={...item,name:detail.name,address:detail.address};
  }
  set(form,'AnchorKind',item.source==='Google'?'Google':item.source==='Cơ sở dịch vụ'?'Branch':'Landmark');set(form,'AnchorId',item.localId);set(form,'GooglePlaceId',item.id);set(form,'AnchorName',item.name);set(form,'Lat','');set(form,'Lng','');selectedAnchorName=item.name;
  message(locationStatus,'Đã chọn mốc '+item.name+'. Chọn thứ cần tìm rồi bấm Tìm quanh mốc.');
 });
 anchorInput.addEventListener('input',()=>{if(anchorInput.value!==selectedAnchorName){['AnchorKind','AnchorId','GooglePlaceId','AnchorName','Lat','Lng'].forEach(k=>set(form,k,''));}});
 page.querySelector('[data-clear-anchor]').addEventListener('click',()=>{clearAnchor();message(locationStatus,'Đã bỏ mốc. Bạn có thể xem tất cả cơ sở hoặc chọn mốc mới.');anchorInput.focus();});
 form.addEventListener('submit',e=>{if(anchorInput.value.trim()&&!form.elements.namedItem('AnchorKind').value){e.preventDefault();message(locationStatus,'Chọn một địa điểm trong gợi ý để xác định đúng mốc, hoặc đặt ghim trên bản đồ.');anchorInput.focus();}});
 page.querySelector('[data-use-my-location]').addEventListener('click',()=>{
  if(!navigator.geolocation){message(locationStatus,'Trình duyệt chưa hỗ trợ vị trí. Chọn mốc hoặc ghim thủ công.');return;}
  message(locationStatus,'Đang xác định vị trí của bạn…');
  navigator.geolocation.getCurrentPosition(p=>{clearAnchor();set(form,'AnchorKind','Pin');set(form,'Lat',p.coords.latitude.toFixed(6));set(form,'Lng',p.coords.longitude.toFixed(6));set(form,'AnchorName','Vị trí của tôi');anchorInput.value=selectedAnchorName='Vị trí của tôi';form.requestSubmit();},()=>message(locationStatus,'Chưa lấy được vị trí. Bạn có thể chọn địa điểm hoặc đặt ghim trên bản đồ.'),{timeout:10000,maximumAge:60000});
 });
 const compare=[...page.querySelectorAll('[data-compare-branch]')],compareStatus=page.querySelector('[data-compare-status]');
 compare.forEach(input=>input.addEventListener('change',()=>{const selected=compare.filter(x=>x.checked);if(selected.length>3){input.checked=false;message(compareStatus,'Chọn tối đa 3 cơ sở.');}else{message(compareStatus,'');message(page.querySelector('[data-compare-count]'),`(${selected.length}/3)`);}}));
 page.querySelector('#compare-branches').addEventListener('submit',e=>{if(!compare.some(x=>x.checked)){e.preventDefault();message(compareStatus,'Chọn ít nhất một cơ sở để so sánh.');}});
 const scrollKey='places-scroll:'+location.pathname+location.search;
 try{const saved=sessionStorage.getItem(scrollKey);if(saved)requestAnimationFrame(()=>window.scrollTo(0,Number(saved)));}catch{}
 page.querySelectorAll('a[href^="/co-so/"]').forEach(a=>{const u=new URL(a.href);u.searchParams.set('returnUrl',location.pathname+location.search);a.href=u.pathname+u.search;a.addEventListener('click',()=>{try{sessionStorage.setItem(scrollKey,String(window.scrollY));}catch{}});});

 const canvas=page.querySelector('[data-search-map]'),mapStatus=page.querySelector('[data-search-map-status]'),routePanel=page.querySelector('[data-route-panel]');
 let payload;try{payload=JSON.parse(page.querySelector('[data-places-payload]').textContent);}catch{return;}
 const hits=payload.hits||[],anchor=payload.anchor,markers=new Map();let map,line,selectedPin;
 const toggle=page.querySelector('[data-toggle-map]');
 toggle.addEventListener('click',()=>{const show=page.classList.toggle('pl-show-map');toggle.setAttribute('aria-expanded',String(show));toggle.textContent=show?'Xem danh sách':'Xem bản đồ';});
 function select(key,fromMarker=false){const h=hits.find(x=>x.key===key);if(!h)return;page.querySelectorAll('[data-result-key]').forEach(c=>c.classList.toggle('is-selected',c.dataset.resultKey===key));if(map&&pos(h.position)){map.panTo(pos(h.position));map.setZoom(16);}message(mapStatus,h.name+' · '+h.address);if(fromMarker){if(matchMedia('(max-width:900px)').matches){page.classList.remove('pl-show-map');toggle.setAttribute('aria-expanded','false');toggle.textContent='Xem bản đồ';}page.querySelector(`[data-result-key="${CSS.escape(key)}"]`)?.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'nearest'});}}
 page.querySelectorAll('[data-show-on-map]').forEach(b=>b.addEventListener('click',()=>{select(b.dataset.showOnMap);page.classList.add('pl-show-map');toggle.setAttribute('aria-expanded','true');toggle.textContent='Xem danh sách';canvas.scrollIntoView({block:'nearest'});}));
 page.querySelectorAll('[data-route-to]').forEach(b=>b.addEventListener('click',async()=>{
  const h=hits.find(x=>x.key===b.dataset.routeTo);if(!h||!anchor||!pos(h.position))return;
  select(h.key);b.disabled=true;routePanel.hidden=false;message(routePanel,'Đang tìm đường đến '+h.name+'…');
  try{
   const c=await maps.config();if(!c.placesReady)throw new Error('Xem đường trong website chưa sẵn sàng. Bạn có thể mở vị trí cơ sở trên Google Maps.');
   const r=await fetch('/api/maps/route',{method:'POST',headers:{'Content-Type':'application/json','RequestVerificationToken':page.querySelector('[data-route-token] input').value},body:JSON.stringify({originLat:anchor.position.lat,originLng:anchor.position.lng,destinationLat:h.position.lat,destinationLng:h.position.lng,mode:payload.mode})});
   if(r.status===429)throw new Error('Bạn yêu cầu đường đi hơi nhanh. Chờ một lát rồi thử lại.');const data=await r.json();if(!r.ok)throw new Error(data.message||'Chưa tìm được đường đi.');
   if(map){if(line)line.setMap(null);line=new google.maps.Polyline({path:google.maps.geometry.encoding.decodePath(data.encodedPolyline),strokeColor:'#2447e8',strokeOpacity:.9,strokeWeight:5,map});const bounds=new google.maps.LatLngBounds();line.getPath().forEach(p=>bounds.extend(p));map.fitBounds(bounds,45);}
   routePanel.replaceChildren();const strong=document.createElement('strong'),p=document.createElement('p');strong.textContent=anchor.name+' → '+h.name;p.textContent=(data.distanceMeters/1000).toFixed(1)+' km đường đi · khoảng '+Math.ceil(data.durationSeconds/60)+' phút. Thời gian ước tính theo phương thức đã chọn.';routePanel.append(strong,p);(data.warnings||[]).forEach(w=>{const note=document.createElement('small');note.textContent=w;routePanel.append(note);});
  }catch(e){message(routePanel,e.message);}finally{b.disabled=false;}
 }));
 function choosePin(position,title){clearAnchor();set(form,'AnchorKind','Pin');set(form,'Lat',position.lat.toFixed(6));set(form,'Lng',position.lng.toFixed(6));set(form,'AnchorName',title);anchorInput.value=selectedAnchorName=title;if(selectedPin)selectedPin.map=null;selectedPin=maps.marker(map,position,title,'anchor');message(locationStatus,'Đã chọn mốc mới. Bấm Tìm quanh mốc để áp dụng.');}
 page.querySelector('[data-search-map-center]').addEventListener('click',()=>{if(!map){message(mapStatus,'Bản đồ chưa sẵn sàng. Hãy chọn mốc bằng tên hoặc dùng vị trí của bạn.');return;}const c=map.getCenter();choosePin({lat:c.lat(),lng:c.lng()},'Tâm bản đồ đã chọn');form.requestSubmit();});
 (async()=>{
  try{
   map=await maps.create(canvas,pos(anchor?.position)||pos(hits.find(x=>x.position)?.position));const bounds=new google.maps.LatLngBounds();let count=0;
   if(anchor){maps.marker(map,pos(anchor.position),anchor.name,'anchor');bounds.extend(pos(anchor.position));count++;}
   hits.forEach(h=>{const position=pos(h.position);if(!position)return;markers.set(h.key,maps.marker(map,position,h.name,h.source==='Google'?'google':'branch',()=>select(h.key,true)));bounds.extend(position);count++;});
   if(count>1)map.fitBounds(bounds,45);else if(count===1)map.setZoom(15);
   map.addListener('click',e=>{if(e.latLng)choosePin({lat:e.latLng.lat(),lng:e.latLng.lng()},'Ghim trên bản đồ');});
  }catch(e){maps.showFailure(canvas,e);message(mapStatus,e.message);}
 })();
})();
