using System.ComponentModel.DataAnnotations;
namespace HoTroDuLich.Web.Domain;
public class TaiKhoan
{
 public long MaTaiKhoan { get; set; }
 public string Email { get; set; } = "";
 public string? SoDienThoai { get; set; }
 public string MatKhauBam { get; set; } = "";
 public string VaiTro { get; set; } = "";
 public string TrangThai { get; set; } = "";
 public Guid DauPhien { get; set; } = Guid.NewGuid();
 public bool PhaiDoiMatKhau { get; set; }
 public DateTime ThoiDiemTao { get; set; } = DateTime.UtcNow;
 public DateTime? ThoiDiemDangNhapCuoi { get; set; }
 public DateTime? ThoiDiemNgung { get; set; }
 public byte[] RowVersion { get; set; } = [];
}
public class HoSoNguoiDung
{
 public long MaHoSo { get; set; }
 public long MaTaiKhoan { get; set; }
 public string TenHienThi { get; set; } = "";
 public string? AnhDaiDien { get; set; }
 public string? GioiThieu { get; set; }
 public string? NoiSinhSong { get; set; }
 public string? SoThich { get; set; }
 public string ThongTinChiaSe { get; set; } = "";
 public DateTime ThoiDiemCapNhat { get; set; } = DateTime.UtcNow;
 public byte[] RowVersion { get; set; } = [];
}
public class NhaCungCapDichVu
{
 public long MaNhaCungCap { get; set; }
 public long MaTaiKhoan { get; set; }
 public string TenDonVi { get; set; } = "";
 public string LoaiHinh { get; set; } = "";
 public string NguoiLienHe { get; set; } = "";
 public string DiaChi { get; set; } = "";
 public string SoDienThoai { get; set; } = "";
 public string EmailLienHe { get; set; } = "";
 public string TrangThaiXacMinh { get; set; } = "";
 public string? TrangThaiQuyenHoatDong { get; set; }
 public DateTime ThoiDiemTao { get; set; } = DateTime.UtcNow;
 public byte[] RowVersion { get; set; } = [];
}
public class HoSoXacMinhNhaCungCap
{
 public long MaHoSo { get; set; }
 public long MaNhaCungCap { get; set; }
 public string NoiDungDangKy { get; set; } = "";
 public string NguoiDaiDien { get; set; } = "";
 public DateTime ThoiDiemNop { get; set; } = DateTime.UtcNow;
 public int SoLanBoSung { get; set; }
 public string TrangThaiXuLy { get; set; } = "";
 public byte[] RowVersion { get; set; } = [];
}
public class QuyetDinhXacMinh
{
 public long MaQuyetDinh { get; set; }
 public long MaHoSo { get; set; }
 public int LanXuLy { get; set; }
 public string KetQua { get; set; } = "";
 public string? KetQuaXacMinh { get; set; }
 public string? LyDo { get; set; }
 public long MaAdminDuyet { get; set; }
 public DateTime ThoiDiemDuyet { get; set; } = DateTime.UtcNow;
}
public class TaiLieuXacMinh
{
 public long MaTaiLieu { get; set; }
 public long MaHoSo { get; set; }
 public string TenTepGoc { get; set; } = "";
 public string DuongDan { get; set; } = "";
 public string LoaiTep { get; set; } = "";
 public int KichThuoc { get; set; }
 public int LanNop { get; set; }
 public DateTime ThoiDiemTai { get; set; } = DateTime.UtcNow;
}
public class QuyetDinhQuyenHoatDong
{
 public long MaQuyetDinh { get; set; }
 public long MaNhaCungCap { get; set; }
 public string TrangThaiTruoc { get; set; } = "";
 public string TrangThaiSau { get; set; } = "";
 public string LyDo { get; set; } = "";
 public string CanCu { get; set; } = "";
 public DateOnly? ThoiHan { get; set; }
 public long MaAdmin { get; set; }
 public DateTime ThoiDiem { get; set; } = DateTime.UtcNow;
}
public class GiaiTrinhNhaCungCap
{
 public long MaGiaiTrinh { get; set; }
 public long MaQuyetDinh { get; set; }
 public string NoiDung { get; set; } = "";
 public DateTime ThoiDiemGui { get; set; } = DateTime.UtcNow;
 public string TrangThai { get; set; } = "";
 public string? KetQuaXemXet { get; set; }
 public long? MaAdminXemXet { get; set; }
 public DateTime? ThoiDiemXemXet { get; set; }
}
public class TaiLieuGiaiTrinh
{
 public long MaTaiLieu { get; set; }
 public long MaGiaiTrinh { get; set; }
 public string TenTepGoc { get; set; } = "";
 public string DuongDan { get; set; } = "";
 public string LoaiTep { get; set; } = "";
 public int KichThuoc { get; set; }
 public DateTime ThoiDiemTai { get; set; } = DateTime.UtcNow;
}
public class DiaDiemDuLich
{
 public long MaDiaDiem { get; set; }
 public string TenDiaDiem { get; set; } = "";
 public string LoaiDiaDiem { get; set; } = "";
 public string KhuVuc { get; set; } = "";
 public string? DiaChi { get; set; }
 public string? MoTa { get; set; }
 public bool DangHienThi { get; set; }
}
public class DichVuDuLich
{
 public long MaDichVu { get; set; }
 public long MaNhaCungCap { get; set; }
 public string TenDichVu { get; set; } = "";
 public string LoaiDichVu { get; set; } = "";
 public string? MoTa { get; set; }
 public string KhuVucPhucVu { get; set; } = "";
 public long? MaDiaDiem { get; set; }
 public decimal? GiaThamKhao { get; set; }
 public string? ThoiGianPhucVu { get; set; }
 public string? DieuKienPhucVu { get; set; }
 public DateOnly? TamNgungTu { get; set; }
 public DateOnly? TamNgungDen { get; set; }
 public string? LyDoTamNgung { get; set; }
 public string TrangThaiCongBo { get; set; } = "";
 public string TrangThaiTiepNhan { get; set; } = "";
 public long? MaQuyetDinhKhongTiepNhan { get; set; }
 public int? PhienBanCongBo { get; set; }
 public DateTime ThoiDiemTao { get; set; } = DateTime.UtcNow;
 public DateTime ThoiDiemCapNhat { get; set; } = DateTime.UtcNow;
 public byte[] RowVersion { get; set; } = [];
}
public class BanCapNhatDichVu
{
 public long MaBanCapNhat { get; set; }
 public long MaDichVu { get; set; }
 public int SoPhienBan { get; set; }
 public string TenDichVu { get; set; } = "";
 public string LoaiDichVu { get; set; } = "";
 public string? MoTa { get; set; }
 public string KhuVucPhucVu { get; set; } = "";
 public long? MaDiaDiem { get; set; }
 public decimal? GiaThamKhao { get; set; }
 public string? ThoiGianPhucVu { get; set; }
 public string? DieuKienPhucVu { get; set; }
 public DateOnly? TamNgungTu { get; set; }
 public DateOnly? TamNgungDen { get; set; }
 public string? LyDoTamNgung { get; set; }
 public string TrangThaiDuyet { get; set; } = "";
 public string? LyDo { get; set; }
 public long? MaAdminDuyet { get; set; }
 public DateTime ThoiDiemGui { get; set; } = DateTime.UtcNow;
 public DateTime? ThoiDiemDuyet { get; set; }
}
public class KeHoachChuyenDi
{
 public long MaKeHoach { get; set; }
 public long MaTaiKhoan { get; set; }
 public string TenKeHoach { get; set; } = "";
 public string NoiDen { get; set; } = "";
 public DateOnly NgayBatDau { get; set; }
 public DateOnly NgayKetThuc { get; set; }
 public decimal? NganSachDuKien { get; set; }
 public string TrangThai { get; set; } = "";
 public DateTime ThoiDiemTao { get; set; } = DateTime.UtcNow;
 public DateTime ThoiDiemCapNhat { get; set; } = DateTime.UtcNow;
 public byte[] RowVersion { get; set; } = [];
}
public class HoatDongLichTrinh
{
 public long MaHoatDong { get; set; }
 public long MaKeHoach { get; set; }
 public DateOnly Ngay { get; set; }
 public TimeOnly? Gio { get; set; }
 public int ThuTu { get; set; }
 public long? MaDiaDiem { get; set; }
 public long? MaDichVu { get; set; }
 public string NoiDung { get; set; } = "";
 public decimal? ChiPhiDuKien { get; set; }
}
public class TinhHuongPhatSinh
{
 public long MaTinhHuong { get; set; }
 public long MaKeHoach { get; set; }
 public string LoaiTinhHuong { get; set; } = "";
 public string MoTa { get; set; } = "";
 public string? ViTri { get; set; }
 public DateTime ThoiDiemGhiNhan { get; set; } = DateTime.UtcNow;
 public string TrangThaiXuLy { get; set; } = "";
 public string? KetQuaXuLy { get; set; }
 public DateTime ThoiDiemCapNhat { get; set; } = DateTime.UtcNow;
 public byte[] RowVersion { get; set; } = [];
}
public class TinhHuongHoatDong
{
 public long MaTinhHuong { get; set; }
 public long MaHoatDong { get; set; }
}
public class PhuongAnXuLy
{
 public long MaPhuongAn { get; set; }
 public long MaTinhHuong { get; set; }
 public string NoiDung { get; set; } = "";
 public DateTime ThoiDiemChon { get; set; } = DateTime.UtcNow;
 public bool LaHienHanh { get; set; }
}
public class NhuCauDongHanh
{
 public long MaNhuCau { get; set; }
 public long MaTaiKhoan { get; set; }
 public string NoiDung { get; set; } = "";
 public string DiemDen { get; set; } = "";
 public DateOnly NgayBatDau { get; set; }
 public DateOnly NgayKetThuc { get; set; }
 public decimal? NganSachDuKien { get; set; }
 public string? HinhThucDi { get; set; }
 public string? MongMuonDongHanh { get; set; }
 public string PhamViChiaSe { get; set; } = "";
 public DateTime ThoiDiemDang { get; set; } = DateTime.UtcNow;
 public string TrangThaiCongBo { get; set; } = "";
 public byte[] RowVersion { get; set; } = [];
}
public class DeNghiKetNoiDongHanh
{
 public long MaDeNghi { get; set; }
 public long MaNhuCau { get; set; }
 public long MaNguoiGui { get; set; }
 public string? LoiGioiThieu { get; set; }
 public DateTime ThoiDiemGui { get; set; } = DateTime.UtcNow;
 public DateTime? ThoiDiemPhanHoi { get; set; }
 public string TrangThai { get; set; } = "";
 public byte[] RowVersion { get; set; } = [];
}
public class ThoaThuanDongHanh
{
 public long MaThoaThuan { get; set; }
 public long MaDeNghi { get; set; }
 public int PhienBan { get; set; }
 public DateOnly NgayDi { get; set; }
 public DateOnly NgayVe { get; set; }
 public string NoiDen { get; set; } = "";
 public decimal? NganSach { get; set; }
 public string? PhamViDiCung { get; set; }
 public long MaNguoiDeXuat { get; set; }
 public DateTime ThoiDiemDeXuat { get; set; } = DateTime.UtcNow;
 public long? MaNguoiXacNhan { get; set; }
 public DateTime? ThoiDiemXacNhan { get; set; }
 public string LoaiPhienBan { get; set; } = "";
 public string TrangThai { get; set; } = "";
 public string? LyDo { get; set; }
 public long? MaNguoiKetThuc { get; set; }
 public DateTime? ThoiDiemKetThuc { get; set; }
 public byte[] RowVersion { get; set; } = [];
}
public class YeuCauDatDichVu
{
 public long MaYeuCau { get; set; }
 public long MaTaiKhoan { get; set; }
 public long MaDichVu { get; set; }
 public DateOnly NgayBatDau { get; set; }
 public DateOnly? NgayKetThuc { get; set; }
 public string? ThoiGianDenDi { get; set; }
 public int SoNguoi { get; set; }
 public int SoLuong { get; set; }
 public string? NoiDungLuaChon { get; set; }
 public string? GhiChu { get; set; }
 public decimal? ChiPhiDuKien { get; set; }
 public string? DieuKienDeXuat { get; set; }
 public int PhienBan { get; set; }
 public DateTime ThoiDiemGui { get; set; } = DateTime.UtcNow;
 public DateTime? ThoiDiemPhanHoi { get; set; }
 public string? LyDo { get; set; }
 public string TrangThai { get; set; } = "";
 public Guid MaLuotGui { get; set; } = Guid.NewGuid();
 public byte[] RowVersion { get; set; } = [];
}
public class DeNghiDieuChinhDichVu
{
 public long MaDeNghi { get; set; }
 public long MaYeuCau { get; set; }
 public string LoaiDeNghi { get; set; } = "";
 public string DieuKienCu { get; set; } = "";
 public DateOnly? NgayBatDauMoi { get; set; }
 public DateOnly? NgayKetThucMoi { get; set; }
 public int? SoNguoiMoi { get; set; }
 public int? SoLuongMoi { get; set; }
 public string? DieuKienMoi { get; set; }
 public string LyDo { get; set; } = "";
 public DateTime ThoiDiemGui { get; set; } = DateTime.UtcNow;
 public string? QuyetDinh { get; set; }
 public string? DieuKienDeXuat { get; set; }
 public DateTime? ThoiDiemPhanHoi { get; set; }
 public string TrangThai { get; set; } = "";
 public byte[] RowVersion { get; set; } = [];
}
public class KetQuaCungCapDichVu
{
 public long MaKetQua { get; set; }
 public long MaYeuCau { get; set; }
 public string HangMuc { get; set; } = "";
 public string KetQuaThucHien { get; set; } = "";
 public string? GhiChu { get; set; }
 public DateTime ThoiDiemGhi { get; set; } = DateTime.UtcNow;
 public string? NoiDungPhanAnh { get; set; }
 public DateTime? ThoiDiemPhanAnh { get; set; }
 public string TrangThaiKiemTra { get; set; } = "";
 public DateTime? ThoiDiemKiemTra { get; set; }
 public byte[] RowVersion { get; set; } = [];
}
public class ThongBao
{
 public long MaThongBao { get; set; }
 public long MaNguoiNhan { get; set; }
 public string LoaiThongBao { get; set; } = "";
 public string NoiDung { get; set; } = "";
 public string? DuongDan { get; set; }
 public bool DaDoc { get; set; }
 public DateTime ThoiDiemTao { get; set; } = DateTime.UtcNow;
}
public class NhatKyThaoTac
{
 public long MaNhatKy { get; set; }
 public long? MaTaiKhoan { get; set; }
 public string LoaiSuKien { get; set; } = "";
 public string? DoiTuong { get; set; }
 public long? MaDoiTuong { get; set; }
 public string? TrangThaiTruoc { get; set; }
 public string? TrangThaiSau { get; set; }
 public string? LyDo { get; set; }
 public string? DiaChiIP { get; set; }
 public DateTime ThoiDiem { get; set; } = DateTime.UtcNow;
}
