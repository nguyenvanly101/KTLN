using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using HoTroDuLich.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.RateLimiting;
namespace HoTroDuLich.Web.Controllers;
public class XuLyYeuCauDatController(IDatDichVuService component,TravelService read):FullTextController<IDatDichVuService>(component,read) {
 [Authorize(Policy="LaNhaCungCap"),HttpGet("/nha-cung-cap/yeu-cau")]
 public async Task<IActionResult> DanhSachNCC(string? trangThai,int trang=1) { ViewBag.ServiceNames=await C.LayTenDichVuAsync();return V("Bookings/Index",Page(FilterBookings(await C.DanhSachNCCAsync(),trangThai),trang)); }
 [Authorize(Policy="LaNhaCungCap"),HttpGet("/nha-cung-cap/yeu-cau/{maYeuCau}")]
 public async Task<IActionResult> XemYeuCau(long maYeuCau) { ViewBag.ServiceName=await C.LayTenDichVuCuaYeuCauAsync(maYeuCau);return V("Bookings/Detail",await C.XemYeuCauAsync(maYeuCau)); }
 [Authorize(Policy="LaNhaCungCap"),HttpPost("/yeu-cau/chap-nhan")]
 public async Task<IActionResult> ChapNhan(CommandInput i) { if(i.Decision=="ChapNhan")i.Decision="DaXacNhan";await C.ChapNhanAsync(i);return Done("/nha-cung-cap/yeu-cau/"+i.Id); }
}
