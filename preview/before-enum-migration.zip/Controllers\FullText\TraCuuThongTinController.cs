using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using HoTroDuLich.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.RateLimiting;
namespace HoTroDuLich.Web.Controllers;
public class TraCuuThongTinController(ITimKiemThongTinService component,TravelService read):FullTextController<ITimKiemThongTinService>(component,read) {
 [AllowAnonymous,HttpGet("/thong-tin/mo-tim-kiem")]
 public async Task<IActionResult> MoTimKiem() { ViewBag.Regions=await C.MoTimKiemAsync();var r=await C.TraCuuAsync(null,null,null,null,null);ViewBag.Places=r.Places;return V("Explore/Index",r.Services); }
 [AllowAnonymous,HttpGet("/thong-tin/tra-cuu")]
 public async Task<IActionResult> TraCuu(string? tuKhoa,string? khuVuc,string? loai,decimal? giaTu,decimal? giaDen,int trang=1) { ViewBag.Query=tuKhoa;ViewBag.Region=khuVuc;ViewBag.Type=DanhMuc.ChuanHoa(loai);ViewBag.Min=giaTu;ViewBag.Max=giaDen;ViewBag.Regions=await C.MoTimKiemAsync();var r=await C.TraCuuAsync(tuKhoa,khuVuc,loai,giaTu,giaDen,trang);ViewBag.Places=r.Places;ViewBag.SimplePage=trang;ViewBag.SimpleNext=r.Services.Count==20||r.Places.Count==20;return V("Explore/Index",r.Services); }
}
