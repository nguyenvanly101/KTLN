using System.Security.Claims;
using System.Data;
using System.ComponentModel.DataAnnotations;
using HoTroDuLich.Web.Data;
using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using System.Text.Json;
using System.Security.Cryptography;

namespace HoTroDuLich.Web.Services;
public partial class NgungTaiKhoanService(AppDbContext context, IHttpContextAccessor accessor, IWebHostEnvironment environment, IConfiguration configuration, IServiceProvider provider, IDatDichVuService serviceDatDichVu, IKetNoiDongHanhService serviceKetNoiDongHanh, INhatKyService serviceNhatKy, IThoaThuanDongHanhService serviceThoaThuanDongHanh, IThongBaoService serviceThongBao) : NghiepVuService(context, accessor, environment, configuration, provider), INgungTaiKhoanService
{
    public async Task<DeactivationReview> KiemTraDieuKienNgung()
    {
        RoleRequired(Traveler, ProviderRole);
        var obligations = new List<AccountObligation>();
        var bookings = await serviceDatDichVu.TruyVanYeuCau().Where(x => new[] { "ChoPhanHoi", "DeXuatKhac", "DaXacNhan", "ChoKiemTra" }.Contains(x.TrangThai)).ToListAsync();
        obligations.AddRange(bookings.Select(x => new AccountObligation("Yêu cầu #" + x.MaYeuCau + " · " + Labels.Status(x.TrangThai), "/Bookings/Detail/" + x.MaYeuCau)));
        if (Role == Traveler)
        {
            var agreements = await serviceThoaThuanDongHanh.TruyVanThoaThuan().Where(x => x.TrangThai == "DaXacNhan").ToListAsync();
            obligations.AddRange(agreements.Select(x => new AccountObligation("Thỏa thuận đồng hành #" + x.MaThoaThuan, "/Companions/Agreement/" + x.MaDeNghi)));
        }
        else
        {
            var changes = await db.DeNghiDieuChinhDichVu.Where(x => new[] { "ChoPhanHoi", "DeXuatKhac" }.Contains(x.TrangThai) && serviceDatDichVu.TruyVanYeuCau().Any(y => y.MaYeuCau == x.MaYeuCau)).ToListAsync();
            obligations.AddRange(changes.Select(x => new AccountObligation("Đề nghị điều chỉnh #" + x.MaDeNghi, "/Bookings/Changes/" + x.MaYeuCau)));
        }

        var needs = await db.NhuCauDongHanh.CountAsync(x => x.MaTaiKhoan == UserId && x.TrangThaiCongBo == "DangCongBo");
        var connections = await serviceKetNoiDongHanh.TruyVanKetNoi().CountAsync(x => x.TrangThai == "ChoPhanHoi");
        var services = Role == ProviderRole ? await db.DichVuDuLich.CountAsync(x => x.TrangThaiTiepNhan == "TiepNhan" && db.NhaCungCapDichVu.Any(p => p.MaNhaCungCap == x.MaNhaCungCap && p.MaTaiKhoan == UserId)) : 0;
        return new(obligations, needs, connections, services, null);
    }

    public async Task<DeactivationReview> XacThucLaiAsync(string password)
    {
        RoleRequired(Traveler, ProviderRole);
        var a = await Find<TaiKhoan>(UserId);
        if (new PasswordHasher<TaiKhoan>().VerifyHashedPassword(a, a.MatKhauBam, password) != PasswordVerificationResult.Failed)
        {
            var review = await KiemTraDieuKienNgung();
            return review with
            {
                ConfirmationToken = review.Obligations.Count == 0 ? DeactivationProtector.Protect(UserId + "|" + a.DauPhien, TimeSpan.FromMinutes(5)) : null
            };
        }

        serviceNhatKy.Ghi("XacThucLai", "TaiKhoan", UserId, null, "ThatBai");
        await db.SaveChangesAsync();
        Ensure(false, "1401-01", "Password");
        throw new InvalidOperationException();
    }

    public async Task NgungTaiKhoanAsync(string token)
    {
        RoleRequired(Traveler, ProviderRole);
        string? evidence = null;
        try
        {
            evidence = DeactivationProtector.Unprotect(token);
        }
        catch (CryptographicException)
        {
            Ensure(false, "1401-02");
        }
        catch (ArgumentException)
        {
            Ensure(false, "1401-02");
        }

        await Execute(async () =>
        {
            var a = await Find<TaiKhoan>(UserId);
            Ensure(evidence == UserId + "|" + a.DauPhien, "1401-02");
            var review = await KiemTraDieuKienNgung();
            Ensure(review.Obligations.Count == 0, "1401-03");
            a.TrangThai = "DaNgung";
            a.ThoiDiemNgung = Clock.BayGioUtc;
            a.DauPhien = Guid.NewGuid();
            foreach (var n in await db.NhuCauDongHanh.Where(x => x.MaTaiKhoan == UserId && x.TrangThaiCongBo == "DangCongBo").ToListAsync())
                n.TrangThaiCongBo = "DungCongBo";
            foreach (var c in await serviceKetNoiDongHanh.TruyVanKetNoi().Where(x => x.TrangThai == "ChoPhanHoi").ToListAsync())
            {
                c.TrangThai = "HetHieuLuc";
                c.ThoiDiemPhanHoi = Clock.BayGioUtc;
                var n = await Find<NhuCauDongHanh>(c.MaNhuCau);
                serviceThongBao.Tao(c.MaNguoiGui == UserId ? n.MaTaiKhoan : c.MaNguoiGui, "Đề nghị kết nối hết hiệu lực do một bên ngừng tài khoản.", "/dong-hanh/de-nghi/xem-de-nghi/" + c.MaDeNghi, "DeNghiHetHieuLuc");
            }

            foreach (var t in await serviceThoaThuanDongHanh.TruyVanThoaThuan().Where(x => x.TrangThai == "ChoXacNhan").ToListAsync())
            {
                t.TrangThai = "DaThayThe";
                t.LyDo = "Một bên ngừng tài khoản";
            }

            if (Role == ProviderRole)
            {
                var p = await MyProvider();
                foreach (var s in await db.DichVuDuLich.Where(x => x.MaNhaCungCap == p.MaNhaCungCap && x.TrangThaiTiepNhan == "TiepNhan").ToListAsync())
                {
                    s.TrangThaiTiepNhan = "KhongTiepNhanMoi";
                    s.MaQuyetDinhKhongTiepNhan = null;
                }
            }

            serviceNhatKy.Ghi("NgungTaiKhoan", "TaiKhoan", UserId, "HoatDong", "DaNgung", $"{review.Needs} nhu cầu; {review.Connections} đề nghị; {review.Services} dịch vụ");
        });
    }
}
