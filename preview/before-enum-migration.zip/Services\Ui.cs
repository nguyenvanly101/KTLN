using Microsoft.AspNetCore.Html;
using HoTroDuLich.Web.Domain;
namespace HoTroDuLich.Web.Services;

public static class Ui
{
    public static IHtmlContent Icon(string name) => new HtmlString($"<svg class=\"icon\" aria-hidden=\"true\"><use href=\"/images/icons.svg#{name}\"></use></svg>");
    public static string DestinationImage(string region) => region.Contains("Hội An") ? "/images/hoian.jpg" : region.Contains("Hải Phòng") || region.Contains("Lan Hạ") || region.Contains("Hạ Long") ? "/images/vietnam-bay.jpg" : "/images/dalat.jpg";
    public static string ServiceImage(DichVuDuLich s) => DanhMuc.ChuanHoa(s.LoaiDichVu) == "LuuTru" ? "/images/stay.jpg" : DanhMuc.ChuanHoa(s.LoaiDichVu) == "AnUong" ? "/images/food.jpg" : DestinationImage(s.KhuVucPhucVu);
    public static string CategoryIcon(string type) => DanhMuc.ChuanHoa(type) switch { "LuuTru" => "bed", "AnUong" => "food", "PhuongTien" => "car", "HoatDong" => "compass", _ => "pin" };
}
