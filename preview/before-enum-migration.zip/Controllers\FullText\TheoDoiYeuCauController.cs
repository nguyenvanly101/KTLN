using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using HoTroDuLich.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.RateLimiting;
namespace HoTroDuLich.Web.Controllers;
public class TheoDoiYeuCauController(IDatDichVuService component,TravelService read):FullTextController<IDatDichVuService>(component,read) {
 [Authorize(Policy="LaKhachDuLich"),HttpGet("/yeu-cau/cua-toi")]
 public async Task<IActionResult> DanhSachCuaToi(string? trangThai,int trang=1) { ViewBag.ServiceNames=await C.LayTenDichVuAsync();return V("Bookings/Index",Page(FilterBookings(await C.DanhSachCuaToiAsync(),trangThai),trang)); }
 [Authorize(Policy="LaKhachDuLich"),HttpGet("/yeu-cau/{maYeuCau}")]
 public async Task<IActionResult> ChiTiet(long maYeuCau) { ViewBag.ServiceName=await C.LayTenDichVuCuaYeuCauAsync(maYeuCau);return V("Bookings/Detail",await C.ChiTietAsync(maYeuCau)); }
 [Authorize(Policy="LaKhachDuLich"),HttpPost("/yeu-cau/phan-hoi-de-xuat")]
 public async Task<IActionResult> PhanHoiDeXuat(CommandInput i) { await C.PhanHoiDeXuatAsync(i);return Done("/yeu-cau/"+i.Id); }
}
