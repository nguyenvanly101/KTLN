using System.Security.Claims;
using System.Data;
using System.ComponentModel.DataAnnotations;
using HoTroDuLich.Web.Data;
using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using System.Text.Json;
using System.Security.Cryptography;

namespace HoTroDuLich.Web.Services;
public partial class NhatKyService(AppDbContext context, IHttpContextAccessor accessor, IWebHostEnvironment environment, IConfiguration configuration, IServiceProvider provider) : NghiepVuService(context, accessor, environment, configuration, provider), INhatKyService
{
    public void Ghi(string kind, string target, long id, string? before, string? after, string? reason = null) => db.NhatKyThaoTac.Add(new() { MaTaiKhoan = UserId == 0 ? null : UserId, LoaiSuKien = kind, DoiTuong = target, MaDoiTuong = id, TrangThaiTruoc = before, TrangThaiSau = after, LyDo = reason, DiaChiIP = http.HttpContext?.Connection.RemoteIpAddress?.ToString() });
    public async Task<List<NhatKyThaoTac>> LayDanhSachAsync()
    {
        RoleRequired(AdminRole);
        return await db.NhatKyThaoTac.OrderByDescending(x => x.ThoiDiem).Take(200).ToListAsync();
    }

    public async Task<AdminOverview> TongQuanAsync()
    {
        RoleRequired(AdminRole);
        return new(await db.BanCapNhatDichVu.CountAsync(x => x.TrangThaiDuyet == "ChoDuyet"), await db.HoSoXacMinhNhaCungCap.CountAsync(x => x.TrangThaiXuLy == "ChoXacMinh"), await db.NhaCungCapDichVu.CountAsync(), await db.GiaiTrinhNhaCungCap.CountAsync(x => x.TrangThai == "ChoXemXet"));
    }
}
