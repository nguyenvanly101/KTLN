using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using HoTroDuLich.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.RateLimiting;
namespace HoTroDuLich.Web.Controllers;
public class DanhSachKeHoachController(ILapKeHoachService component,TravelService read):FullTextController<ILapKeHoachService>(component,read) {
 [Authorize(Policy="LaKhachDuLich"),HttpGet("/ke-hoach")]
 public async Task<IActionResult> DanhSach(int trang=1) { return V("Plans/Index",Page(await C.DanhSachAsync(),trang)); }
 [Authorize(Policy="LaKhachDuLich"),HttpGet("/ke-hoach/{maKeHoach}")]
 public async Task<IActionResult> XemKeHoach(long maKeHoach) { ViewBag.Activities=await C.LayHoatDong(maKeHoach);return V("Plans/Detail",await C.XemKeHoachAsync(maKeHoach)); }
}
