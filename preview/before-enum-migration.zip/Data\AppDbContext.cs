using Microsoft.EntityFrameworkCore;
using HoTroDuLich.Web.Domain;
namespace HoTroDuLich.Web.Data;
public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
 public DbSet<TaiKhoan> TaiKhoan => Set<TaiKhoan>();
 public DbSet<HoSoNguoiDung> HoSoNguoiDung => Set<HoSoNguoiDung>();
 public DbSet<NhaCungCapDichVu> NhaCungCapDichVu => Set<NhaCungCapDichVu>();
 public DbSet<HoSoXacMinhNhaCungCap> HoSoXacMinhNhaCungCap => Set<HoSoXacMinhNhaCungCap>();
 public DbSet<QuyetDinhXacMinh> QuyetDinhXacMinh => Set<QuyetDinhXacMinh>();
 public DbSet<TaiLieuXacMinh> TaiLieuXacMinh => Set<TaiLieuXacMinh>();
 public DbSet<QuyetDinhQuyenHoatDong> QuyetDinhQuyenHoatDong => Set<QuyetDinhQuyenHoatDong>();
 public DbSet<GiaiTrinhNhaCungCap> GiaiTrinhNhaCungCap => Set<GiaiTrinhNhaCungCap>();
 public DbSet<TaiLieuGiaiTrinh> TaiLieuGiaiTrinh => Set<TaiLieuGiaiTrinh>();
 public DbSet<DiaDiemDuLich> DiaDiemDuLich => Set<DiaDiemDuLich>();
 public DbSet<DichVuDuLich> DichVuDuLich => Set<DichVuDuLich>();
 public DbSet<BanCapNhatDichVu> BanCapNhatDichVu => Set<BanCapNhatDichVu>();
 public DbSet<KeHoachChuyenDi> KeHoachChuyenDi => Set<KeHoachChuyenDi>();
 public DbSet<HoatDongLichTrinh> HoatDongLichTrinh => Set<HoatDongLichTrinh>();
 public DbSet<TinhHuongPhatSinh> TinhHuongPhatSinh => Set<TinhHuongPhatSinh>();
 public DbSet<TinhHuongHoatDong> TinhHuongHoatDong => Set<TinhHuongHoatDong>();
 public DbSet<PhuongAnXuLy> PhuongAnXuLy => Set<PhuongAnXuLy>();
 public DbSet<NhuCauDongHanh> NhuCauDongHanh => Set<NhuCauDongHanh>();
 public DbSet<DeNghiKetNoiDongHanh> DeNghiKetNoiDongHanh => Set<DeNghiKetNoiDongHanh>();
 public DbSet<ThoaThuanDongHanh> ThoaThuanDongHanh => Set<ThoaThuanDongHanh>();
 public DbSet<YeuCauDatDichVu> YeuCauDatDichVu => Set<YeuCauDatDichVu>();
 public DbSet<DeNghiDieuChinhDichVu> DeNghiDieuChinhDichVu => Set<DeNghiDieuChinhDichVu>();
 public DbSet<KetQuaCungCapDichVu> KetQuaCungCapDichVu => Set<KetQuaCungCapDichVu>();
 public DbSet<ThongBao> ThongBao => Set<ThongBao>();
 public DbSet<NhatKyThaoTac> NhatKyThaoTac => Set<NhatKyThaoTac>();
 protected override void ConfigureConventions(ModelConfigurationBuilder b) {
  b.Conventions.Remove(typeof(Microsoft.EntityFrameworkCore.Metadata.Conventions.ForeignKeyIndexConvention));
  b.Properties<DateTime>().HaveColumnType("datetime2(0)").HaveConversion<UtcDateTimeConverter>();
  b.Properties<DateTime?>().HaveColumnType("datetime2(0)").HaveConversion<NullableUtcDateTimeConverter>();
 }
 protected override void OnModelCreating(ModelBuilder b) {
  b.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);
  foreach(var entity in b.Model.GetEntityTypes()) {
   foreach(var fk in entity.GetForeignKeys()) {
    fk.DeleteBehavior=DeleteBehavior.NoAction;
    fk.SetConstraintName("FK_"+entity.GetTableName()+"_"+string.Join("_",fk.Properties.Select(p=>p.Name)));
   }
  }
 }
}
public sealed class UtcDateTimeConverter() : Microsoft.EntityFrameworkCore.Storage.ValueConversion.ValueConverter<DateTime,DateTime>(
 v=>v.Kind==DateTimeKind.Utc?v:v.ToUniversalTime(), v=>DateTime.SpecifyKind(v,DateTimeKind.Utc));
public sealed class NullableUtcDateTimeConverter() : Microsoft.EntityFrameworkCore.Storage.ValueConversion.ValueConverter<DateTime?,DateTime?>(
 v=>v.HasValue?(v.Value.Kind==DateTimeKind.Utc?v:v.Value.ToUniversalTime()):null,
 v=>v.HasValue?DateTime.SpecifyKind(v.Value,DateTimeKind.Utc):null);
