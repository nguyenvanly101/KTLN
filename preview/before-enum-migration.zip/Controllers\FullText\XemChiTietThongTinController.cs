using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using HoTroDuLich.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.RateLimiting;
namespace HoTroDuLich.Web.Controllers;
public class XemChiTietThongTinController(ITimKiemThongTinService component,TravelService read):FullTextController<ITimKiemThongTinService>(component,read) {
 [AllowAnonymous,HttpGet("/thong-tin/xem-chi-tiet")]
 public async Task<IActionResult> XemChiTiet(string loai,long maMuc) { var result=await C.XemChiTietAsync(loai,maMuc);ViewBag.Provider=result.NhaCungCap;ViewBag.Services=result.DichVuTaiDiem;return result.DiaDiem!=null?V("Explore/Place",result.DiaDiem):V("Explore/Detail",result.DichVu); }
}
