using System.Security.Claims;
using System.Data;
using System.ComponentModel.DataAnnotations;
using HoTroDuLich.Web.Data;
using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using System.Text.Json;
using System.Security.Cryptography;

namespace HoTroDuLich.Web.Services;
public partial class LuuTepService(AppDbContext context, IHttpContextAccessor accessor, IWebHostEnvironment environment, IConfiguration configuration, IServiceProvider provider, IQuyenHoatDongService serviceQuyenHoatDong, IXacMinhNhaCungCapService serviceXacMinhNhaCungCap) : NghiepVuService(context, accessor, environment, configuration, provider), ILuuTepService
{
    public string DuongDanAnToan(string file)
    {
        var root = Path.GetFullPath(Path.Combine(env.ContentRootPath, "App_Data", "uploads")) + Path.DirectorySeparatorChar;
        var path = Path.GetFullPath(Path.Combine(root, file.Replace('/', Path.DirectorySeparatorChar)));
        Require(path.StartsWith(root, StringComparison.OrdinalIgnoreCase), "Đường dẫn không hợp lệ.", 404);
        return path;
    }

    public async Task<(string Path, string Name, string ContentType)> TaiTepAsync(string kind, long id)
    {
        string file, name, type;
        if (kind == "verification")
        {
            var f = await Find<TaiLieuXacMinh>(id);
            await serviceXacMinhNhaCungCap.XemHoSoAsync(f.MaHoSo);
            file = f.DuongDan;
            name = f.TenTepGoc;
            type = f.LoaiTep;
        }
        else
        {
            Require(kind == "explanation", "Tệp không hợp lệ.", 404);
            var f = await Find<TaiLieuGiaiTrinh>(id);
            var g = await Find<GiaiTrinhNhaCungCap>(f.MaGiaiTrinh);
            var d = await Find<QuyetDinhQuyenHoatDong>(g.MaQuyetDinh);
            await serviceQuyenHoatDong.XemChiTietAsync(d.MaNhaCungCap);
            file = f.DuongDan;
            name = f.TenTepGoc;
            type = f.LoaiTep;
        }

        return (DuongDanAnToan(file), name, type == "pdf" ? "application/pdf" : type == "png" ? "image/png" : "image/jpeg");
    }
}
