using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using HoTroDuLich.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.RateLimiting;
namespace HoTroDuLich.Web.Controllers;
public class GuiYeuCauDatController(IDatDichVuService component,TravelService read):FullTextController<IDatDichVuService>(component,read) {
 [Authorize(Policy="LaKhachDuLich"),HttpGet("/yeu-cau/mo-dat-dich-vu")]
 public async Task<IActionResult> MoDatDichVu(long maDichVu) { var d=await C.MoDatDichVuAsync(maDichVu);ViewBag.Service=d;return V("Bookings/Create",new BookingInput{ServiceId=maDichVu,Version=TravelService.Token(d.RowVersion)}); }
 [Authorize(Policy="LaKhachDuLich"),HttpPost("/yeu-cau/kiem-tra-truoc-gui")]
 public async Task<IActionResult> KiemTraTruocGui(BookingInput i) { ViewBag.Warnings=await C.KiemTraTruocGuiAsync(i);ViewBag.ServiceName=(await S.PublicService(i.ServiceId)).TenDichVu;return V("Bookings/Preview",i); }
 [Authorize(Policy="LaKhachDuLich"),HttpPost("/yeu-cau/gui-yeu-cau")]
 public async Task<IActionResult> GuiYeuCau(BookingInput i) { return Done("/yeu-cau/"+await C.GuiYeuCauAsync(i),"Đã gửi yêu cầu, chờ nhà cung cấp phản hồi."); }
}
