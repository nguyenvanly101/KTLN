using System.Security.Claims;
using System.Data;
using System.ComponentModel.DataAnnotations;
using HoTroDuLich.Web.Data;
using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using System.Text.Json;
using System.Security.Cryptography;

namespace HoTroDuLich.Web.Services;
public partial class TimKiemThongTinService(AppDbContext context, IHttpContextAccessor accessor, IWebHostEnvironment environment, IConfiguration configuration, IServiceProvider provider, IDanhMucService serviceDanhMuc, IQuanLyDichVuService serviceQuanLyDichVu) : NghiepVuService(context, accessor, environment, configuration, provider), ITimKiemThongTinService
{
    public async Task<(List<DichVuDuLich> Services, List<DiaDiemDuLich> Places)> TraCuuAsync(string? q, string? region, string? type, decimal? min, decimal? max, int page = 1)
    {
        RequireUseCase(SucAccess.TravelSearch);
        type = DanhMuc.ChuanHoa(type);
        Ensure((q?.Length ?? 0) <= 100 && page >= 1 && (min == null || min is >= 0 and <= 1000000000) && (max == null || max is >= 0 and <= 1000000000) && (min == null || max == null || min <= max) && (string.IsNullOrEmpty(type) || type == "DiaDiem" || DanhMuc.LoaiDichVu.Contains(type)) && (string.IsNullOrEmpty(region) || (await serviceDanhMuc.LayDanhMucKhuVuc()).Contains(region)), "0101-01");
        var s = PublicServices().AsNoTracking();
        var p = db.DiaDiemDuLich.Where(x => x.DangHienThi).AsNoTracking();
        if (!string.IsNullOrWhiteSpace(q))
        {
            q = q.Trim();
            s = s.Where(x => x.TenDichVu.Contains(q) || (x.MoTa != null && x.MoTa.Contains(q)));
            p = p.Where(x => x.TenDiaDiem.Contains(q) || (x.MoTa != null && x.MoTa.Contains(q)));
        }

        if (!string.IsNullOrEmpty(region))
        {
            s = s.Where(x => x.KhuVucPhucVu == region);
            p = p.Where(x => x.KhuVuc == region);
        }

        if (!string.IsNullOrEmpty(type))
        {
            var legacy = DanhMuc.Ten(type);
            s = s.Where(x => x.LoaiDichVu == type || x.LoaiDichVu == legacy);
            if (type != "DiaDiem")
                p = p.Where(x => false);
            else
                s = s.Where(x => false);
        }

        if (min != null)
            s = s.Where(x => x.GiaThamKhao >= min);
        if (max != null)
            s = s.Where(x => x.GiaThamKhao <= max);
        if (min != null || max != null)
            p = p.Where(x => false);
        return (await s.OrderBy(x => x.TenDichVu).ThenBy(x => x.MaDichVu).Skip((page - 1) * 20).Take(20).ToListAsync(), await p.OrderBy(x => x.TenDiaDiem).ThenBy(x => x.MaDiaDiem).Skip((page - 1) * 20).Take(20).ToListAsync());
    }

    public async Task<NhaCungCapDichVu> LayNhaCungCapAsync(long id)
    {
        var s = await serviceQuanLyDichVu.LayChiTiet(id);
        return await Find<NhaCungCapDichVu>(s.MaNhaCungCap);
    }
}
