using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using HoTroDuLich.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.RateLimiting;
namespace HoTroDuLich.Web.Controllers;
public class DanhSachChoDuyetController(IXetDuyetDichVuService component,TravelService read):FullTextController<IXetDuyetDichVuService>(component,read) {
 [Authorize(Policy="LaQuanTriVien"),HttpGet("/quan-tri/xet-duyet-dich-vu/mo-danh-sach-cho-duyet")]
 public async Task<IActionResult> MoDanhSachChoDuyet(string? q,string status="ChoDuyet",int trang=1) { return V("Admin/ServiceReviews",await C.MoDanhSachChoDuyetAsync(q,status,trang)); }
 [Authorize(Policy="LaQuanTriVien"),HttpGet("/quan-tri/xet-duyet-dich-vu/xem-noi-dung/{maBanCapNhat}")]
 public async Task<IActionResult> XemNoiDung(long maBanCapNhat) { return V("Admin/Review",await C.XemNoiDungAsync(maBanCapNhat)); }
}
