using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
namespace HoTroDuLich.Web.Services;

public partial class TravelService
{
 public IQueryable<YeuCauDatDichVu> AccessibleBookings()=>db.YeuCauDatDichVu.Where(x=>x.MaTaiKhoan==UserId||db.DichVuDuLich.Any(s=>s.MaDichVu==x.MaDichVu&&db.NhaCungCapDichVu.Any(p=>p.MaNhaCungCap==s.MaNhaCungCap&&p.MaTaiKhoan==UserId)));
 public async Task<List<YeuCauDatDichVu>> Bookings()=>await AccessibleBookings().OrderByDescending(x=>x.ThoiDiemGui).ThenByDescending(x=>x.MaYeuCau).ToListAsync();
 public async Task<YeuCauDatDichVu> Booking(long id)=>await AccessibleBookings().SingleOrDefaultAsync(x=>x.MaYeuCau==id)??throw new BusinessException(MaLoi.TatCa["0701-04"].Message,404,"0701-04");
 private string? NormalizeSelections(string? value,string code){var lines=(value??"").Replace("\r","").Split('\n',StringSplitOptions.RemoveEmptyEntries|StringSplitOptions.TrimEntries);Ensure((value?.Length??0)<=1000&&lines.Length<=10&&lines.All(x=>x.Length<=150)&&lines.Distinct(StringComparer.OrdinalIgnoreCase).Count()==lines.Length,code,"Selections");return lines.Length==0?null:string.Join('\n',lines);}
 public void ValidateBooking(BookingInput i){Validate(i,"0701-03");Ensure(i.Start>=Today&&(i.End==null||i.End>=i.Start)&&i.SubmissionId!=Guid.Empty,"0701-03");i.Selections=NormalizeSelections(i.Selections,"0701-03");}
 public async Task<DichVuDuLich> BookableService(long id){var s=await db.DichVuDuLich.SingleOrDefaultAsync(x=>x.MaDichVu==id&&x.TrangThaiCongBo=="DaDuyet");Ensure(s!=null,"0701-01");Ensure(s!.TrangThaiTiepNhan=="TiepNhan"&&await ProviderActive(s.MaNhaCungCap),"0701-02");return s;}
 public async Task<List<string>> CheckBooking(BookingInput i){RoleRequired(Traveler);ValidateBooking(i);var s=await BookableService(i.ServiceId);var warnings=new List<string>();if(s.TamNgungTu!=null&&(i.End??i.Start)>=s.TamNgungTu&&(s.TamNgungDen==null||i.Start<=s.TamNgungDen))warnings.Add("Khoảng ngày đã chọn giao với thời gian tạm ngừng được công bố. Hãy trao đổi với nhà cung cấp trước khi xác nhận.");if(await db.BanCapNhatDichVu.AnyAsync(x=>x.MaDichVu==i.ServiceId&&x.TrangThaiDuyet=="ChoDuyet"))warnings.Add("Dịch vụ có bản cập nhật đang chờ duyệt; thông tin có thể thay đổi.");warnings.Add("Gửi yêu cầu không bảo đảm còn chỗ. Yêu cầu chỉ được xác nhận khi hai bên đồng ý cùng điều kiện.");return warnings;}
 public async Task<long> Book(BookingInput i){
  RoleRequired(Traveler);var duplicate=await db.YeuCauDatDichVu.AsNoTracking().SingleOrDefaultAsync(x=>x.MaTaiKhoan==UserId&&x.MaLuotGui==i.SubmissionId);if(duplicate!=null)return duplicate.MaYeuCau;
  ValidateBooking(i);long id=0;
  try{await Execute(async()=>{
   var existing=await db.YeuCauDatDichVu.SingleOrDefaultAsync(x=>x.MaTaiKhoan==UserId&&x.MaLuotGui==i.SubmissionId);if(existing!=null){id=existing.MaYeuCau;return;}
   var s=await BookableService(i.ServiceId);var y=new YeuCauDatDichVu{MaTaiKhoan=UserId,MaDichVu=i.ServiceId,NgayBatDau=i.Start,NgayKetThuc=i.End,ThoiGianDenDi=i.ArrivalDeparture,SoNguoi=i.People,SoLuong=i.Quantity,NoiDungLuaChon=i.Selections,GhiChu=i.Notes,ChiPhiDuKien=i.Cost,PhienBan=1,TrangThai="ChoPhanHoi",MaLuotGui=i.SubmissionId};db.Add(y);await db.SaveChangesAsync();id=y.MaYeuCau;var p=await Find<NhaCungCapDichVu>(s.MaNhaCungCap);Notify(p.MaTaiKhoan,"Có yêu cầu đặt dịch vụ mới #"+id,"/nha-cung-cap/yeu-cau/"+id,"YeuCauDatMoi");
  });}catch(DbUpdateException e) when(SqlError(e) is 2601 or 2627){var saved=await db.YeuCauDatDichVu.AsNoTracking().SingleOrDefaultAsync(x=>x.MaTaiKhoan==UserId&&x.MaLuotGui==i.SubmissionId);if(saved==null)throw;id=saved.MaYeuCau;}
  return id;
 }
 private static string BookingSnapshot(YeuCauDatDichVu y)=>JsonSerializer.Serialize(new{y.NgayBatDau,y.NgayKetThuc,y.ThoiGianDenDi,y.SoNguoi,y.SoLuong,y.NoiDungLuaChon,y.ChiPhiDuKien,y.GhiChu,y.DieuKienDeXuat,y.PhienBan});
 public async Task BookingAction(CommandInput i){
  RoleRequired(new[]{"Rut","KhachDongY","KhachKhongDongY"}.Contains(i.Decision)?Traveler:ProviderRole);
  await Execute(async()=>{
   var y=await Booking(i.Id);CheckVersion(y,i.Version,"0701-05");Ensure(i.BusinessVersion==y.PhienBan,"0701-05");var s=await Find<DichVuDuLich>(y.MaDichVu);var p=await Find<NhaCungCapDichVu>(s.MaNhaCungCap);var before=BookingSnapshot(y);string type;
   if(i.Decision=="Rut"){Ensure(y.MaTaiKhoan==UserId&&new[]{"ChoPhanHoi","DeXuatKhac"}.Contains(y.TrangThai),"0801-02");y.TrangThai="KhongTiepTuc";y.LyDo=i.Reason;type="YeuCauDaRut";}
   else if(i.Decision is "KhachDongY" or "KhachKhongDongY"){
    Ensure(y.MaTaiKhoan==UserId&&y.TrangThai=="DeXuatKhac","0701-05");
    var available=await ProviderActive(p.MaNhaCungCap)&&s.TrangThaiTiepNhan=="TiepNhan"&&s.TrangThaiCongBo=="DaDuyet";
    y.TrangThai=i.Decision=="KhachDongY"&&available?"DaXacNhan":"KhongTiepTuc";if(!available)y.LyDo="Nhà cung cấp không còn tiếp nhận yêu cầu mới";type=y.TrangThai=="DaXacNhan"?"YeuCauDaXacNhan":"YeuCauKhongTiepTuc";
   }else{
    Require(p.MaTaiKhoan==UserId,"Không có quyền phản hồi.",404);Ensure(y.TrangThai=="ChoPhanHoi","0701-05");Require(new[]{"DaXacNhan","TuChoi","DeXuatKhac"}.Contains(i.Decision),"Quyết định không hợp lệ.",400);
    if(i.Decision!="TuChoi")await BookableService(y.MaDichVu);else Ensure(!string.IsNullOrWhiteSpace(i.Reason),"0701-06","Reason");
    if(i.Decision=="DeXuatKhac"){
     Require(!string.IsNullOrWhiteSpace(i.Text)&&i.Text.Length<=2000,"Vui lòng giải thích điều kiện đề xuất, tối đa 2000 ký tự.",400);
     var start=i.Start??y.NgayBatDau;var end=i.End??y.NgayKetThuc;var people=i.People??y.SoNguoi;var quantity=i.Quantity??y.SoLuong;var cost=i.Cost??y.ChiPhiDuKien;var selections=i.Selections==null?y.NoiDungLuaChon:NormalizeSelections(i.Selections,"0701-03");var arrival=i.ArrivalDeparture??y.ThoiGianDenDi;
     Ensure(start>=Today&&(end==null||end>=start)&&people is >=1 and <=100&&quantity is >=1 and <=100&&(cost==null||cost is >=0 and <=1000000000)&&(arrival?.Length??0)<=100,"0701-03");
     Ensure(start!=y.NgayBatDau||end!=y.NgayKetThuc||people!=y.SoNguoi||quantity!=y.SoLuong||cost!=y.ChiPhiDuKien||selections!=y.NoiDungLuaChon||arrival!=y.ThoiGianDenDi,"0701-07");
     y.NgayBatDau=start;y.NgayKetThuc=end;y.SoNguoi=people;y.SoLuong=quantity;y.ChiPhiDuKien=cost;y.NoiDungLuaChon=selections;y.ThoiGianDenDi=arrival;y.DieuKienDeXuat=i.Text.Trim();
    }
    y.TrangThai=i.Decision;y.LyDo=string.IsNullOrWhiteSpace(i.Reason)?null:i.Reason;type=i.Decision=="DaXacNhan"?"YeuCauDaXacNhan":i.Decision=="TuChoi"?"YeuCauBiTuChoi":"YeuCauCoDeXuatKhac";
   }
   y.ThoiDiemPhanHoi=DateTime.UtcNow;y.PhienBan++;Audit("PhanHoiDatDichVu","YeuCauDatDichVu",y.MaYeuCau,before,BookingSnapshot(y),i.Reason);Notify(UserId==y.MaTaiKhoan?p.MaTaiKhoan:y.MaTaiKhoan,"Yêu cầu #"+y.MaYeuCau+": "+Labels.Status(y.TrangThai),UserId==y.MaTaiKhoan?"/nha-cung-cap/yeu-cau/"+y.MaYeuCau:"/yeu-cau/"+y.MaYeuCau,type);
  });
 }
 public async Task EditPendingBooking(BookingInput i){RoleRequired(Traveler);ValidateBooking(i);await Execute(async()=>{var y=await Booking(i.Id);Ensure(y.MaTaiKhoan==UserId&&y.TrangThai=="ChoPhanHoi","0801-02");CheckVersion(y,i.Version,"0801-03");y.NgayBatDau=i.Start;y.NgayKetThuc=i.End;y.ThoiGianDenDi=i.ArrivalDeparture;y.SoNguoi=i.People;y.SoLuong=i.Quantity;y.NoiDungLuaChon=i.Selections;y.GhiChu=i.Notes;y.ChiPhiDuKien=i.Cost;y.PhienBan++;var s=await Find<DichVuDuLich>(y.MaDichVu);var p=await Find<NhaCungCapDichVu>(s.MaNhaCungCap);Notify(p.MaTaiKhoan,"Khách vừa sửa yêu cầu #"+y.MaYeuCau,"/nha-cung-cap/yeu-cau/"+y.MaYeuCau,"YeuCauDaSua");});}
 public async Task<List<DeNghiDieuChinhDichVu>> Changes(long id){await Booking(id);return await db.DeNghiDieuChinhDichVu.Where(x=>x.MaYeuCau==id).OrderByDescending(x=>x.ThoiDiemGui).ToListAsync();}
 private async Task CheckChangeable(YeuCauDatDichVu y){Ensure(y.TrangThai=="DaXacNhan"&&y.NgayBatDau>Today&&!await db.KetQuaCungCapDichVu.AnyAsync(x=>x.MaYeuCau==y.MaYeuCau),"0801-02");}
 private void ValidateChange(YeuCauDatDichVu y,DateOnly? start,DateOnly? end,int? people,int? quantity,string? terms){Ensure((start==null||start>=Today)&&(end==null||end>=Today)&&((end??y.NgayKetThuc)==null||(end??y.NgayKetThuc)>=(start??y.NgayBatDau)),"0801-05");Ensure((people==null||people is >=1 and <=100)&&(quantity==null||quantity is >=1 and <=100)&&(terms?.Length??0)<=2000,"0801-05");}
 public async Task ChangeBooking(ChangeInput i){
  RoleRequired(Traveler);Validate(i,"0801-05");Require(new[]{"ThayDoi","Huy"}.Contains(i.Kind),"Loại đề nghị không hợp lệ.",400);
  await Execute(async()=>{
   var y=await Booking(i.Id);Ensure(y.MaTaiKhoan==UserId,"0801-01");CheckVersion(y,i.Version,"0801-03");await CheckChangeable(y);Ensure(!await db.DeNghiDieuChinhDichVu.AnyAsync(x=>x.MaYeuCau==i.Id&&new[]{"ChoPhanHoi","DeXuatKhac"}.Contains(x.TrangThai)),"0801-04");
   if(i.Kind=="ThayDoi"){ValidateChange(y,i.Start,i.End,i.People,i.Quantity,i.Terms);Ensure((i.Start!=null&&i.Start!=y.NgayBatDau)||(i.End!=null&&i.End!=y.NgayKetThuc)||(i.People!=null&&i.People!=y.SoNguoi)||(i.Quantity!=null&&i.Quantity!=y.SoLuong)||(!string.IsNullOrWhiteSpace(i.Terms)&&i.Terms!=y.DieuKienDeXuat),"0801-05");}
   db.Add(new DeNghiDieuChinhDichVu{MaYeuCau=i.Id,LoaiDeNghi=i.Kind,DieuKienCu=BookingSnapshot(y),NgayBatDauMoi=i.Kind=="ThayDoi"?i.Start:null,NgayKetThucMoi=i.Kind=="ThayDoi"?i.End:null,SoNguoiMoi=i.Kind=="ThayDoi"?i.People:null,SoLuongMoi=i.Kind=="ThayDoi"?i.Quantity:null,DieuKienMoi=i.Kind=="ThayDoi"?i.Terms:null,LyDo=i.Reason.Trim(),TrangThai="ChoPhanHoi"});var s=await Find<DichVuDuLich>(y.MaDichVu);var p=await Find<NhaCungCapDichVu>(s.MaNhaCungCap);Notify(p.MaTaiKhoan,"Có đề nghị điều chỉnh yêu cầu #"+i.Id,"/Bookings/Changes/"+i.Id,"DeNghiDieuChinhMoi");
  });
 }
 private static void ApplyChange(YeuCauDatDichVu y,DeNghiDieuChinhDichVu d){if(d.LoaiDeNghi=="Huy"){y.TrangThai="DaHuy";y.LyDo=d.LyDo;}else{y.NgayBatDau=d.NgayBatDauMoi??y.NgayBatDau;y.NgayKetThuc=d.NgayKetThucMoi??y.NgayKetThuc;y.SoNguoi=d.SoNguoiMoi??y.SoNguoi;y.SoLuong=d.SoLuongMoi??y.SoLuong;y.DieuKienDeXuat=d.DieuKienDeXuat??d.DieuKienMoi??y.DieuKienDeXuat;}y.PhienBan++;}
 public async Task ChangeAction(CommandInput i){
  var customer=new[]{"DaRut","KhachDongY"}.Contains(i.Decision);RoleRequired(customer?Traveler:ProviderRole);
  await Execute(async()=>{
   var d=await Find<DeNghiDieuChinhDichVu>(i.Id);var y=await Booking(d.MaYeuCau);CheckVersion(d,i.Version,"0801-06");Ensure(y.TrangThai=="DaXacNhan","0801-06");var s=await Find<DichVuDuLich>(y.MaDichVu);var p=await Find<NhaCungCapDichVu>(s.MaNhaCungCap);
   if(customer){Ensure(y.MaTaiKhoan==UserId,"0801-01");if(i.Decision=="DaRut"){Ensure(new[]{"ChoPhanHoi","DeXuatKhac"}.Contains(d.TrangThai),"0801-06");d.TrangThai="DaRut";}else{Ensure(d.TrangThai=="DeXuatKhac","0801-06");ApplyChange(y,d);d.TrangThai="ChapNhan";}}
   else{
    Ensure(p.MaTaiKhoan==UserId,"0801-01");Ensure(d.TrangThai=="ChoPhanHoi","0801-06");Require(new[]{"ChapNhan","TuChoi","DeXuatKhac"}.Contains(i.Decision),"Quyết định không hợp lệ.",400);
    if(i.Decision=="TuChoi")Ensure(!string.IsNullOrWhiteSpace(i.Reason),"0801-07","Reason");
    if(i.Decision=="DeXuatKhac"){Ensure(d.LoaiDeNghi=="ThayDoi"&&!string.IsNullOrWhiteSpace(i.Text)&&i.Text.Length<=2000,"0801-05");ValidateChange(y,i.Start,i.End,i.People,i.Quantity,i.Text);d.NgayBatDauMoi=i.Start??d.NgayBatDauMoi;d.NgayKetThucMoi=i.End??d.NgayKetThucMoi;d.SoNguoiMoi=i.People??d.SoNguoiMoi;d.SoLuongMoi=i.Quantity??d.SoLuongMoi;ValidateChange(y,d.NgayBatDauMoi,d.NgayKetThucMoi,d.SoNguoiMoi,d.SoLuongMoi,i.Text);d.DieuKienDeXuat=i.Text.Trim();}
    if(i.Decision=="ChapNhan")ApplyChange(y,d);d.TrangThai=i.Decision;d.QuyetDinh=string.IsNullOrWhiteSpace(i.Reason)?null:i.Reason;
   }
   d.ThoiDiemPhanHoi=DateTime.UtcNow;Notify(customer?p.MaTaiKhoan:y.MaTaiKhoan,"Đề nghị điều chỉnh #"+d.MaDeNghi+": "+Labels.Status(d.TrangThai),"/Bookings/Changes/"+y.MaYeuCau,"DeNghiDieuChinhDaPhanHoi");
  });
 }
 public async Task<List<string>> BookingItems(long id){var y=await Booking(id);var s=await Find<DichVuDuLich>(y.MaDichVu);var suffix=" × "+y.SoLuong;var main=s.TenDichVu[..Math.Min(s.TenDichVu.Length,200-suffix.Length)]+suffix;return new[]{main}.Concat((y.NoiDungLuaChon??"").Replace("\r","").Split('\n',StringSplitOptions.RemoveEmptyEntries|StringSplitOptions.TrimEntries)).ToList();}
 public async Task<List<KetQuaCungCapDichVu>> Results(long id){await Booking(id);return await db.KetQuaCungCapDichVu.Where(x=>x.MaYeuCau==id).ToListAsync();}
 private async Task AggregateResults(YeuCauDatDichVu y){var items=await BookingItems(y.MaYeuCau);var rows=await db.KetQuaCungCapDichVu.Where(x=>x.MaYeuCau==y.MaYeuCau).ToListAsync();y.TrangThai=items.Any(item=>!rows.Any(r=>r.HangMuc==item))||rows.Any(r=>r.KetQuaThucHien=="ChuaXacDinh"||r.TrangThaiKiemTra=="ChoKiemTra")?"ChoKiemTra":rows.All(r=>r.KetQuaThucHien=="DayDu")?"HoanThanh":rows.All(r=>r.KetQuaThucHien is "KhongThucHien" or "KhachKhongDen")?"KhongThucHien":"ThucHienMotPhan";}
 public async Task RecordResult(CommandInput i){
  RoleRequired(ProviderRole);await Execute(async()=>{
   var y=await Booking(i.Id);var s=await Find<DichVuDuLich>(y.MaDichVu);var p=await MyProvider();Ensure(p.MaNhaCungCap==s.MaNhaCungCap,"0901-01");CheckVersion(y,i.Version,"0901-04");Ensure(new[]{"DaXacNhan","ChoKiemTra"}.Contains(y.TrangThai),"0901-02");Ensure(y.NgayBatDau<=Today,"0901-03");
   var items=await BookingItems(i.Id);var rows=await db.KetQuaCungCapDichVu.Where(x=>x.MaYeuCau==i.Id).ToListAsync();var settled=rows.Where(x=>x.KetQuaThucHien!="ChuaXacDinh"&&x.TrangThaiKiemTra!="ChoKiemTra").Select(x=>x.HangMuc).ToHashSet();
   Ensure(!i.Items.Any(x=>settled.Contains(x.Item)),"0901-06");var pending=items.Where(x=>!settled.Contains(x)).ToHashSet();Ensure(i.Items.Count==pending.Count&&i.Items.Select(x=>x.Item).Distinct().Count()==i.Items.Count&&i.Items.All(x=>pending.Contains(x.Item)&&new[]{"DayDu","MotPhan","KhongThucHien","KhachKhongDen","ChuaXacDinh"}.Contains(x.Result)&&(x.Notes?.Length??0)<=1000),"0901-05");Ensure(pending.Count>0,"0901-06");
   foreach(var entry in i.Items){var r=rows.SingleOrDefault(x=>x.HangMuc==entry.Item);if(r==null){r=new(){MaYeuCau=i.Id,HangMuc=entry.Item};db.Add(r);}else Audit("DoiChieuKetQua","KetQuaCungCapDichVu",r.MaKetQua,r.KetQuaThucHien,entry.Result,entry.Notes);r.KetQuaThucHien=entry.Result;r.GhiChu=entry.Notes;r.TrangThaiKiemTra=entry.Result=="ChuaXacDinh"?"ChoKiemTra":r.NoiDungPhanAnh==null?"DaGhiNhan":"DaKiemTra";r.ThoiDiemKiemTra=r.TrangThaiKiemTra=="DaKiemTra"?DateTime.UtcNow:null;}
   await db.SaveChangesAsync();await AggregateResults(y);y.PhienBan++;Notify(y.MaTaiKhoan,"Kết quả từng hạng mục dịch vụ đã được ghi nhận.","/yeu-cau/"+i.Id+"/ket-qua/xem-ket-qua","KetQuaDaGhiNhan");
  });
 }
 public async Task ResultAction(CommandInput i){
  RoleRequired(i.Decision=="PhanAnh"?Traveler:ProviderRole);await Execute(async()=>{
   var r=await Find<KetQuaCungCapDichVu>(i.Id);var y=await Booking(r.MaYeuCau);CheckVersion(r,i.Version);
   if(i.Decision=="PhanAnh"){Ensure(y.MaTaiKhoan==UserId,"0901-01");Ensure(r.NoiDungPhanAnh==null&&DateTime.UtcNow<=r.ThoiDiemGhi.AddDays(config.GetValue<int>("Business:ComplaintDays",30)),"0901-07");Require(!string.IsNullOrWhiteSpace(i.Text)&&i.Text.Length<=1000,"Vui lòng nhập phản ánh, tối đa 1000 ký tự.",400);r.NoiDungPhanAnh=i.Text.Trim();r.ThoiDiemPhanAnh=DateTime.UtcNow;r.TrangThaiKiemTra="ChoKiemTra";r.ThoiDiemKiemTra=null;y.TrangThai="ChoKiemTra";y.PhienBan++;var s=await Find<DichVuDuLich>(y.MaDichVu);var p=await Find<NhaCungCapDichVu>(s.MaNhaCungCap);Notify(p.MaTaiKhoan,"Có phản ánh kết quả dịch vụ.","/yeu-cau/"+y.MaYeuCau+"/ket-qua/mo-ghi-nhan","KetQuaCoPhanAnh");}
   else{var p=await MyProvider();Ensure(await db.DichVuDuLich.AnyAsync(x=>x.MaDichVu==y.MaDichVu&&x.MaNhaCungCap==p.MaNhaCungCap),"0901-01");Ensure(r.TrangThaiKiemTra=="ChoKiemTra","0901-06");Require(new[]{"DayDu","MotPhan","KhongThucHien","KhachKhongDen"}.Contains(i.Decision),"Chọn kết quả sau đối chiếu.",400);Audit("DoiChieuKetQua","KetQuaCungCapDichVu",r.MaKetQua,r.KetQuaThucHien,i.Decision,i.Reason);r.KetQuaThucHien=i.Decision;r.TrangThaiKiemTra=r.NoiDungPhanAnh==null?"DaGhiNhan":"DaKiemTra";r.ThoiDiemKiemTra=DateTime.UtcNow;await db.SaveChangesAsync();await AggregateResults(y);y.PhienBan++;Notify(y.MaTaiKhoan,"Kết quả phản ánh đã được đối chiếu.","/yeu-cau/"+y.MaYeuCau+"/ket-qua/xem-ket-qua","KetQuaDaDoiChieu");}
  });
 }
}
