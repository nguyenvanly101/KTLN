using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using Microsoft.EntityFrameworkCore;
namespace HoTroDuLich.Web.Services;

public partial class TravelService
{
 public async Task<List<KeHoachChuyenDi>> Plans()=>await db.KeHoachChuyenDi.Where(x=>x.MaTaiKhoan==UserId).OrderByDescending(x=>x.ThoiDiemCapNhat).ThenByDescending(x=>x.MaKeHoach).ToListAsync();
 public async Task<KeHoachChuyenDi> OwnPlan(long id){RoleRequired(Traveler);return await db.KeHoachChuyenDi.SingleOrDefaultAsync(x=>x.MaKeHoach==id&&x.MaTaiKhoan==UserId)??throw new BusinessException(MaLoi.TatCa["0201-02"].Message,404,"0201-02");}
 public async Task<List<HoatDongLichTrinh>> Activities(long id){await OwnPlan(id);return await db.HoatDongLichTrinh.Where(x=>x.MaKeHoach==id).OrderBy(x=>x.Ngay).ThenBy(x=>x.ThuTu).ThenBy(x=>x.MaHoatDong).ToListAsync();}
 public async Task<long> SavePlan(PlanInput i){
  RoleRequired(Traveler);Validate(i,"0201-01");Dates(i.Start,i.End);long id=0;
  await Execute(async()=>{
   KeHoachChuyenDi p;
   if(i.Id==0){Ensure(i.Start>=Today,"0201-01","Start");p=new(){MaTaiKhoan=UserId,TrangThai="Nhap"};db.Add(p);}
   else {p=await OwnPlan(i.Id);CheckVersion(p,i.Version,"0201-05");Ensure(i.Start>=Today||i.Start==p.NgayBatDau,"0201-01","Start");Ensure(!await db.HoatDongLichTrinh.AnyAsync(x=>x.MaKeHoach==i.Id&&(x.Ngay<i.Start||x.Ngay>i.End)),"0201-07");p.TrangThai="Nhap";}
   p.TenKeHoach=i.Name.Trim();p.NoiDen=i.Destination.Trim();p.NgayBatDau=i.Start;p.NgayKetThuc=i.End;p.NganSachDuKien=i.Budget;p.ThoiDiemCapNhat=DateTime.UtcNow;
   await db.SaveChangesAsync();id=p.MaKeHoach;
  });return id;
 }
 public async Task PlanDecision(CommandInput i){RoleRequired(Traveler);await Execute(async()=>{var p=await OwnPlan(i.Id);CheckVersion(p,i.Version,"0201-05");Require(new[]{"Nhap","DaChapNhan"}.Contains(i.Decision),"Trạng thái kế hoạch không hợp lệ.",400);p.TrangThai=i.Decision;p.ThoiDiemCapNhat=DateTime.UtcNow;});}
 public async Task SaveActivity(ActivityInput i){
  RoleRequired(Traveler);Validate(i,"0201-01");
  await Execute(async()=>{
   var p=await OwnPlan(i.PlanId);CheckVersion(p,i.Version,"0201-05");Ensure(i.Date>=p.NgayBatDau&&i.Date<=p.NgayKetThuc,"0201-03","Date");
   Require(i.PlaceId==null||i.ServiceId==null,"Chỉ chọn một địa điểm hoặc dịch vụ.",400);
   if(i.ServiceId!=null)Ensure(await PublicServices().AnyAsync(x=>x.MaDichVu==i.ServiceId),"0201-04");
   if(i.PlaceId!=null)Ensure(await db.DiaDiemDuLich.AnyAsync(x=>x.MaDiaDiem==i.PlaceId&&x.DangHienThi),"0201-04");
   HoatDongLichTrinh a;
   if(i.Id==0){a=new(){MaKeHoach=i.PlanId};db.Add(a);}
   else a=await db.HoatDongLichTrinh.SingleOrDefaultAsync(x=>x.MaHoatDong==i.Id&&x.MaKeHoach==i.PlanId)??throw new BusinessException("Không tìm thấy hoạt động.",404);
   if(i.Id==0||a.Ngay!=i.Date)a.ThuTu=(await db.HoatDongLichTrinh.Where(x=>x.MaKeHoach==i.PlanId&&x.Ngay==i.Date).MaxAsync(x=>(int?)x.ThuTu)??0)+1;
   a.Ngay=i.Date;a.Gio=i.Time;a.NoiDung=i.Content.Trim();a.ChiPhiDuKien=i.Cost;a.MaDichVu=i.ServiceId;a.MaDiaDiem=i.PlaceId;
   p.TrangThai="Nhap";p.ThoiDiemCapNhat=DateTime.UtcNow;
  });
 }
 public async Task ReorderActivity(CommandInput i){await Execute(async()=>{var a=await Find<HoatDongLichTrinh>(i.Id);var p=await OwnPlan(a.MaKeHoach);CheckVersion(p,i.Version,"0201-05");var items=await db.HoatDongLichTrinh.Where(x=>x.MaKeHoach==p.MaKeHoach&&x.Ngay==a.Ngay).OrderBy(x=>x.ThuTu).ThenBy(x=>x.MaHoatDong).ToListAsync();var index=items.IndexOf(a);var target=i.Decision=="Len"?index-1:index+1;Require(target>=0&&target<items.Count,"Hoạt động đã ở đầu hoặc cuối ngày.",422);(items[index],items[target])=(items[target],items[index]);for(var n=0;n<items.Count;n++)items[n].ThuTu=n+1;p.TrangThai="Nhap";p.ThoiDiemCapNhat=DateTime.UtcNow;});}
 public async Task DeleteActivity(CommandInput i){await Execute(async()=>{var a=await Find<HoatDongLichTrinh>(i.Id);var p=await OwnPlan(a.MaKeHoach);CheckVersion(p,i.Version,"0201-05");Ensure(!await db.TinhHuongHoatDong.AnyAsync(x=>x.MaHoatDong==i.Id),"0201-06");db.Remove(a);p.TrangThai="Nhap";p.ThoiDiemCapNhat=DateTime.UtcNow;});}
 public async Task<List<TinhHuongPhatSinh>> Incidents(long plan){await OwnPlan(plan);return await db.TinhHuongPhatSinh.Where(x=>x.MaKeHoach==plan).OrderByDescending(x=>x.ThoiDiemGhiNhan).ToListAsync();}
 public async Task CreateIncident(IncidentInput i){
  RoleRequired(Traveler);i.Type=DanhMuc.ChuanHoa(i.Type);Validate(i,"0501-02");Ensure(DanhMuc.LoaiTinhHuong.Contains(i.Type),"0501-02","Type");
  var ids=i.ActivityIds.Concat(i.ActivityId.HasValue?[i.ActivityId.Value]:Array.Empty<long>()).Distinct().ToArray();
  await Execute(async()=>{await OwnPlan(i.PlanId);Ensure(await db.HoatDongLichTrinh.CountAsync(x=>ids.Contains(x.MaHoatDong)&&x.MaKeHoach==i.PlanId)==ids.Length,"0501-03");var t=new TinhHuongPhatSinh{MaKeHoach=i.PlanId,LoaiTinhHuong=i.Type,MoTa=i.Description.Trim(),ViTri=i.Location,TrangThaiXuLy="ChuaGiaiQuyet"};db.Add(t);await db.SaveChangesAsync();foreach(var id in ids)db.Add(new TinhHuongHoatDong{MaTinhHuong=t.MaTinhHuong,MaHoatDong=id});});
 }
 public async Task IncidentAction(CommandInput i){
  await Execute(async()=>{
   var t=await Find<TinhHuongPhatSinh>(i.Id);await OwnPlan(t.MaKeHoach);CheckVersion(t,i.Version,"0501-05");Ensure(!new[]{"DaGiaiQuyet","DungXuLy"}.Contains(t.TrangThaiXuLy),"0501-04");
   if(i.Decision=="PhuongAn"){
    Require(!string.IsNullOrWhiteSpace(i.Text)&&i.Text.Length<=2000,"Vui lòng nhập phương án, tối đa 2000 ký tự.",400);
    foreach(var a in await db.PhuongAnXuLy.Where(x=>x.MaTinhHuong==i.Id&&x.LaHienHanh).ToListAsync())a.LaHienHanh=false;
    await db.SaveChangesAsync();db.Add(new PhuongAnXuLy{MaTinhHuong=i.Id,NoiDung=i.Text.Trim(),LaHienHanh=true});t.TrangThaiXuLy="DaChonPhuongAn";
   }else{
    Require(new[]{"ChuaGiaiQuyet","GiaiQuyetMotPhan","DaGiaiQuyet","DungXuLy"}.Contains(i.Decision),"Kết quả không hợp lệ.",400);
    if(i.Decision is "GiaiQuyetMotPhan" or "DaGiaiQuyet")Ensure(!string.IsNullOrWhiteSpace(i.Text)&&i.Text.Length<=2000,"0501-06","Text");
    t.KetQuaXuLy=string.IsNullOrWhiteSpace(i.Text)?null:i.Text.Trim();
    t.TrangThaiXuLy=i.Decision=="ChuaGiaiQuyet"&&await db.PhuongAnXuLy.AnyAsync(x=>x.MaTinhHuong==i.Id&&x.LaHienHanh)?"DaChonPhuongAn":i.Decision;
   }
   t.ThoiDiemCapNhat=DateTime.UtcNow;
  });
 }
 public async Task<List<PhuongAnXuLy>> IncidentOptions(long id){var t=await Find<TinhHuongPhatSinh>(id);await OwnPlan(t.MaKeHoach);return await db.PhuongAnXuLy.Where(x=>x.MaTinhHuong==id).OrderByDescending(x=>x.ThoiDiemChon).ToListAsync();}
}
