using System.Security.Claims;
using System.Data;
using HoTroDuLich.Web.Data;
using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using System.ComponentModel.DataAnnotations;
namespace HoTroDuLich.Web.Services;
public class BusinessException(string message,int status=422,string code="NGHIEP_VU",string? field=null):Exception(message){public int Status{get;}=status;public string Code{get;}=code;public string? Field{get;}=field;}
public partial class TravelService(AppDbContext db,IHttpContextAccessor http,IWebHostEnvironment env,IConfiguration config) {
 public const string Traveler="KHACH_DU_LICH",ProviderRole="NHA_CUNG_CAP",AdminRole="QUAN_TRI_VIEN";
 public long UserId=>long.TryParse(http.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier),out var id)?id:0;
 public string Role=>http.HttpContext?.User.FindFirstValue(ClaimTypes.Role)??"";
 public static DateOnly Today=>DateOnly.FromDateTime(TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow,"SE Asia Standard Time"));
 public static string Token(byte[] v)=>Convert.ToBase64String(v);
 public void Require(bool valid,string message,int status=422){if(!valid)throw new BusinessException(message,status);}
 public void Ensure(bool valid,string code,string? field=null){if(valid)return;var e=MaLoi.TatCa[code];throw new BusinessException(e.Message,e.Status,code,field);}
 public void Validate(object input,string code){var errors=new List<ValidationResult>();Ensure(Validator.TryValidateObject(input,new ValidationContext(input),errors,true),code,errors.FirstOrDefault()?.MemberNames.FirstOrDefault());}
 public void RoleRequired(params string[] roles)=>Require(UserId>0&&roles.Contains(Role),"Bạn không có quyền thực hiện thao tác này.",403);
 public void RequireUseCase(string useCase)=>Require(SucAccess.Allows(http.HttpContext?.User??new ClaimsPrincipal(),useCase),"Vai trò của bạn không được sử dụng chức năng này.",403);
 public void CheckVersion(object entity,string version,string? code=null){var p=entity.GetType().GetProperty("RowVersion");var matches=p!=null&&Token((byte[])p.GetValue(entity)!)==version;if(code!=null)Ensure(matches,code);else Require(matches,"Dữ liệu vừa thay đổi ở phiên khác. Vui lòng tải lại.",409);}
 public async Task<T> Find<T>(long id) where T:class=>await db.Set<T>().FindAsync(id)??throw new BusinessException("Không tìm thấy dữ liệu.",404);
 public void Dates(DateOnly start,DateOnly? end)=>Require(start!=default&&(end==null||end>=start),"Ngày kết thúc phải từ ngày bắt đầu trở đi.",400);
 private readonly List<string> pendingFiles=[];
 public async Task Execute(Func<Task> work){
  try {
   for(var attempt=0;;attempt++){
    await using var tx=await db.Database.BeginTransactionAsync(IsolationLevel.Serializable);
    try{await work();await db.SaveChangesAsync();await tx.CommitAsync();pendingFiles.Clear();return;}
    catch(Exception e) when(SqlError(e) is 1205 or -2){await tx.RollbackAsync();db.ChangeTracker.Clear();if(attempt>=2)throw new BusinessException("Hệ thống đang bận. Vui lòng thử lại sau.",503,"CSDL_TAM_THOI");await Task.Delay(Random.Shared.Next(200,801));}
   }
  }catch{db.ChangeTracker.Clear();foreach(var path in pendingFiles)if(File.Exists(path))File.Delete(path);pendingFiles.Clear();throw;}
 }
 private static int? SqlError(Exception e)=>e is SqlException s?s.Number:e.InnerException==null?null:SqlError(e.InnerException);
 public void Notify(long id,string text,string url,string type="NghiepVu")=>db.ThongBao.Add(new(){MaNguoiNhan=id,LoaiThongBao=type,NoiDung=text,DuongDan=url});
 public void Audit(string kind,string target,long id,string? before,string? after,string? reason=null)=>db.NhatKyThaoTac.Add(new(){MaTaiKhoan=UserId==0?null:UserId,LoaiSuKien=kind,DoiTuong=target,MaDoiTuong=id,TrangThaiTruoc=before,TrangThaiSau=after,LyDo=reason,DiaChiIP=http.HttpContext?.Connection.RemoteIpAddress?.ToString()});
 public async Task<NhaCungCapDichVu> MyProvider()=>await db.NhaCungCapDichVu.SingleOrDefaultAsync(x=>x.MaTaiKhoan==UserId)??throw new BusinessException("Không tìm thấy nhà cung cấp.",403);
 public async Task<bool> ProviderActive(long id)=>await db.NhaCungCapDichVu.AnyAsync(x=>x.MaNhaCungCap==id&&x.TrangThaiXacMinh=="DaXacMinh"&&x.TrangThaiQuyenHoatDong=="DangHoatDong"&&db.TaiKhoan.Any(a=>a.MaTaiKhoan==x.MaTaiKhoan&&a.TrangThai=="HoatDong"));
 public IQueryable<DichVuDuLich> PublicServices()=>db.DichVuDuLich.Where(x=>x.TrangThaiCongBo=="DaDuyet"&&db.NhaCungCapDichVu.Any(p=>p.MaNhaCungCap==x.MaNhaCungCap&&p.TrangThaiQuyenHoatDong!="DaThuHoi"));
 public async Task<List<string>> Regions(){var cache=http.HttpContext!.RequestServices.GetRequiredService<IMemoryCache>();return (await cache.GetOrCreateAsync("DanhMuc.KhuVuc",async entry=>{entry.AbsoluteExpirationRelativeToNow=TimeSpan.FromMinutes(10);return await db.DiaDiemDuLich.Where(x=>x.DangHienThi).Select(x=>x.KhuVuc).Union(PublicServices().Select(x=>x.KhuVucPhucVu)).Distinct().OrderBy(x=>x).ToListAsync();}))!;}
 public async Task<(List<DichVuDuLich> Services,List<DiaDiemDuLich> Places)> Explore(string? q,string? region,string? type,decimal? min,decimal? max,int page=1){
  RequireUseCase(SucAccess.TravelSearch);
  type=DanhMuc.ChuanHoa(type);Ensure((q?.Length??0)<=100&&page>=1&&(min==null||min is >=0 and <=1000000000)&&(max==null||max is >=0 and <=1000000000)&&(min==null||max==null||min<=max)&&(string.IsNullOrEmpty(type)||type=="DiaDiem"||DanhMuc.LoaiDichVu.Contains(type))&&(string.IsNullOrEmpty(region)||(await Regions()).Contains(region)),"0101-01");
  var s=PublicServices().AsNoTracking();var p=db.DiaDiemDuLich.Where(x=>x.DangHienThi).AsNoTracking();
  if(!string.IsNullOrWhiteSpace(q)){q=q.Trim();s=s.Where(x=>x.TenDichVu.Contains(q)||(x.MoTa!=null&&x.MoTa.Contains(q)));p=p.Where(x=>x.TenDiaDiem.Contains(q)||(x.MoTa!=null&&x.MoTa.Contains(q)));}
  if(!string.IsNullOrEmpty(region)){s=s.Where(x=>x.KhuVucPhucVu==region);p=p.Where(x=>x.KhuVuc==region);}
  if(!string.IsNullOrEmpty(type)){var legacy=DanhMuc.Ten(type);s=s.Where(x=>x.LoaiDichVu==type||x.LoaiDichVu==legacy);if(type!="DiaDiem")p=p.Where(x=>false);else s=s.Where(x=>false);}
  if(min!=null)s=s.Where(x=>x.GiaThamKhao>=min);if(max!=null)s=s.Where(x=>x.GiaThamKhao<=max);if(min!=null||max!=null)p=p.Where(x=>false);
  return(await s.OrderBy(x=>x.TenDichVu).ThenBy(x=>x.MaDichVu).Skip((page-1)*20).Take(20).ToListAsync(),await p.OrderBy(x=>x.TenDiaDiem).ThenBy(x=>x.MaDiaDiem).Skip((page-1)*20).Take(20).ToListAsync());
 }
 public async Task<List<ThongBao>> Notifications()=>await db.ThongBao.Where(x=>x.MaNguoiNhan==UserId).OrderByDescending(x=>x.ThoiDiemTao).Take(100).ToListAsync();
 public async Task<string?> MarkRead(long id){var n=await db.ThongBao.SingleOrDefaultAsync(x=>x.MaThongBao==id&&x.MaNguoiNhan==UserId)??throw new BusinessException("Không tìm thấy thông báo.",404);n.DaDoc=true;await db.SaveChangesAsync();return n.DuongDan;}
 public async Task<int> UnreadCount()=>UserId==0?0:await db.ThongBao.CountAsync(x=>x.MaNguoiNhan==UserId&&!x.DaDoc);
 private async Task<List<(string Name,string Path,string Type,int Size)>> StoreFiles(List<IFormFile> files){
  Require(files.Count<=5,"Tối đa 5 tệp.",400);var result=new List<(string,string,string,int)>();var bytes=new List<(IFormFile File,byte[] Data,string Extension)>();
  foreach(var f in files){var ext=Path.GetExtension(f.FileName).ToLowerInvariant();Require(new[]{".pdf",".jpg",".jpeg",".png"}.Contains(ext)&&f.Length>0&&f.Length<=5242880,"Chỉ nhận PDF/JPG/PNG, tối đa 5 MB mỗi tệp.",400);using var ms=new MemoryStream();await f.CopyToAsync(ms);var a=ms.ToArray();Require((ext==".pdf"&&a.Length>4&&System.Text.Encoding.ASCII.GetString(a,0,5)=="%PDF-")||((ext==".jpg"||ext==".jpeg")&&a.Length>3&&a[0]==255&&a[1]==216&&a[2]==255)||(ext==".png"&&a.Length>8&&a.Take(8).SequenceEqual(new byte[]{137,80,78,71,13,10,26,10})),"Nội dung tệp không đúng định dạng.",400);bytes.Add((f,a,ext==".jpeg"?"jpg":ext[1..]));}
  var directory=Path.Combine(env.ContentRootPath,"App_Data","uploads",DateTime.UtcNow.Year.ToString());Directory.CreateDirectory(directory);try{foreach(var f in bytes){var name=Guid.NewGuid()+"."+f.Extension;var path=Path.Combine(directory,name);pendingFiles.Add(path);await File.WriteAllBytesAsync(path,f.Data);result.Add((Path.GetFileName(f.File.FileName),DateTime.UtcNow.Year+"/"+name,f.Extension,f.Data.Length));}}catch{foreach(var path in pendingFiles)if(File.Exists(path))File.Delete(path);pendingFiles.Clear();throw;}return result;
 }
}
