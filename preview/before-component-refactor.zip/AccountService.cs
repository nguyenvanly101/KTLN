using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
namespace HoTroDuLich.Web.Services;

public partial class TravelService
{
 private static readonly TaiKhoan FakeAccount=new();
 private static readonly string FakePasswordHash=new PasswordHasher<TaiKhoan>().HashPassword(FakeAccount,Guid.NewGuid().ToString());
 public static string? NormalizePhone(string? value){if(string.IsNullOrWhiteSpace(value))return null;var phone=new string(value.Where(c=>!char.IsWhiteSpace(c)&&c!='-'&&c!='.').ToArray());if(phone.StartsWith("+84"))phone="0"+phone[3..];else if(phone.StartsWith("0084"))phone="0"+phone[4..];return phone;}
 public static bool ValidPassword(string value,string email)=>value.Length is >=8 and <=100&&value.Any(char.IsLetter)&&value.Any(char.IsDigit)&&!value.Contains(email,StringComparison.OrdinalIgnoreCase);
 public async Task<TaiKhoan> Authenticate(LoginInput i){
  Validate(i,"1101-01");var identity=i.Email.Trim();var email=identity.ToLowerInvariant();var phone=NormalizePhone(identity);var a=identity.Contains('@')?await db.TaiKhoan.SingleOrDefaultAsync(x=>x.Email==email):await db.TaiKhoan.SingleOrDefaultAsync(x=>x.SoDienThoai==phone);var hasher=new PasswordHasher<TaiKhoan>();var check=hasher.VerifyHashedPassword(a??FakeAccount,a?.MatKhauBam??FakePasswordHash,i.Password);
  if(a==null||check==PasswordVerificationResult.Failed){Audit("DangNhap","TaiKhoan",0,null,"ThatBai","Định danh: "+identity[..Math.Min(identity.Length,2)]+"***");await db.SaveChangesAsync();Ensure(false,"1101-02","Password");}
  Ensure(a!.TrangThai=="HoatDong","1101-03");await Execute(async()=>{if(check==PasswordVerificationResult.SuccessRehashNeeded)a.MatKhauBam=hasher.HashPassword(a,i.Password);a.ThoiDiemDangNhapCuoi=DateTime.UtcNow;Audit("DangNhap","TaiKhoan",a.MaTaiKhoan,null,"ThanhCong");});return a;
 }
 public async Task Register(RegisterInput i){
  Ensure(new[]{Traveler,ProviderRole}.Contains(i.Role),"1001-01");i.Phone=NormalizePhone(i.Phone);i.ContactPhone=NormalizePhone(i.ContactPhone);Validate(i,"1001-02");var email=i.Email.Trim().ToLowerInvariant();Ensure(ValidPassword(i.Password,email)&&i.Password==i.ConfirmPassword,"1001-03","Password");
  Ensure(!await db.TaiKhoan.AnyAsync(x=>x.Email==email||(i.Phone!=null&&x.SoDienThoai==i.Phone)),"1001-04");var files=await StoreFiles(i.Role==ProviderRole?i.Documents:[]);
  await Execute(async()=>{
   Ensure(!await db.TaiKhoan.AnyAsync(x=>x.Email==email||(i.Phone!=null&&x.SoDienThoai==i.Phone)),"1001-04");var a=new TaiKhoan{Email=email,SoDienThoai=i.Phone,VaiTro=i.Role,TrangThai="HoatDong"};a.MatKhauBam=new PasswordHasher<TaiKhoan>().HashPassword(a,i.Password);db.Add(a);await db.SaveChangesAsync();db.Add(new HoSoNguoiDung{MaTaiKhoan=a.MaTaiKhoan,TenHienThi=i.Name.Trim(),ThongTinChiaSe="RiengTu"});
   if(i.Role==ProviderRole){var p=new NhaCungCapDichVu{MaTaiKhoan=a.MaTaiKhoan,TenDonVi=i.Organization!.Trim(),DiaChi=i.Address!.Trim(),SoDienThoai=i.ContactPhone!,EmailLienHe=i.ContactEmail!.Trim().ToLowerInvariant(),NguoiLienHe=i.ContactName!.Trim(),LoaiHinh=i.OrganizationType!.Trim(),TrangThaiXacMinh="ChoXacMinh"};db.Add(p);await db.SaveChangesAsync();var h=new HoSoXacMinhNhaCungCap{MaNhaCungCap=p.MaNhaCungCap,NguoiDaiDien=i.Representative!.Trim(),NoiDungDangKy=i.RegistrationDescription!.Trim(),TrangThaiXuLy="ChoXacMinh"};db.Add(h);await db.SaveChangesAsync();foreach(var f in files)db.Add(new TaiLieuXacMinh{MaHoSo=h.MaHoSo,TenTepGoc=f.Name,DuongDan=f.Path,LoaiTep=f.Type,KichThuoc=f.Size,LanNop=0});}
   Audit("DangKy","TaiKhoan",a.MaTaiKhoan,null,i.Role);
  });
 }
 public async Task<TaiKhoan> ChangePassword(PasswordChangeInput i){Validate(i,"1001-03");var a=await Find<TaiKhoan>(UserId);var hasher=new PasswordHasher<TaiKhoan>();Ensure(hasher.VerifyHashedPassword(a,a.MatKhauBam,i.OldPassword)!=PasswordVerificationResult.Failed,"1101-02","OldPassword");Ensure(ValidPassword(i.NewPassword,a.Email)&&i.NewPassword==i.ConfirmPassword&&i.NewPassword!=i.OldPassword,"1001-03","NewPassword");await Execute(async()=>{a.MatKhauBam=hasher.HashPassword(a,i.NewPassword);a.PhaiDoiMatKhau=false;a.DauPhien=Guid.NewGuid();Audit("DoiMatKhau","TaiKhoan",a.MaTaiKhoan,null,"DaDoi");});return a;}
 public async Task LogLogout(){Audit("DangXuat","TaiKhoan",UserId,null,"KetThucPhien");await db.SaveChangesAsync();}
 public async Task<HoSoNguoiDung> Profile()=>await db.HoSoNguoiDung.SingleAsync(x=>x.MaTaiKhoan==UserId);
 public async Task<ProfileInput> ProfileForm(){var p=await Profile();var a=await Find<TaiKhoan>(UserId);var n=await db.NhaCungCapDichVu.SingleOrDefaultAsync(x=>x.MaTaiKhoan==UserId);return new(){Version=Token(p.RowVersion),Name=p.TenHienThi,Phone=a.SoDienThoai,Bio=p.GioiThieu,City=p.NoiSinhSong,Interests=p.SoThich,Privacy=p.ThongTinChiaSe,ProviderVersion=n==null?"":Token(n.RowVersion),ContactName=n?.NguoiLienHe,Address=n?.DiaChi,ContactPhone=n?.SoDienThoai,ContactEmail=n?.EmailLienHe};}
 public async Task SaveProfile(ProfileInput i){
  RequireUseCase(SucAccess.Profile);i.Phone=NormalizePhone(i.Phone);i.ContactPhone=NormalizePhone(i.ContactPhone);Validate(i,"1201-01");Ensure(new[]{"CongKhai","KhiKetNoi","RiengTu"}.Contains(i.Privacy),"1201-01","Privacy");
  var files=new List<(string Name,string Path,string Type,int Size)>();if(i.Avatar!=null){Ensure(new[]{".jpg",".jpeg",".png"}.Contains(Path.GetExtension(i.Avatar.FileName).ToLowerInvariant()),"1201-01","Avatar");files=await StoreFiles([i.Avatar]);}string? previousAvatar=null;
  await Execute(async()=>{var p=await Profile();CheckVersion(p,i.Version,"1201-03");var a=await Find<TaiKhoan>(UserId);Ensure(i.Phone==null||!await db.TaiKhoan.AnyAsync(x=>x.MaTaiKhoan!=UserId&&x.SoDienThoai==i.Phone),"1201-02","Phone");p.TenHienThi=i.Name.Trim();p.GioiThieu=i.Bio;p.NoiSinhSong=i.City;p.SoThich=i.Interests;p.ThongTinChiaSe=i.Privacy;p.ThoiDiemCapNhat=DateTime.UtcNow;a.SoDienThoai=i.Phone;if(files.Count>0){previousAvatar=p.AnhDaiDien;p.AnhDaiDien=files[0].Path;}
   if(Role==ProviderRole){var n=await MyProvider();CheckVersion(n,i.ProviderVersion,"1201-03");Ensure(!string.IsNullOrWhiteSpace(i.ContactName)&&!string.IsNullOrWhiteSpace(i.Address)&&!string.IsNullOrWhiteSpace(i.ContactPhone)&&!string.IsNullOrWhiteSpace(i.ContactEmail),"1201-01");n.NguoiLienHe=i.ContactName!.Trim();n.DiaChi=i.Address!.Trim();n.SoDienThoai=i.ContactPhone!;n.EmailLienHe=i.ContactEmail!.Trim().ToLowerInvariant();}
  });if(previousAvatar!=null&&files.Count>0){var old=UploadPath(previousAvatar);if(File.Exists(old))File.Delete(old);}
 }
 private ITimeLimitedDataProtector DeactivationProtector=>http.HttpContext!.RequestServices.GetRequiredService<IDataProtectionProvider>().CreateProtector("HoTroDuLich.NgungTaiKhoan.v1").ToTimeLimitedDataProtector();
 public async Task<DeactivationReview> DeactivationObligations(){
  RoleRequired(Traveler,ProviderRole);var obligations=new List<AccountObligation>();var bookings=await AccessibleBookings().Where(x=>new[]{"ChoPhanHoi","DeXuatKhac","DaXacNhan","ChoKiemTra"}.Contains(x.TrangThai)).ToListAsync();obligations.AddRange(bookings.Select(x=>new AccountObligation("Yêu cầu #"+x.MaYeuCau+" · "+Labels.Status(x.TrangThai),"/Bookings/Detail/"+x.MaYeuCau)));
  if(Role==Traveler){var agreements=await AccessibleAgreements().Where(x=>x.TrangThai=="DaXacNhan").ToListAsync();obligations.AddRange(agreements.Select(x=>new AccountObligation("Thỏa thuận đồng hành #"+x.MaThoaThuan,"/Companions/Agreement/"+x.MaDeNghi)));}
  else {var changes=await db.DeNghiDieuChinhDichVu.Where(x=>new[]{"ChoPhanHoi","DeXuatKhac"}.Contains(x.TrangThai)&&AccessibleBookings().Any(y=>y.MaYeuCau==x.MaYeuCau)).ToListAsync();obligations.AddRange(changes.Select(x=>new AccountObligation("Đề nghị điều chỉnh #"+x.MaDeNghi,"/Bookings/Changes/"+x.MaYeuCau)));}
  var needs=await db.NhuCauDongHanh.CountAsync(x=>x.MaTaiKhoan==UserId&&x.TrangThaiCongBo=="DangCongBo");var connections=await AccessibleConnections().CountAsync(x=>x.TrangThai=="ChoPhanHoi");var services=Role==ProviderRole?await db.DichVuDuLich.CountAsync(x=>x.TrangThaiTiepNhan=="TiepNhan"&&db.NhaCungCapDichVu.Any(p=>p.MaNhaCungCap==x.MaNhaCungCap&&p.MaTaiKhoan==UserId)):0;return new(obligations,needs,connections,services,null);
 }
 public async Task<DeactivationReview> Reauthenticate(string password){RoleRequired(Traveler,ProviderRole);var a=await Find<TaiKhoan>(UserId);if(new PasswordHasher<TaiKhoan>().VerifyHashedPassword(a,a.MatKhauBam,password)!=PasswordVerificationResult.Failed){var review=await DeactivationObligations();return review with{ConfirmationToken=review.Obligations.Count==0?DeactivationProtector.Protect(UserId+"|"+a.DauPhien,TimeSpan.FromMinutes(5)):null};}Audit("XacThucLai","TaiKhoan",UserId,null,"ThatBai");await db.SaveChangesAsync();Ensure(false,"1401-01","Password");throw new InvalidOperationException();}
 public async Task Deactivate(string token){
  RoleRequired(Traveler,ProviderRole);string? evidence=null;try{evidence=DeactivationProtector.Unprotect(token);}catch(CryptographicException){Ensure(false,"1401-02");}catch(ArgumentException){Ensure(false,"1401-02");}
  await Execute(async()=>{
   var a=await Find<TaiKhoan>(UserId);Ensure(evidence==UserId+"|"+a.DauPhien,"1401-02");var review=await DeactivationObligations();Ensure(review.Obligations.Count==0,"1401-03");a.TrangThai="DaNgung";a.ThoiDiemNgung=DateTime.UtcNow;a.DauPhien=Guid.NewGuid();
   foreach(var n in await db.NhuCauDongHanh.Where(x=>x.MaTaiKhoan==UserId&&x.TrangThaiCongBo=="DangCongBo").ToListAsync())n.TrangThaiCongBo="DungCongBo";
   foreach(var c in await AccessibleConnections().Where(x=>x.TrangThai=="ChoPhanHoi").ToListAsync()){c.TrangThai="HetHieuLuc";c.ThoiDiemPhanHoi=DateTime.UtcNow;var n=await Find<NhuCauDongHanh>(c.MaNhuCau);Notify(c.MaNguoiGui==UserId?n.MaTaiKhoan:c.MaNguoiGui,"Đề nghị kết nối hết hiệu lực do một bên ngừng tài khoản.","/dong-hanh/de-nghi/xem-de-nghi/"+c.MaDeNghi,"DeNghiHetHieuLuc");}
   foreach(var t in await AccessibleAgreements().Where(x=>x.TrangThai=="ChoXacNhan").ToListAsync()){t.TrangThai="DaThayThe";t.LyDo="Một bên ngừng tài khoản";}
   if(Role==ProviderRole){var p=await MyProvider();foreach(var s in await db.DichVuDuLich.Where(x=>x.MaNhaCungCap==p.MaNhaCungCap&&x.TrangThaiTiepNhan=="TiepNhan").ToListAsync()){s.TrangThaiTiepNhan="KhongTiepNhanMoi";s.MaQuyetDinhKhongTiepNhan=null;}}
   Audit("NgungTaiKhoan","TaiKhoan",UserId,"HoatDong","DaNgung",$"{review.Needs} nhu cầu; {review.Connections} đề nghị; {review.Services} dịch vụ");
  });
 }
}
