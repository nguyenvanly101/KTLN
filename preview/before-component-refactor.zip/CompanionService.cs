using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using Microsoft.EntityFrameworkCore;
namespace HoTroDuLich.Web.Services;

public partial class TravelService
{
 private long CompanionViewer=>Role==Traveler?UserId:0;
 private async Task EnsureConnectionActive(DeNghiKetNoiDongHanh c){var n=await Find<NhuCauDongHanh>(c.MaNhuCau);Ensure(await db.TaiKhoan.CountAsync(a=>(a.MaTaiKhoan==c.MaNguoiGui||a.MaTaiKhoan==n.MaTaiKhoan)&&a.TrangThai=="HoatDong")==2,"0402-05");}
 public IQueryable<NhuCauDongHanh> VisibleNeeds(){var viewer=CompanionViewer;return db.NhuCauDongHanh.Where(n=>n.TrangThaiCongBo=="DangCongBo"&&n.NgayKetThuc>=Today&&db.TaiKhoan.Any(a=>a.MaTaiKhoan==n.MaTaiKhoan&&a.TrangThai=="HoatDong")&&(viewer>0||n.PhamViChiaSe=="CongKhai"));}
 private IQueryable<NhuCauDongHanh> SharedNeeds(IQueryable<NhuCauDongHanh> query){
  var viewer=CompanionViewer;
  return query.AsNoTracking().Select(n=>new NhuCauDongHanh{
   MaNhuCau=n.MaNhuCau,MaTaiKhoan=n.MaTaiKhoan,DiemDen=n.DiemDen,NgayBatDau=n.NgayBatDau,NgayKetThuc=n.NgayKetThuc,HinhThucDi=n.HinhThucDi,PhamViChiaSe=n.PhamViChiaSe,ThoiDiemDang=n.ThoiDiemDang,TrangThaiCongBo=n.TrangThaiCongBo,
   NoiDung=n.PhamViChiaSe!="KhiKetNoi"||n.MaTaiKhoan==viewer||db.DeNghiKetNoiDongHanh.Any(c=>c.MaNhuCau==n.MaNhuCau&&c.MaNguoiGui==viewer&&c.TrangThai=="DaChapNhan")?n.NoiDung:"",
   NganSachDuKien=n.PhamViChiaSe!="KhiKetNoi"||n.MaTaiKhoan==viewer||db.DeNghiKetNoiDongHanh.Any(c=>c.MaNhuCau==n.MaNhuCau&&c.MaNguoiGui==viewer&&c.TrangThai=="DaChapNhan")?n.NganSachDuKien:null,
   MongMuonDongHanh=n.PhamViChiaSe!="KhiKetNoi"||n.MaTaiKhoan==viewer||db.DeNghiKetNoiDongHanh.Any(c=>c.MaNhuCau==n.MaNhuCau&&c.MaNguoiGui==viewer&&c.TrangThai=="DaChapNhan")?n.MongMuonDongHanh:null
  });
 }
 public async Task<List<NhuCauDongHanh>> Needs(string? q,DateOnly? start,DateOnly? end,decimal? budget,string? style,int page=1){
  RequireUseCase(SucAccess.CompanionSearch);style=DanhMuc.ChuanHoa(style);Ensure((start==null||end==null||end>=start)&&(budget==null||budget is >=0 and <=1000000000)&&page>=1&&(q?.Length??0)<=200&&(style==""||DanhMuc.HinhThucDi.Contains(style)),"0301-01");
  var viewer=CompanionViewer;var n=VisibleNeeds().Where(x=>x.MaTaiKhoan!=viewer);
  if(!string.IsNullOrWhiteSpace(q)){q=q.Trim();n=n.Where(x=>x.DiemDen.Contains(q));}if(start!=null)n=n.Where(x=>x.NgayKetThuc>=start);if(end!=null)n=n.Where(x=>x.NgayBatDau<=end);
  if(budget!=null)n=n.Where(x=>x.NganSachDuKien==null||x.NganSachDuKien<=budget);if(style!=""){var legacy=DanhMuc.Ten(style);n=n.Where(x=>x.HinhThucDi==style||x.HinhThucDi==legacy);}
  return await SharedNeeds(n.OrderByDescending(x=>x.ThoiDiemDang).ThenByDescending(x=>x.MaNhuCau).Skip((page-1)*20).Take(20)).ToListAsync();
 }
 public async Task<NhuCauDongHanh> Need(long id){RequireUseCase(SucAccess.CompanionSearch);return await SharedNeeds(VisibleNeeds().Where(x=>x.MaNhuCau==id)).SingleOrDefaultAsync()??throw new BusinessException(MaLoi.TatCa["0301-02"].Message,404,"0301-02");}
 public async Task<List<NhuCauDongHanh>> MyNeeds()=>await db.NhuCauDongHanh.Where(x=>x.MaTaiKhoan==UserId).OrderByDescending(x=>x.ThoiDiemDang).ToListAsync();
 public void ValidateNeed(NeedInput i){i.Style=string.IsNullOrWhiteSpace(i.Style)?null:DanhMuc.ChuanHoa(i.Style);Validate(i,"0302-01");Ensure(i.Start>=Today&&i.End>=i.Start&&new[]{"CongKhai","DaDangNhap","KhiKetNoi"}.Contains(i.Privacy)&&(i.Style==null||DanhMuc.HinhThucDi.Contains(i.Style)),"0302-01");}
 public async Task SaveNeed(NeedInput i){RoleRequired(Traveler);ValidateNeed(i);await Execute(async()=>{NhuCauDongHanh n;if(i.Id==0){n=new(){MaTaiKhoan=UserId,TrangThaiCongBo="DangCongBo"};db.Add(n);}else{n=await db.NhuCauDongHanh.SingleOrDefaultAsync(x=>x.MaNhuCau==i.Id&&x.MaTaiKhoan==UserId)??throw new BusinessException("Không tìm thấy nhu cầu.",404);CheckVersion(n,i.Version);}n.DiemDen=i.Destination.Trim();n.NoiDung=i.Content.Trim();n.NgayBatDau=i.Start;n.NgayKetThuc=i.End;n.NganSachDuKien=i.Budget;n.HinhThucDi=i.Style;n.MongMuonDongHanh=i.Wishes;n.PhamViChiaSe=i.Privacy;});}
 public async Task StopNeed(CommandInput i){RoleRequired(Traveler);await Execute(async()=>{var n=await db.NhuCauDongHanh.SingleOrDefaultAsync(x=>x.MaNhuCau==i.Id&&x.MaTaiKhoan==UserId)??throw new BusinessException("Không tìm thấy nhu cầu.",404);CheckVersion(n,i.Version);n.TrangThaiCongBo="DungCongBo";});}
 public async Task CheckConnect(long id){RoleRequired(Traveler);var n=await VisibleNeeds().SingleOrDefaultAsync(x=>x.MaNhuCau==id);Ensure(n!=null,"0401-01");Ensure(n!.MaTaiKhoan!=UserId,"0401-02");Ensure(!await db.DeNghiKetNoiDongHanh.AnyAsync(x=>x.MaNguoiGui==UserId&&x.MaNhuCau==id&&x.TrangThai=="ChoPhanHoi"),"0401-03");Ensure(!await db.DeNghiKetNoiDongHanh.AnyAsync(x=>x.MaNguoiGui==UserId&&x.MaNhuCau==id&&x.TrangThai=="DaChapNhan"),"0401-04");}
 public async Task Connect(CommandInput i){RoleRequired(Traveler);Require(i.Text.Length<=1000,"Lời giới thiệu tối đa 1000 ký tự.",400);await Execute(async()=>{await CheckConnect(i.Id);var n=await Find<NhuCauDongHanh>(i.Id);db.Add(new DeNghiKetNoiDongHanh{MaNhuCau=i.Id,MaNguoiGui=UserId,LoiGioiThieu=string.IsNullOrWhiteSpace(i.Text)?null:i.Text.Trim(),TrangThai="ChoPhanHoi"});Notify(n.MaTaiKhoan,"Bạn nhận được đề nghị kết nối đồng hành.","/dong-hanh/de-nghi","DeNghiKetNoiMoi");});}
 public IQueryable<DeNghiKetNoiDongHanh> AccessibleConnections()=>db.DeNghiKetNoiDongHanh.Where(x=>x.MaNguoiGui==UserId||db.NhuCauDongHanh.Any(n=>n.MaNhuCau==x.MaNhuCau&&n.MaTaiKhoan==UserId));
 public IQueryable<ThoaThuanDongHanh> AccessibleAgreements()=>db.ThoaThuanDongHanh.Where(t=>AccessibleConnections().Any(c=>c.MaDeNghi==t.MaDeNghi));
 public async Task<List<DeNghiKetNoiDongHanh>> Connections()=>await AccessibleConnections().OrderByDescending(x=>x.ThoiDiemGui).ToListAsync();
 public async Task<DeNghiKetNoiDongHanh> Connection(long id){RoleRequired(Traveler);return await AccessibleConnections().SingleOrDefaultAsync(x=>x.MaDeNghi==id)??throw new BusinessException(MaLoi.TatCa["0401-05"].Message,404,"0401-05");}
 public async Task ConnectionAction(CommandInput i){RoleRequired(Traveler);await Execute(async()=>{var c=await Connection(i.Id);CheckVersion(c,i.Version,"0401-07");Ensure(c.TrangThai=="ChoPhanHoi","0401-07");var n=await Find<NhuCauDongHanh>(c.MaNhuCau);if(i.Decision=="DaRut")Ensure(c.MaNguoiGui==UserId,"0401-06");else{Ensure(n.MaTaiKhoan==UserId,"0401-06");Require(new[]{"DaChapNhan","TuChoi"}.Contains(i.Decision),"Quyết định không hợp lệ.",400);Ensure(await db.TaiKhoan.CountAsync(x=>(x.MaTaiKhoan==c.MaNguoiGui||x.MaTaiKhoan==n.MaTaiKhoan)&&x.TrangThai=="HoatDong")==2,"0401-08");}c.TrangThai=i.Decision;c.ThoiDiemPhanHoi=DateTime.UtcNow;Notify(UserId==c.MaNguoiGui?n.MaTaiKhoan:c.MaNguoiGui,"Đề nghị kết nối: "+Labels.Status(i.Decision),"/dong-hanh/de-nghi/xem-de-nghi/"+c.MaDeNghi,"DeNghiKetNoiDaPhanHoi");});}
 public async Task<List<ThoaThuanDongHanh>> Agreements(long connection){await Connection(connection);return await db.ThoaThuanDongHanh.Where(x=>x.MaDeNghi==connection).OrderByDescending(x=>x.PhienBan).ToListAsync();}
 public async Task<AgreementInput> AgreementForm(long connection){var c=await Connection(connection);Ensure(c.TrangThai=="DaChapNhan","0402-01");var history=await Agreements(connection);Ensure(!history.Any(x=>x.TrangThai is "DaNgung" or "MotBenDaRut"),"0402-02");Ensure(!history.Any(x=>x.TrangThai=="ChoXacNhan"&&x.LoaiPhienBan=="DeNghiNgung"),"0402-03");var current=history.FirstOrDefault(x=>x.TrangThai=="ChoXacNhan")??history.FirstOrDefault(x=>x.TrangThai=="DaXacNhan");var n=await Find<NhuCauDongHanh>(c.MaNhuCau);return new(){ConnectionId=connection,BaseVersion=history.FirstOrDefault()?.PhienBan??0,Version=Token(c.RowVersion),Destination=current?.NoiDen??n.DiemDen,Start=current?.NgayDi??n.NgayBatDau,End=current?.NgayVe??n.NgayKetThuc,Budget=current?.NganSach,Scope=current?.PhamViDiCung};}
 public async Task ProposeAgreement(AgreementInput i){
  RoleRequired(Traveler);if(i.Kind=="NoiDung"){Validate(i,"0402-04");Ensure(i.Start>=Today&&i.End>=i.Start,"0402-04");}Require(new[]{"NoiDung","DeNghiNgung"}.Contains(i.Kind),"Loại phiên bản không hợp lệ.",400);
  await Execute(async()=>{
   var c=await Connection(i.ConnectionId);Ensure(c.TrangThai=="DaChapNhan","0402-01");await EnsureConnectionActive(c);
   var history=await db.ThoaThuanDongHanh.Where(x=>x.MaDeNghi==i.ConnectionId).OrderByDescending(x=>x.PhienBan).ToListAsync();
   Ensure(!history.Any(x=>x.TrangThai is "DaNgung" or "MotBenDaRut"),"0402-02");Ensure((history.FirstOrDefault()?.PhienBan??0)==i.BaseVersion,"0402-06");
   var pending=history.SingleOrDefault(x=>x.TrangThai=="ChoXacNhan");var active=history.SingleOrDefault(x=>x.TrangThai=="DaXacNhan");
   if(i.Kind=="DeNghiNgung"){Ensure(active!=null,"0402-10");Ensure(pending==null,"0402-11");i.Start=active!.NgayDi;i.End=active.NgayVe;i.Destination=active.NoiDen;i.Budget=active.NganSach;i.Scope=active.PhamViDiCung;}
   else{Ensure(pending?.LoaiPhienBan!="DeNghiNgung","0402-03");Ensure(active==null||active.NgayDi!=i.Start||active.NgayVe!=i.End||active.NoiDen!=i.Destination.Trim()||active.NganSach!=i.Budget||active.PhamViDiCung!=i.Scope,"0402-07");if(pending!=null){pending.TrangThai="DaThayThe";pending.LyDo="Đã có đề xuất mới";await db.SaveChangesAsync();}}
   var t=new ThoaThuanDongHanh{MaDeNghi=i.ConnectionId,PhienBan=i.BaseVersion+1,NgayDi=i.Start,NgayVe=i.End,NoiDen=i.Destination.Trim(),NganSach=i.Budget,PhamViDiCung=i.Scope,MaNguoiDeXuat=UserId,LoaiPhienBan=i.Kind,TrangThai="ChoXacNhan"};db.Add(t);await db.SaveChangesAsync();var n=await Find<NhuCauDongHanh>(c.MaNhuCau);Notify(UserId==c.MaNguoiGui?n.MaTaiKhoan:c.MaNguoiGui,"Có đề xuất đồng hành cần xác nhận.","/dong-hanh/thoa-thuan/xem-de-nghi/"+t.MaThoaThuan,i.Kind=="DeNghiNgung"?"DeNghiCungNgung":"ThoaThuanChoXacNhan");
  });
 }
 public async Task AgreementAction(CommandInput i){
  RoleRequired(Traveler);await Execute(async()=>{
   var t=await Find<ThoaThuanDongHanh>(i.Id);var c=await Connection(t.MaDeNghi);CheckVersion(t,i.Version,i.Decision=="Rut"?"0402-10":"0402-06");var n=await Find<NhuCauDongHanh>(c.MaNhuCau);var other=UserId==c.MaNguoiGui?n.MaTaiKhoan:c.MaNguoiGui;string type;
   if(i.Decision=="Rut"){
    Ensure(t.TrangThai=="DaXacNhan","0402-10");t.TrangThai="MotBenDaRut";t.MaNguoiKetThuc=UserId;t.ThoiDiemKetThuc=DateTime.UtcNow;t.LyDo=string.IsNullOrWhiteSpace(i.Reason)?null:i.Reason;
    foreach(var pending in await db.ThoaThuanDongHanh.Where(x=>x.MaDeNghi==t.MaDeNghi&&x.TrangThai=="ChoXacNhan").ToListAsync()){pending.TrangThai="DaThayThe";pending.LyDo="Thỏa thuận đã kết thúc";}type="ThoaThuanMotBenRut";
   }else{
    Ensure(t.MaNguoiDeXuat!=UserId,"0402-08");Ensure(t.TrangThai=="ChoXacNhan"&&i.BusinessVersion==t.PhienBan,"0402-06");Require(new[]{"DaXacNhan","TuChoi"}.Contains(i.Decision),"Quyết định không hợp lệ.",400);
    t.MaNguoiXacNhan=UserId;t.ThoiDiemXacNhan=DateTime.UtcNow;
    if(i.Decision=="TuChoi"){Ensure(!string.IsNullOrWhiteSpace(i.Reason),"0402-09","Reason");t.TrangThai="TuChoi";t.LyDo=i.Reason;type="ThoaThuanBiTuChoi";}
    else{
     await EnsureConnectionActive(c);var old=await db.ThoaThuanDongHanh.SingleOrDefaultAsync(x=>x.MaDeNghi==t.MaDeNghi&&x.TrangThai=="DaXacNhan");
     if(old!=null){old.TrangThai=t.LoaiPhienBan=="DeNghiNgung"?"DaNgung":"DaThayThe";if(t.LoaiPhienBan=="DeNghiNgung"){old.ThoiDiemKetThuc=DateTime.UtcNow;old.MaNguoiKetThuc=UserId;}await db.SaveChangesAsync();}
     t.TrangThai=t.LoaiPhienBan=="DeNghiNgung"?"DaNgung":"DaXacNhan";if(t.LoaiPhienBan=="DeNghiNgung"){t.ThoiDiemKetThuc=DateTime.UtcNow;t.MaNguoiKetThuc=UserId;}type=t.LoaiPhienBan=="DeNghiNgung"?"ThoaThuanDaNgung":"ThoaThuanDaXacNhan";
     Notify(UserId,"Thỏa thuận: "+Labels.Status(t.TrangThai),"/dong-hanh/thoa-thuan/xem-de-nghi/"+t.MaThoaThuan,type);
    }
   }
   Notify(other,"Thỏa thuận: "+Labels.Status(t.TrangThai),"/dong-hanh/thoa-thuan/xem-de-nghi/"+t.MaThoaThuan,type);
  });
 }
}
