using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using Microsoft.EntityFrameworkCore;
namespace HoTroDuLich.Web.Services;

public partial class TravelService {
 public async Task<AdminOverview> AdminOverview() {
  RoleRequired(AdminRole);
  return new(await db.BanCapNhatDichVu.CountAsync(x=>x.TrangThaiDuyet=="ChoDuyet"),
   await db.HoSoXacMinhNhaCungCap.CountAsync(x=>x.TrangThaiXuLy=="ChoXacMinh"),
   await db.NhaCungCapDichVu.CountAsync(), await db.GiaiTrinhNhaCungCap.CountAsync(x=>x.TrangThai=="ChoXemXet"));
 }
 static string SearchText(string? q)=>(q??"").Trim()[..Math.Min((q??"").Trim().Length,100)];
 void ValidFilter(string status, params string[] allowed)=>Require(status==""||allowed.Contains(status),"Bộ lọc trạng thái không hợp lệ.",400);
 async Task<FilteredPage<T>> PageOf<T>(IQueryable<T> rows, string route, string q, string status, int page) {
  var total=await rows.CountAsync();
  page=Math.Clamp(page,1,Math.Max(1,(int)Math.Ceiling(total/20d)));
  return new(await rows.Skip((page-1)*20).Take(20).ToListAsync(),new(route,q,status,page,total));
 }
 public async Task<FilteredPage<AdminReviewRow>> ServiceReviews(string? q,string status,int page) {
  RoleRequired(AdminRole);q=SearchText(q);ValidFilter(status,"ChoDuyet","DaDuyet","CanSua","TuChoi");
  var rows=from v in db.BanCapNhatDichVu.AsNoTracking()
   join s in db.DichVuDuLich on v.MaDichVu equals s.MaDichVu
   join p in db.NhaCungCapDichVu on s.MaNhaCungCap equals p.MaNhaCungCap
   where (status==""||v.TrangThaiDuyet==status)&&(q==""||v.TenDichVu.Contains(q)||p.TenDonVi.Contains(q))
   orderby v.ThoiDiemGui descending,v.MaBanCapNhat descending
   select new AdminReviewRow(v,p.TenDonVi);
  return await PageOf(rows,"/Admin/ServiceReviews",q,status,page);
 }
 public async Task<FilteredPage<AdminVerificationRow>> Verifications(string? q,string status,int page) {
  RoleRequired(AdminRole);q=SearchText(q);ValidFilter(status,"ChoXacMinh","CanBoSung","DaXacMinh","TuChoi");
  var rows=from h in db.HoSoXacMinhNhaCungCap.AsNoTracking()
   join p in db.NhaCungCapDichVu on h.MaNhaCungCap equals p.MaNhaCungCap
   where (status==""||h.TrangThaiXuLy==status)&&(q==""||p.TenDonVi.Contains(q)||h.NguoiDaiDien.Contains(q))
   orderby h.ThoiDiemNop descending,h.MaHoSo descending
   select new AdminVerificationRow(h,p.TenDonVi);
  return await PageOf(rows,"/Admin/Verifications",q,status,page);
 }
 public async Task<FilteredPage<NhaCungCapDichVu>> ProviderRightsList(string? q,string status,int page) {
  RoleRequired(AdminRole);q=SearchText(q);ValidFilter(status,"DangHoatDong","TamDinhChi","DaThuHoi","ChuaDuDieuKien");
  var rows=db.NhaCungCapDichVu.AsNoTracking()
   .Where(p=>(status==""||(status=="ChuaDuDieuKien"?p.TrangThaiQuyenHoatDong==null:p.TrangThaiQuyenHoatDong==status))
    &&(q==""||p.TenDonVi.Contains(q)||p.EmailLienHe.Contains(q)))
   .OrderBy(p=>p.TenDonVi).ThenBy(p=>p.MaNhaCungCap);
  return await PageOf(rows,"/Admin/Providers",q,status,page);
 }
 public async Task<List<YeuCauDatDichVu>> AdjustmentBookings() {
  RoleRequired(Traveler,ProviderRole);
  return await AccessibleBookings().Where(y=>y.TrangThai=="DaXacNhan"||db.DeNghiDieuChinhDichVu.Any(d=>d.MaYeuCau==y.MaYeuCau)).OrderByDescending(y=>y.ThoiDiemGui).ToListAsync();
 }
 public async Task<List<YeuCauDatDichVu>> ResultBookings() {
  RoleRequired(Traveler,ProviderRole);
  return await AccessibleBookings().Where(y=>y.TrangThai=="DaXacNhan"||db.KetQuaCungCapDichVu.Any(r=>r.MaYeuCau==y.MaYeuCau)).OrderByDescending(y=>y.ThoiDiemGui).ToListAsync();
 }
}
