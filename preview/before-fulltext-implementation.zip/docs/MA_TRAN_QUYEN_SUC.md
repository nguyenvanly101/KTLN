# Đối chiếu quyền truy cập theo đặc tả SUC

Nguồn: `Đặc tả SUC (1).docx`, phiên bản 04 ngày 01/11/2026; đọc lại từ tệp người dùng cung cấp. ACT01 = khách du lịch, ACT02 = nhà cung cấp, ACT03 = quản trị viên.

Nguyên tắc: vai trò không kế thừa nhau. Có tên trong “Actor tham gia” không đồng nghĩa được thực hiện toàn bộ thao tác của SUC. Quyền trên bản ghi và trạng thái hiện hành được kiểm tra tiếp ở tầng nghiệp vụ.

| SUC | ACT01 | ACT02 | ACT03 |
| --- | --- | --- | --- |
| 01.01 Tìm thông tin du lịch | Tra cứu và xem chi tiết | Không | Không |
| 02.01 Lập kế hoạch | Tạo, xem, sửa kế hoạch của mình | Không | Không |
| 03.01 Tìm người đồng hành | Tìm và xem nội dung được chia sẻ | Không | Không |
| 03.02 Công bố nhu cầu | Đăng và quản lý bài của mình | Không | Không |
| 04.01 Kết nối | Gửi/rút lời mời của mình; nhận lời/từ chối lời mời gửi tới mình | Không | Không |
| 04.02 Thỏa thuận đồng hành | Đề xuất, phản hồi, rút/ngừng trong kết nối của mình | Không | Không |
| 05.01 Tình huống phát sinh | Ghi nhận, chọn phương án, cập nhật kết quả trong kế hoạch của mình | Không | Không |
| 06.01 Thông tin dịch vụ | Không | Quản lý dịch vụ của mình; chỉ gửi đăng/cập nhật khi đã xác minh và đang hoạt động | Không |
| 06.02 Xét duyệt dịch vụ | Không | Không quyết định duyệt; chỉ nhận kết quả | Duyệt, từ chối, yêu cầu sửa đúng phiên bản |
| 07.01 Đặt dịch vụ | Tạo/sửa/rút yêu cầu của mình; chấp thuận điều kiện thay thế | Xem, phản hồi yêu cầu cho dịch vụ mình sở hữu; không đặt dịch vụ như khách | Không |
| 08.01 Thay đổi/hủy | Gửi/rút đề nghị của mình; chấp thuận điều kiện thay thế | Phản hồi đề nghị cho dịch vụ mình sở hữu; không tự đóng vai khách gửi đề nghị | Không |
| 09.01 Kết quả cung cấp | Xem và gửi phản ánh cho dịch vụ đã đặt | Ghi nhận, đối chiếu kết quả của dịch vụ mình cung cấp; không gửi phản ánh thay khách | Không |
| 10.01 Đăng ký | Đăng ký khi chưa đăng nhập | Đăng ký kèm hồ sơ khi chưa đăng nhập | Không đăng ký qua biểu mẫu công khai |
| 10.02 Xác minh nhà cung cấp | Không | Xem/bổ sung/nộp lại hồ sơ của mình theo luồng hợp lệ; không tự xác minh | Xem và quyết định xác minh |
| 11.01 Đăng nhập | Có | Có | Có |
| 12.01 Cập nhật hồ sơ | Chỉ hồ sơ của mình | Chỉ hồ sơ của mình, không tự sửa vai trò/kết quả xác minh | Không có actor này trong SUC12.01; không mở chức năng sửa hồ sơ |
| 13.01 Quyền hoạt động | Không | Xem quyết định, gửi giải trình của mình | Đình chỉ, khôi phục, thu hồi; xem xét giải trình |
| 14.01 Ngừng tài khoản | Tự yêu cầu khi đủ điều kiện | Tự yêu cầu khi đủ điều kiện | Không có actor này trong SUC14.01 |

## Khách chưa đăng nhập

SUC01.01 và BR10.01-1 cho phép tra cứu công khai. Phạm vi xem trước đăng nhập của SUC03.01 được tài liệu SUC đánh dấu là điểm cần chốt với FR. Bản hiện tại giữ cách xem công khai đã triển khai theo chương thiết kế: chỉ bài có phạm vi `CongKhai`; không gửi lời mời hay ghi dữ liệu. Không mở rộng thành quyền của ACT02/ACT03: khi đang đăng nhập bằng hai vai trò này, các đường dẫn tra cứu của khách đều trả 403. Muốn xem với tư cách khách vãng lai phải đăng xuất thực sự.

## Thực thi

- `Services/SucAccess.cs`: danh mục 18 SUC và actor, được dùng chung cho chính sách máy chủ và menu.
- `SucAuthorizeAttribute`: kiểm tra trước khi vào action, kể cả URL trực tiếp và POST giả lập. Các action của vai trò tham gia còn có giới hạn riêng bằng `Authorize(Roles=...)` và kiểm tra thao tác trong Service.
- Cookie trả HTTP 403 khi đã đăng nhập nhưng sai quyền; không cấp quyền khách du lịch cho Admin hoặc nhà cung cấp.
- `/` và `/Home/Index` đưa ACT02 về `/Provider`, ACT03 về `/Admin`; không dẫn tới trang khám phá dành cho ACT01.
- Header, sidebar, menu tài khoản và các liên kết phụ chỉ chứa chức năng hợp vai trò. Admin không có nút sửa hồ sơ/ngừng tài khoản.
- Chưa xác minh/đình chỉ/thu hồi: không hiện biểu mẫu gửi đăng/cập nhật dịch vụ; kiểm tra server vẫn chặn gửi giả lập. Xử lý các thỏa thuận đã xác nhận, hồ sơ và giải trình vẫn theo các trạng thái được phép của SUC11.01 A1 và BR13.01-4.
- Thông báo, tải tài liệu và nhật ký là màn hình hỗ trợ cho các nghiệp vụ tương ứng. Thông báo chỉ của người nhận; tệp chỉ chủ hồ sơ/giải trình và Admin; nhật ký chỉ Admin. Hiển thị tên tài khoản ở header không phải quyền sửa hồ sơ SUC12.01.

## Kiểm chứng

`tests/actor-access.cjs` đối chiếu HTTP GET/POST cho khách vãng lai và cả ba actor, kiểm tra menu, truy cập bằng URL, giả mạo thao tác trong SUC dùng chung và quyền sở hữu đối tượng. Bộ kiểm thử nghiệp vụ xuyên suốt được giữ ở `tests/http-workflows.cjs`. Dữ liệu chạy kiểm thử nằm ở cơ sở dữ liệu SQL Server riêng.
