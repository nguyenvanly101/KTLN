# Cấu trúc trang theo chức năng

Mỗi nghiệp vụ có URL và màn hình riêng. Trang tổng quan chỉ có số liệu và liên kết tới nghiệp vụ; các mục menu không dùng liên kết cuộn xuống từng phần trên một trang.

| Actor | Chức năng | Danh sách / trang chính | Chi tiết / thao tác |
|---|---|---|---|
| Quản trị viên | Tổng quan | `/Admin` | Chỉ số tổng hợp và lối vào các nghiệp vụ |
| Quản trị viên | Xét duyệt dịch vụ – SUC06.02 | `/Admin/ServiceReviews` | `/Admin/Review/{id}` |
| Quản trị viên | Xác minh nhà cung cấp – SUC10.02 | `/Admin/Verifications` | `/Admin/Verification/{id}` |
| Quản trị viên | Quyền hoạt động – SUC13.01 | `/Admin/Providers` | `/Admin/Provider/{id}` |
| Quản trị viên | Nhật ký hoạt động | `/Admin/Audit` | Nhật ký riêng |
| Nhà cung cấp | Quản lý dịch vụ – SUC06.01 | `/Provider` | `/Provider/Edit/{id}` |
| Nhà cung cấp | Hồ sơ xác minh – SUC10.02 | `/Provider/Verification` | Bổ sung / nộp lại đúng trạng thái hồ sơ |
| Nhà cung cấp | Quyền hoạt động – SUC13.01 | `/Provider/Rights` | Quyết định và gửi giải trình |
| Khách du lịch, nhà cung cấp | Đặt dịch vụ – SUC07.01 | `/Bookings` | `/Bookings/Detail/{id}` |
| Khách du lịch, nhà cung cấp | Thay đổi / hủy – SUC08.01 | `/Bookings/Adjustments` | `/Bookings/Changes/{id}`; khách gửi đề nghị ở `/Bookings/Change/{id}` |
| Khách du lịch, nhà cung cấp | Kết quả phục vụ – SUC09.01 | `/Bookings/Results` | `/Bookings/Outcome/{id}` |
| Khách du lịch | Hỗ trợ chuyến đi – SUC05.01 | `/Support?planId={id}` | Báo cáo mới ở `/Support/Create?planId={id}`; xử lý ở `/Support/Detail/{id}` |

Các trang chi tiết có liên kết quay về đúng danh sách; menu giữ trạng thái đang chọn theo nghiệp vụ. Ba trang chi tiết đặt dịch vụ có liên kết chuyển nghiệp vụ trong cùng yêu cầu, không ghép các biểu mẫu của ba SUC vào một trang.

Ba danh sách quản trị hỗ trợ tìm kiếm, lọc trạng thái và phân trang 20 bản ghi/trang tại máy chủ. Mặc định xét duyệt chỉ hiển thị phiên bản chờ duyệt, xác minh chỉ hiển thị hồ sơ chờ xác minh; “Tất cả trạng thái” hiển thị cả lịch sử. Tìm kiếm và bộ lọc được giữ trong URL, bao gồm khi chuyển trang.

Thông báo và điều hướng sau khi lưu chuyển tới đúng trang nghiệp vụ. Quyền theo actor, quyền sở hữu bản ghi, kiểm tra trạng thái, CSRF và phiên bản dữ liệu vẫn được thực thi tại máy chủ như ma trận SUC.

Kiểm chứng ngày 03/11/2026: build không lỗi/cảnh báo; 286 kiểm tra actor, 193 kiểm tra luồng nghiệp vụ và 89 kiểm tra trang chức năng đã đạt trên SQL Server thử nghiệm riêng. Bộ `tests/function-pages.cjs` kiểm tra bộ lọc thực tế, tách nội dung, mục menu đang chọn và liên kết quay về; có thể chạy sau bộ luồng nghiệp vụ.
