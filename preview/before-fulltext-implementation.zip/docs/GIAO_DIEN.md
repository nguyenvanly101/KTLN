# Định hướng giao diện Hành Trình

Giao diện được làm mới theo hướng tạp chí du lịch: nền kem, xanh rừng và cam đất; ảnh điểm đến lớn, tiêu đề có điểm nhấn serif và bố cục bất đối xứng ở màn hình rộng. Dùng dữ liệu, ảnh và các đường dẫn nghiệp vụ hiện có.

## Quy tắc dùng chung

- Màu và thành phần dùng chung nằm trong `wwwroot/css/experience.css`, nạp sau các stylesheet cũ.
- Nội dung thường dùng phông hệ thống có tiếng Việt; serif chỉ dùng làm điểm nhấn tiêu đề. Không yêu cầu tải font bên ngoài.
- Thao tác chính dùng xanh rừng; cam đất dành cho nhãn mục và dấu hiệu điều hướng.
- Ô nhập tối thiểu 48 px, chữ 16 px; nút và điều khiển chính tối thiểu 44 px. Focus bàn phím có viền tương phản.
- Bố cục trang chủ chuyển từ hai cột sang một cột trên điện thoại; danh mục dịch vụ xuống dòng thay vì phải cuộn ngang.
- Hiệu ứng hover nhẹ, tắt chuyển động khi bật `prefers-reduced-motion`.

## Luồng khám phá

Trang chủ dẫn tới tìm kiếm, tự lên lịch trình và kết nối đồng hành. Gợi ý điểm đến là liên kết lọc thật. Các thẻ dịch vụ có loại hình, vị trí, giá tham khảo và nút Chi tiết. Chuyển loại dịch vụ giữ từ khóa, điểm đến và khoảng giá; Xóa bộ lọc trở về trang khám phá.

Khu vực cá nhân, nhà cung cấp và quản trị dùng cùng màu và kích thước chữ, giữ điều hướng theo vai trò. Menu trên điện thoại đóng bằng Escape và trả focus về nút mở; các trang đang chọn có `aria-current`.

Trang tìm bạn đồng hành có phần giới thiệu, hướng dẫn ba bước, bộ lọc giữ hình thức đi đã chọn và thẻ lời rủ hiển thị rõ người đăng, nơi đến, ngày và ngân sách. Khi không có kết quả, giao diện hướng dẫn nới tiêu chí hoặc đăng tin.

Trang nhà cung cấp tách trạng thái xác minh và quyền hoạt động, bổ sung các số liệu từ dữ liệu hiện có và phân cấp danh sách dịch vụ. Danh sách đặt dịch vụ giữ dạng bảng trên máy tính, chuyển thành từng thẻ có nhãn trên điện thoại; vẫn giữ ngữ nghĩa bảng và liên kết xem chi tiết.

Thiết kế tham khảo dữ liệu cục bộ của skill ui-ux-pro-max về hero và bố cục có điểm nhấn, điều chỉnh bảng màu và kiểu chữ phù hợp sản phẩm du lịch tiếng Việt. Không bổ sung đánh giá, lượng người dùng hoặc số liệu tiếp thị giả.
