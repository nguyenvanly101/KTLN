CREATE TABLE [DiaDiemDuLich] (
    [MaDiaDiem] bigint NOT NULL IDENTITY,
    [TenDiaDiem] nvarchar(200) NOT NULL,
    [LoaiDiaDiem] nvarchar(50) NOT NULL,
    [KhuVuc] nvarchar(100) NOT NULL,
    [DiaChi] nvarchar(300) NULL,
    [MoTa] nvarchar(4000) NULL,
    [DangHienThi] bit NOT NULL,
    CONSTRAINT [PK_DiaDiemDuLich] PRIMARY KEY ([MaDiaDiem]),
    CONSTRAINT [CK_DiaDiemDuLich_KhuVuc_KhongRong] CHECK (LEN(LTRIM([KhuVuc])) > 0),
    CONSTRAINT [CK_DiaDiemDuLich_LoaiDiaDiem_KhongRong] CHECK (LEN(LTRIM([LoaiDiaDiem])) > 0),
    CONSTRAINT [CK_DiaDiemDuLich_TenDiaDiem_KhongRong] CHECK (LEN(LTRIM([TenDiaDiem])) > 0)
);
GO


CREATE TABLE [TaiKhoan] (
    [MaTaiKhoan] bigint NOT NULL IDENTITY,
    [Email] nvarchar(256) NOT NULL,
    [SoDienThoai] nvarchar(15) NULL,
    [MatKhauBam] nvarchar(500) NOT NULL,
    [VaiTro] varchar(30) NOT NULL,
    [TrangThai] varchar(30) NOT NULL,
    [DauPhien] uniqueidentifier NOT NULL,
    [PhaiDoiMatKhau] bit NOT NULL,
    [ThoiDiemTao] datetime2 NOT NULL,
    [ThoiDiemDangNhapCuoi] datetime2 NULL,
    [ThoiDiemNgung] datetime2 NULL,
    [RowVersion] rowversion NOT NULL,
    CONSTRAINT [PK_TaiKhoan] PRIMARY KEY ([MaTaiKhoan]),
    CONSTRAINT [CK_TaiKhoan_Email] CHECK ([Email] LIKE '%_@_%._%' AND [Email] NOT LIKE '% %'),
    CONSTRAINT [CK_TaiKhoan_Ngung] CHECK ((TrangThai = 'DaNgung' AND ThoiDiemNgung IS NOT NULL) OR (TrangThai = 'HoatDong' AND ThoiDiemNgung IS NULL)),
    CONSTRAINT [CK_TaiKhoan_SoDienThoai] CHECK ([SoDienThoai] LIKE '0%' AND [SoDienThoai] NOT LIKE '%[^0-9]%' AND LEN([SoDienThoai]) BETWEEN 10 AND 11),
    CONSTRAINT [CK_TaiKhoan_TrangThai] CHECK ([TrangThai] IN ('HoatDong','DaNgung')),
    CONSTRAINT [CK_TaiKhoan_VaiTro] CHECK ([VaiTro] IN ('KHACH_DU_LICH','NHA_CUNG_CAP','QUAN_TRI_VIEN'))
);
GO


CREATE TABLE [HoSoNguoiDung] (
    [MaHoSo] bigint NOT NULL IDENTITY,
    [MaTaiKhoan] bigint NOT NULL,
    [TenHienThi] nvarchar(100) NOT NULL,
    [AnhDaiDien] nvarchar(400) NULL,
    [GioiThieu] nvarchar(1000) NULL,
    [NoiSinhSong] nvarchar(200) NULL,
    [SoThich] nvarchar(500) NULL,
    [ThongTinChiaSe] varchar(30) NOT NULL,
    [ThoiDiemCapNhat] datetime2 NOT NULL,
    [RowVersion] rowversion NOT NULL,
    CONSTRAINT [PK_HoSoNguoiDung] PRIMARY KEY ([MaHoSo]),
    CONSTRAINT [CK_HoSoNguoiDung_TenHienThi_KhongRong] CHECK (LEN(LTRIM([TenHienThi])) > 0),
    CONSTRAINT [CK_HoSoNguoiDung_ThongTinChiaSe] CHECK ([ThongTinChiaSe] IN ('CongKhai','KhiKetNoi','RiengTu')),
    CONSTRAINT [FK_HoSoNguoiDung_TaiKhoan_MaTaiKhoan] FOREIGN KEY ([MaTaiKhoan]) REFERENCES [TaiKhoan] ([MaTaiKhoan]) ON DELETE NO ACTION
);
GO


CREATE TABLE [KeHoachChuyenDi] (
    [MaKeHoach] bigint NOT NULL IDENTITY,
    [MaTaiKhoan] bigint NOT NULL,
    [TenKeHoach] nvarchar(150) NOT NULL,
    [NoiDen] nvarchar(200) NOT NULL,
    [NgayBatDau] date NOT NULL,
    [NgayKetThuc] date NOT NULL,
    [NganSachDuKien] decimal(18,2) NULL,
    [TrangThai] varchar(30) NOT NULL,
    [ThoiDiemTao] datetime2 NOT NULL,
    [ThoiDiemCapNhat] datetime2 NOT NULL,
    [RowVersion] rowversion NOT NULL,
    CONSTRAINT [PK_KeHoachChuyenDi] PRIMARY KEY ([MaKeHoach]),
    CONSTRAINT [CK_KeHoachChuyenDi_NganSachDuKien] CHECK ([NganSachDuKien] >= 0),
    CONSTRAINT [CK_KeHoachChuyenDi_Ngay] CHECK (NgayKetThuc >= NgayBatDau),
    CONSTRAINT [CK_KeHoachChuyenDi_NoiDen_KhongRong] CHECK (LEN(LTRIM([NoiDen])) > 0),
    CONSTRAINT [CK_KeHoachChuyenDi_TenKeHoach_KhongRong] CHECK (LEN(LTRIM([TenKeHoach])) > 0),
    CONSTRAINT [CK_KeHoachChuyenDi_TrangThai] CHECK ([TrangThai] IN ('Nhap','DaChapNhan')),
    CONSTRAINT [FK_KeHoachChuyenDi_TaiKhoan_MaTaiKhoan] FOREIGN KEY ([MaTaiKhoan]) REFERENCES [TaiKhoan] ([MaTaiKhoan]) ON DELETE NO ACTION
);
GO


CREATE TABLE [NhaCungCapDichVu] (
    [MaNhaCungCap] bigint NOT NULL IDENTITY,
    [MaTaiKhoan] bigint NOT NULL,
    [TenDonVi] nvarchar(200) NOT NULL,
    [LoaiHinh] nvarchar(50) NOT NULL,
    [NguoiLienHe] nvarchar(100) NOT NULL,
    [DiaChi] nvarchar(300) NOT NULL,
    [SoDienThoai] nvarchar(15) NOT NULL,
    [EmailLienHe] nvarchar(256) NOT NULL,
    [TrangThaiXacMinh] varchar(30) NOT NULL,
    [TrangThaiQuyenHoatDong] varchar(30) NULL,
    [ThoiDiemTao] datetime2 NOT NULL,
    [RowVersion] rowversion NOT NULL,
    CONSTRAINT [PK_NhaCungCapDichVu] PRIMARY KEY ([MaNhaCungCap]),
    CONSTRAINT [CK_NhaCungCapDichVu_EmailLienHe] CHECK ([EmailLienHe] LIKE '%_@_%._%' AND [EmailLienHe] NOT LIKE '% %'),
    CONSTRAINT [CK_NhaCungCapDichVu_LoaiHinh_KhongRong] CHECK (LEN(LTRIM([LoaiHinh])) > 0),
    CONSTRAINT [CK_NhaCungCapDichVu_NguoiLienHe_KhongRong] CHECK (LEN(LTRIM([NguoiLienHe])) > 0),
    CONSTRAINT [CK_NhaCungCapDichVu_SoDienThoai] CHECK ([SoDienThoai] LIKE '0%' AND [SoDienThoai] NOT LIKE '%[^0-9]%' AND LEN([SoDienThoai]) BETWEEN 10 AND 11),
    CONSTRAINT [CK_NhaCungCapDichVu_TenDonVi_KhongRong] CHECK (LEN(LTRIM([TenDonVi])) > 0),
    CONSTRAINT [CK_NhaCungCapDichVu_TrangThai] CHECK ((TrangThaiXacMinh IN ('ChoXacMinh', 'CanBoSung', 'TuChoi') AND TrangThaiQuyenHoatDong IS NULL) OR (TrangThaiXacMinh = 'DaXacMinh' AND TrangThaiQuyenHoatDong IS NOT NULL AND TrangThaiQuyenHoatDong IN ('DangHoatDong', 'TamDinhChi')) OR (TrangThaiXacMinh = 'DaThuHoi' AND TrangThaiQuyenHoatDong IS NOT NULL AND TrangThaiQuyenHoatDong = 'DaThuHoi')),
    CONSTRAINT [CK_NhaCungCapDichVu_TrangThaiQuyenHoatDong] CHECK ([TrangThaiQuyenHoatDong] IN ('DangHoatDong','TamDinhChi','DaThuHoi')),
    CONSTRAINT [CK_NhaCungCapDichVu_TrangThaiXacMinh] CHECK ([TrangThaiXacMinh] IN ('ChoXacMinh','CanBoSung','DaXacMinh','TuChoi','DaThuHoi')),
    CONSTRAINT [FK_NhaCungCapDichVu_TaiKhoan_MaTaiKhoan] FOREIGN KEY ([MaTaiKhoan]) REFERENCES [TaiKhoan] ([MaTaiKhoan]) ON DELETE NO ACTION
);
GO


CREATE TABLE [NhatKyThaoTac] (
    [MaNhatKy] bigint NOT NULL IDENTITY,
    [MaTaiKhoan] bigint NULL,
    [LoaiSuKien] nvarchar(40) NOT NULL,
    [DoiTuong] nvarchar(40) NULL,
    [MaDoiTuong] bigint NULL,
    [TrangThaiTruoc] nvarchar(200) NULL,
    [TrangThaiSau] nvarchar(200) NULL,
    [LyDo] nvarchar(500) NULL,
    [DiaChiIP] nvarchar(45) NULL,
    [ThoiDiem] datetime2 NOT NULL,
    CONSTRAINT [PK_NhatKyThaoTac] PRIMARY KEY ([MaNhatKy]),
    CONSTRAINT [CK_NhatKyThaoTac_LoaiSuKien_KhongRong] CHECK (LEN(LTRIM([LoaiSuKien])) > 0),
    CONSTRAINT [FK_NhatKyThaoTac_TaiKhoan_MaTaiKhoan] FOREIGN KEY ([MaTaiKhoan]) REFERENCES [TaiKhoan] ([MaTaiKhoan]) ON DELETE NO ACTION
);
GO


CREATE TABLE [NhuCauDongHanh] (
    [MaNhuCau] bigint NOT NULL IDENTITY,
    [MaTaiKhoan] bigint NOT NULL,
    [NoiDung] nvarchar(2000) NOT NULL,
    [DiemDen] nvarchar(200) NOT NULL,
    [NgayBatDau] date NOT NULL,
    [NgayKetThuc] date NOT NULL,
    [NganSachDuKien] decimal(18,2) NULL,
    [HinhThucDi] nvarchar(50) NULL,
    [MongMuonDongHanh] nvarchar(1000) NULL,
    [PhamViChiaSe] varchar(30) NOT NULL,
    [ThoiDiemDang] datetime2 NOT NULL,
    [TrangThaiCongBo] varchar(30) NOT NULL,
    [RowVersion] rowversion NOT NULL,
    CONSTRAINT [PK_NhuCauDongHanh] PRIMARY KEY ([MaNhuCau]),
    CONSTRAINT [CK_NhuCauDongHanh_DiemDen_KhongRong] CHECK (LEN(LTRIM([DiemDen])) > 0),
    CONSTRAINT [CK_NhuCauDongHanh_NganSachDuKien] CHECK ([NganSachDuKien] >= 0),
    CONSTRAINT [CK_NhuCauDongHanh_Ngay] CHECK (NgayKetThuc >= NgayBatDau),
    CONSTRAINT [CK_NhuCauDongHanh_PhamViChiaSe] CHECK ([PhamViChiaSe] IN ('CongKhai','DaDangNhap','KhiKetNoi')),
    CONSTRAINT [CK_NhuCauDongHanh_TrangThaiCongBo] CHECK ([TrangThaiCongBo] IN ('DangCongBo','DungCongBo')),
    CONSTRAINT [FK_NhuCauDongHanh_TaiKhoan_MaTaiKhoan] FOREIGN KEY ([MaTaiKhoan]) REFERENCES [TaiKhoan] ([MaTaiKhoan]) ON DELETE NO ACTION
);
GO


CREATE TABLE [ThongBao] (
    [MaThongBao] bigint NOT NULL IDENTITY,
    [MaNguoiNhan] bigint NOT NULL,
    [LoaiThongBao] nvarchar(40) NOT NULL,
    [NoiDung] nvarchar(500) NOT NULL,
    [DuongDan] nvarchar(300) NULL,
    [DaDoc] bit NOT NULL,
    [ThoiDiemTao] datetime2 NOT NULL,
    CONSTRAINT [PK_ThongBao] PRIMARY KEY ([MaThongBao]),
    CONSTRAINT [CK_ThongBao_LoaiThongBao_KhongRong] CHECK (LEN(LTRIM([LoaiThongBao])) > 0),
    CONSTRAINT [FK_ThongBao_TaiKhoan_MaNguoiNhan] FOREIGN KEY ([MaNguoiNhan]) REFERENCES [TaiKhoan] ([MaTaiKhoan]) ON DELETE NO ACTION
);
GO


CREATE TABLE [TinhHuongPhatSinh] (
    [MaTinhHuong] bigint NOT NULL IDENTITY,
    [MaKeHoach] bigint NOT NULL,
    [LoaiTinhHuong] nvarchar(50) NOT NULL,
    [MoTa] nvarchar(2000) NOT NULL,
    [ViTri] nvarchar(300) NULL,
    [ThoiDiemGhiNhan] datetime2 NOT NULL,
    [TrangThaiXuLy] varchar(30) NOT NULL,
    [KetQuaXuLy] nvarchar(2000) NULL,
    [ThoiDiemCapNhat] datetime2 NOT NULL,
    [RowVersion] rowversion NOT NULL,
    CONSTRAINT [PK_TinhHuongPhatSinh] PRIMARY KEY ([MaTinhHuong]),
    CONSTRAINT [CK_TinhHuongPhatSinh_KetQua] CHECK (TrangThaiXuLy <> 'DaGiaiQuyet' OR (KetQuaXuLy IS NOT NULL AND LEN(LTRIM(KetQuaXuLy)) > 0)),
    CONSTRAINT [CK_TinhHuongPhatSinh_LoaiTinhHuong_KhongRong] CHECK (LEN(LTRIM([LoaiTinhHuong])) > 0),
    CONSTRAINT [CK_TinhHuongPhatSinh_TrangThaiXuLy] CHECK ([TrangThaiXuLy] IN ('ChuaGiaiQuyet','DaChonPhuongAn','GiaiQuyetMotPhan','DaGiaiQuyet','DungXuLy')),
    CONSTRAINT [FK_TinhHuongPhatSinh_KeHoachChuyenDi_MaKeHoach] FOREIGN KEY ([MaKeHoach]) REFERENCES [KeHoachChuyenDi] ([MaKeHoach]) ON DELETE NO ACTION
);
GO


CREATE TABLE [HoSoXacMinhNhaCungCap] (
    [MaHoSo] bigint NOT NULL IDENTITY,
    [MaNhaCungCap] bigint NOT NULL,
    [NoiDungDangKy] nvarchar(2000) NOT NULL,
    [NguoiDaiDien] nvarchar(100) NOT NULL,
    [ThoiDiemNop] datetime2 NOT NULL,
    [SoLanBoSung] int NOT NULL,
    [TrangThaiXuLy] varchar(30) NOT NULL,
    [RowVersion] rowversion NOT NULL,
    CONSTRAINT [PK_HoSoXacMinhNhaCungCap] PRIMARY KEY ([MaHoSo]),
    CONSTRAINT [CK_HoSoXacMinhNhaCungCap_NguoiDaiDien_KhongRong] CHECK (LEN(LTRIM([NguoiDaiDien])) > 0),
    CONSTRAINT [CK_HoSoXacMinhNhaCungCap_SoLanBoSung] CHECK ([SoLanBoSung] >= 0),
    CONSTRAINT [CK_HoSoXacMinhNhaCungCap_TrangThaiXuLy] CHECK ([TrangThaiXuLy] IN ('ChoXacMinh','CanBoSung','DaXacMinh','TuChoi')),
    CONSTRAINT [FK_HoSoXacMinhNhaCungCap_NhaCungCapDichVu_MaNhaCungCap] FOREIGN KEY ([MaNhaCungCap]) REFERENCES [NhaCungCapDichVu] ([MaNhaCungCap]) ON DELETE NO ACTION
);
GO


CREATE TABLE [QuyetDinhQuyenHoatDong] (
    [MaQuyetDinh] bigint NOT NULL IDENTITY,
    [MaNhaCungCap] bigint NOT NULL,
    [TrangThaiTruoc] varchar(30) NOT NULL,
    [TrangThaiSau] varchar(30) NOT NULL,
    [LyDo] nvarchar(500) NOT NULL,
    [CanCu] nvarchar(500) NOT NULL,
    [ThoiHan] date NULL,
    [MaAdmin] bigint NOT NULL,
    [ThoiDiem] datetime2 NOT NULL,
    CONSTRAINT [PK_QuyetDinhQuyenHoatDong] PRIMARY KEY ([MaQuyetDinh]),
    CONSTRAINT [CK_QuyetDinhQuyenHoatDong_DoiTrangThai] CHECK (TrangThaiTruoc <> TrangThaiSau),
    CONSTRAINT [CK_QuyetDinhQuyenHoatDong_LyDoCanCu] CHECK ((LyDo IS NOT NULL AND LEN(LTRIM(LyDo)) > 0) AND (CanCu IS NOT NULL AND LEN(LTRIM(CanCu)) > 0)),
    CONSTRAINT [CK_QuyetDinhQuyenHoatDong_ThoiHan] CHECK (ThoiHan IS NULL OR TrangThaiSau = 'TamDinhChi'),
    CONSTRAINT [CK_QuyetDinhQuyenHoatDong_TrangThaiSau] CHECK ([TrangThaiSau] IN ('DangHoatDong','TamDinhChi','DaThuHoi')),
    CONSTRAINT [CK_QuyetDinhQuyenHoatDong_TrangThaiTruoc] CHECK ([TrangThaiTruoc] IN ('DangHoatDong','TamDinhChi','DaThuHoi')),
    CONSTRAINT [FK_QuyetDinhQuyenHoatDong_NhaCungCapDichVu_MaNhaCungCap] FOREIGN KEY ([MaNhaCungCap]) REFERENCES [NhaCungCapDichVu] ([MaNhaCungCap]) ON DELETE NO ACTION,
    CONSTRAINT [FK_QuyetDinhQuyenHoatDong_TaiKhoan_MaAdmin] FOREIGN KEY ([MaAdmin]) REFERENCES [TaiKhoan] ([MaTaiKhoan]) ON DELETE NO ACTION
);
GO


CREATE TABLE [DeNghiKetNoiDongHanh] (
    [MaDeNghi] bigint NOT NULL IDENTITY,
    [MaNhuCau] bigint NOT NULL,
    [MaNguoiGui] bigint NOT NULL,
    [LoiGioiThieu] nvarchar(1000) NULL,
    [ThoiDiemGui] datetime2 NOT NULL,
    [ThoiDiemPhanHoi] datetime2 NULL,
    [TrangThai] varchar(30) NOT NULL,
    [RowVersion] rowversion NOT NULL,
    CONSTRAINT [PK_DeNghiKetNoiDongHanh] PRIMARY KEY ([MaDeNghi]),
    CONSTRAINT [CK_DeNghiKetNoiDongHanh_PhanHoi] CHECK ((TrangThai = 'ChoPhanHoi' AND ThoiDiemPhanHoi IS NULL) OR (TrangThai <> 'ChoPhanHoi' AND ThoiDiemPhanHoi IS NOT NULL)),
    CONSTRAINT [CK_DeNghiKetNoiDongHanh_TrangThai] CHECK ([TrangThai] IN ('ChoPhanHoi','DaChapNhan','TuChoi','DaRut','HetHieuLuc')),
    CONSTRAINT [FK_DeNghiKetNoiDongHanh_NhuCauDongHanh_MaNhuCau] FOREIGN KEY ([MaNhuCau]) REFERENCES [NhuCauDongHanh] ([MaNhuCau]) ON DELETE NO ACTION,
    CONSTRAINT [FK_DeNghiKetNoiDongHanh_TaiKhoan_MaNguoiGui] FOREIGN KEY ([MaNguoiGui]) REFERENCES [TaiKhoan] ([MaTaiKhoan]) ON DELETE NO ACTION
);
GO


CREATE TABLE [PhuongAnXuLy] (
    [MaPhuongAn] bigint NOT NULL IDENTITY,
    [MaTinhHuong] bigint NOT NULL,
    [NoiDung] nvarchar(1000) NOT NULL,
    [ThoiDiemChon] datetime2 NOT NULL,
    [LaHienHanh] bit NOT NULL,
    CONSTRAINT [PK_PhuongAnXuLy] PRIMARY KEY ([MaPhuongAn]),
    CONSTRAINT [FK_PhuongAnXuLy_TinhHuongPhatSinh_MaTinhHuong] FOREIGN KEY ([MaTinhHuong]) REFERENCES [TinhHuongPhatSinh] ([MaTinhHuong]) ON DELETE NO ACTION
);
GO


CREATE TABLE [QuyetDinhXacMinh] (
    [MaQuyetDinh] bigint NOT NULL IDENTITY,
    [MaHoSo] bigint NOT NULL,
    [LanXuLy] int NOT NULL,
    [KetQua] varchar(30) NOT NULL,
    [KetQuaXacMinh] nvarchar(500) NULL,
    [LyDo] nvarchar(500) NULL,
    [MaAdminDuyet] bigint NOT NULL,
    [ThoiDiemDuyet] datetime2 NOT NULL,
    CONSTRAINT [PK_QuyetDinhXacMinh] PRIMARY KEY ([MaQuyetDinh]),
    CONSTRAINT [CK_QuyetDinhXacMinh_KetQua] CHECK ([KetQua] IN ('CanBoSung','DaXacMinh','TuChoi')),
    CONSTRAINT [CK_QuyetDinhXacMinh_LanXuLy] CHECK ([LanXuLy] >= 1),
    CONSTRAINT [CK_QuyetDinhXacMinh_LyDo] CHECK (KetQua = 'DaXacMinh' OR (LyDo IS NOT NULL AND LEN(LTRIM(LyDo)) > 0)),
    CONSTRAINT [FK_QuyetDinhXacMinh_HoSoXacMinhNhaCungCap_MaHoSo] FOREIGN KEY ([MaHoSo]) REFERENCES [HoSoXacMinhNhaCungCap] ([MaHoSo]) ON DELETE NO ACTION,
    CONSTRAINT [FK_QuyetDinhXacMinh_TaiKhoan_MaAdminDuyet] FOREIGN KEY ([MaAdminDuyet]) REFERENCES [TaiKhoan] ([MaTaiKhoan]) ON DELETE NO ACTION
);
GO


CREATE TABLE [TaiLieuXacMinh] (
    [MaTaiLieu] bigint NOT NULL IDENTITY,
    [MaHoSo] bigint NOT NULL,
    [TenTepGoc] nvarchar(255) NOT NULL,
    [DuongDan] nvarchar(400) NOT NULL,
    [LoaiTep] varchar(30) NOT NULL,
    [KichThuoc] int NOT NULL,
    [LanNop] int NOT NULL,
    [ThoiDiemTai] datetime2 NOT NULL,
    CONSTRAINT [PK_TaiLieuXacMinh] PRIMARY KEY ([MaTaiLieu]),
    CONSTRAINT [CK_TaiLieuXacMinh_KichThuoc] CHECK ([KichThuoc] BETWEEN 1 AND 5242880),
    CONSTRAINT [CK_TaiLieuXacMinh_LanNop] CHECK ([LanNop] >= 0),
    CONSTRAINT [CK_TaiLieuXacMinh_LoaiTep] CHECK ([LoaiTep] IN ('pdf','jpg','png')),
    CONSTRAINT [CK_TaiLieuXacMinh_TenTepGoc_KhongRong] CHECK (LEN(LTRIM([TenTepGoc])) > 0),
    CONSTRAINT [FK_TaiLieuXacMinh_HoSoXacMinhNhaCungCap_MaHoSo] FOREIGN KEY ([MaHoSo]) REFERENCES [HoSoXacMinhNhaCungCap] ([MaHoSo]) ON DELETE NO ACTION
);
GO


CREATE TABLE [DichVuDuLich] (
    [MaDichVu] bigint NOT NULL IDENTITY,
    [MaNhaCungCap] bigint NOT NULL,
    [TenDichVu] nvarchar(200) NOT NULL,
    [LoaiDichVu] nvarchar(50) NOT NULL,
    [MoTa] nvarchar(4000) NULL,
    [KhuVucPhucVu] nvarchar(200) NOT NULL,
    [MaDiaDiem] bigint NULL,
    [GiaThamKhao] decimal(18,2) NULL,
    [ThoiGianPhucVu] nvarchar(200) NULL,
    [DieuKienPhucVu] nvarchar(2000) NULL,
    [TamNgungTu] date NULL,
    [TamNgungDen] date NULL,
    [LyDoTamNgung] nvarchar(500) NULL,
    [TrangThaiCongBo] varchar(30) NOT NULL,
    [TrangThaiTiepNhan] varchar(30) NOT NULL,
    [MaQuyetDinhKhongTiepNhan] bigint NULL,
    [PhienBanCongBo] int NULL,
    [ThoiDiemTao] datetime2 NOT NULL,
    [ThoiDiemCapNhat] datetime2 NOT NULL,
    [RowVersion] rowversion NOT NULL,
    CONSTRAINT [PK_DichVuDuLich] PRIMARY KEY ([MaDichVu]),
    CONSTRAINT [CK_DichVuDuLich_CongBo] CHECK (TrangThaiCongBo <> 'DaDuyet' OR PhienBanCongBo IS NOT NULL),
    CONSTRAINT [CK_DichVuDuLich_GiaThamKhao] CHECK ([GiaThamKhao] >= 0),
    CONSTRAINT [CK_DichVuDuLich_KhongTiepNhan] CHECK (MaQuyetDinhKhongTiepNhan IS NULL OR TrangThaiTiepNhan = 'KhongTiepNhanMoi'),
    CONSTRAINT [CK_DichVuDuLich_KhuVucPhucVu_KhongRong] CHECK (LEN(LTRIM([KhuVucPhucVu])) > 0),
    CONSTRAINT [CK_DichVuDuLich_LoaiDichVu_KhongRong] CHECK (LEN(LTRIM([LoaiDichVu])) > 0),
    CONSTRAINT [CK_DichVuDuLich_PhienBanCongBo] CHECK ([PhienBanCongBo] >= 1),
    CONSTRAINT [CK_DichVuDuLich_TamNgung] CHECK ((TamNgungTu IS NULL AND TamNgungDen IS NULL AND LyDoTamNgung IS NULL) OR (TamNgungTu IS NOT NULL AND (TamNgungDen IS NULL OR TamNgungDen >= TamNgungTu))),
    CONSTRAINT [CK_DichVuDuLich_TenDichVu_KhongRong] CHECK (LEN(LTRIM([TenDichVu])) > 0),
    CONSTRAINT [CK_DichVuDuLich_TrangThaiCongBo] CHECK ([TrangThaiCongBo] IN ('Nhap','ChoDuyet','DaDuyet','TuChoi','CanSua','NgungCongBo')),
    CONSTRAINT [CK_DichVuDuLich_TrangThaiTiepNhan] CHECK ([TrangThaiTiepNhan] IN ('TiepNhan','KhongTiepNhanMoi')),
    CONSTRAINT [FK_DichVuDuLich_DiaDiemDuLich_MaDiaDiem] FOREIGN KEY ([MaDiaDiem]) REFERENCES [DiaDiemDuLich] ([MaDiaDiem]) ON DELETE NO ACTION,
    CONSTRAINT [FK_DichVuDuLich_NhaCungCapDichVu_MaNhaCungCap] FOREIGN KEY ([MaNhaCungCap]) REFERENCES [NhaCungCapDichVu] ([MaNhaCungCap]) ON DELETE NO ACTION,
    CONSTRAINT [FK_DichVuDuLich_QuyetDinhQuyenHoatDong_MaQuyetDinhKhongTiepNhan] FOREIGN KEY ([MaQuyetDinhKhongTiepNhan]) REFERENCES [QuyetDinhQuyenHoatDong] ([MaQuyetDinh]) ON DELETE NO ACTION
);
GO


CREATE TABLE [GiaiTrinhNhaCungCap] (
    [MaGiaiTrinh] bigint NOT NULL IDENTITY,
    [MaQuyetDinh] bigint NOT NULL,
    [NoiDung] nvarchar(2000) NOT NULL,
    [ThoiDiemGui] datetime2 NOT NULL,
    [TrangThai] varchar(30) NOT NULL,
    [KetQuaXemXet] nvarchar(500) NULL,
    [MaAdminXemXet] bigint NULL,
    [ThoiDiemXemXet] datetime2 NULL,
    CONSTRAINT [PK_GiaiTrinhNhaCungCap] PRIMARY KEY ([MaGiaiTrinh]),
    CONSTRAINT [CK_GiaiTrinhNhaCungCap_TrangThai] CHECK ([TrangThai] IN ('ChoXemXet','DaXemXet')),
    CONSTRAINT [CK_GiaiTrinhNhaCungCap_XemXet] CHECK ((TrangThai = 'ChoXemXet' AND MaAdminXemXet IS NULL AND ThoiDiemXemXet IS NULL) OR (TrangThai = 'DaXemXet' AND MaAdminXemXet IS NOT NULL AND ThoiDiemXemXet IS NOT NULL AND KetQuaXemXet IS NOT NULL AND LEN(LTRIM(KetQuaXemXet)) > 0)),
    CONSTRAINT [FK_GiaiTrinhNhaCungCap_QuyetDinhQuyenHoatDong_MaQuyetDinh] FOREIGN KEY ([MaQuyetDinh]) REFERENCES [QuyetDinhQuyenHoatDong] ([MaQuyetDinh]) ON DELETE NO ACTION,
    CONSTRAINT [FK_GiaiTrinhNhaCungCap_TaiKhoan_MaAdminXemXet] FOREIGN KEY ([MaAdminXemXet]) REFERENCES [TaiKhoan] ([MaTaiKhoan]) ON DELETE NO ACTION
);
GO


CREATE TABLE [ThoaThuanDongHanh] (
    [MaThoaThuan] bigint NOT NULL IDENTITY,
    [MaDeNghi] bigint NOT NULL,
    [PhienBan] int NOT NULL,
    [NgayDi] date NOT NULL,
    [NgayVe] date NOT NULL,
    [NoiDen] nvarchar(200) NOT NULL,
    [NganSach] decimal(18,2) NULL,
    [PhamViDiCung] nvarchar(1000) NULL,
    [MaNguoiDeXuat] bigint NOT NULL,
    [ThoiDiemDeXuat] datetime2 NOT NULL,
    [MaNguoiXacNhan] bigint NULL,
    [ThoiDiemXacNhan] datetime2 NULL,
    [LoaiPhienBan] varchar(30) NOT NULL,
    [TrangThai] varchar(30) NOT NULL,
    [LyDo] nvarchar(500) NULL,
    [MaNguoiKetThuc] bigint NULL,
    [ThoiDiemKetThuc] datetime2 NULL,
    [RowVersion] rowversion NOT NULL,
    CONSTRAINT [PK_ThoaThuanDongHanh] PRIMARY KEY ([MaThoaThuan]),
    CONSTRAINT [CK_ThoaThuanDongHanh_DaXacNhan] CHECK (TrangThai <> 'DaXacNhan' OR MaNguoiXacNhan IS NOT NULL),
    CONSTRAINT [CK_ThoaThuanDongHanh_DeNghiNgung] CHECK (LoaiPhienBan = 'NoiDung' OR TrangThai IN ('ChoXacNhan', 'TuChoi', 'DaNgung', 'DaThayThe')),
    CONSTRAINT [CK_ThoaThuanDongHanh_HaiBen] CHECK (MaNguoiXacNhan IS NULL OR MaNguoiXacNhan <> MaNguoiDeXuat),
    CONSTRAINT [CK_ThoaThuanDongHanh_LoaiPhienBan] CHECK ([LoaiPhienBan] IN ('NoiDung','DeNghiNgung')),
    CONSTRAINT [CK_ThoaThuanDongHanh_LyDo] CHECK (TrangThai <> 'TuChoi' OR (LyDo IS NOT NULL AND LEN(LTRIM(LyDo)) > 0)),
    CONSTRAINT [CK_ThoaThuanDongHanh_NganSach] CHECK ([NganSach] >= 0),
    CONSTRAINT [CK_ThoaThuanDongHanh_Ngay] CHECK (NgayVe >= NgayDi),
    CONSTRAINT [CK_ThoaThuanDongHanh_Ngung] CHECK (TrangThai <> 'DaNgung' OR ThoiDiemKetThuc IS NOT NULL),
    CONSTRAINT [CK_ThoaThuanDongHanh_NoiDen_KhongRong] CHECK (LEN(LTRIM([NoiDen])) > 0),
    CONSTRAINT [CK_ThoaThuanDongHanh_PhienBan] CHECK ([PhienBan] >= 1),
    CONSTRAINT [CK_ThoaThuanDongHanh_Rut] CHECK (TrangThai <> 'MotBenDaRut' OR (MaNguoiKetThuc IS NOT NULL AND ThoiDiemKetThuc IS NOT NULL)),
    CONSTRAINT [CK_ThoaThuanDongHanh_TrangThai] CHECK ([TrangThai] IN ('ChoXacNhan','DaXacNhan','TuChoi','DaThayThe','DaNgung','MotBenDaRut')),
    CONSTRAINT [CK_ThoaThuanDongHanh_XacNhan] CHECK ((MaNguoiXacNhan IS NULL AND ThoiDiemXacNhan IS NULL) OR (MaNguoiXacNhan IS NOT NULL AND ThoiDiemXacNhan IS NOT NULL)),
    CONSTRAINT [FK_ThoaThuanDongHanh_DeNghiKetNoiDongHanh_MaDeNghi] FOREIGN KEY ([MaDeNghi]) REFERENCES [DeNghiKetNoiDongHanh] ([MaDeNghi]) ON DELETE NO ACTION,
    CONSTRAINT [FK_ThoaThuanDongHanh_TaiKhoan_MaNguoiDeXuat] FOREIGN KEY ([MaNguoiDeXuat]) REFERENCES [TaiKhoan] ([MaTaiKhoan]) ON DELETE NO ACTION,
    CONSTRAINT [FK_ThoaThuanDongHanh_TaiKhoan_MaNguoiKetThuc] FOREIGN KEY ([MaNguoiKetThuc]) REFERENCES [TaiKhoan] ([MaTaiKhoan]) ON DELETE NO ACTION,
    CONSTRAINT [FK_ThoaThuanDongHanh_TaiKhoan_MaNguoiXacNhan] FOREIGN KEY ([MaNguoiXacNhan]) REFERENCES [TaiKhoan] ([MaTaiKhoan]) ON DELETE NO ACTION
);
GO


CREATE TABLE [BanCapNhatDichVu] (
    [MaBanCapNhat] bigint NOT NULL IDENTITY,
    [MaDichVu] bigint NOT NULL,
    [SoPhienBan] int NOT NULL,
    [TenDichVu] nvarchar(200) NOT NULL,
    [LoaiDichVu] nvarchar(50) NOT NULL,
    [MoTa] nvarchar(4000) NULL,
    [KhuVucPhucVu] nvarchar(200) NOT NULL,
    [MaDiaDiem] bigint NULL,
    [GiaThamKhao] decimal(18,2) NULL,
    [ThoiGianPhucVu] nvarchar(200) NULL,
    [DieuKienPhucVu] nvarchar(2000) NULL,
    [TamNgungTu] date NULL,
    [TamNgungDen] date NULL,
    [LyDoTamNgung] nvarchar(500) NULL,
    [TrangThaiDuyet] varchar(30) NOT NULL,
    [LyDo] nvarchar(500) NULL,
    [MaAdminDuyet] bigint NULL,
    [ThoiDiemGui] datetime2 NOT NULL,
    [ThoiDiemDuyet] datetime2 NULL,
    CONSTRAINT [PK_BanCapNhatDichVu] PRIMARY KEY ([MaBanCapNhat]),
    CONSTRAINT [CK_BanCapNhatDichVu_Duyet] CHECK ((TrangThaiDuyet = 'ChoDuyet' AND MaAdminDuyet IS NULL AND ThoiDiemDuyet IS NULL) OR (TrangThaiDuyet <> 'ChoDuyet' AND MaAdminDuyet IS NOT NULL AND ThoiDiemDuyet IS NOT NULL)),
    CONSTRAINT [CK_BanCapNhatDichVu_GiaThamKhao] CHECK ([GiaThamKhao] >= 0),
    CONSTRAINT [CK_BanCapNhatDichVu_KhuVucPhucVu_KhongRong] CHECK (LEN(LTRIM([KhuVucPhucVu])) > 0),
    CONSTRAINT [CK_BanCapNhatDichVu_LoaiDichVu_KhongRong] CHECK (LEN(LTRIM([LoaiDichVu])) > 0),
    CONSTRAINT [CK_BanCapNhatDichVu_LyDo] CHECK (TrangThaiDuyet NOT IN ('TuChoi', 'CanSua') OR (LyDo IS NOT NULL AND LEN(LTRIM(LyDo)) > 0)),
    CONSTRAINT [CK_BanCapNhatDichVu_SoPhienBan] CHECK ([SoPhienBan] >= 1),
    CONSTRAINT [CK_BanCapNhatDichVu_TamNgung] CHECK ((TamNgungTu IS NULL AND TamNgungDen IS NULL AND LyDoTamNgung IS NULL) OR (TamNgungTu IS NOT NULL AND (TamNgungDen IS NULL OR TamNgungDen >= TamNgungTu))),
    CONSTRAINT [CK_BanCapNhatDichVu_TenDichVu_KhongRong] CHECK (LEN(LTRIM([TenDichVu])) > 0),
    CONSTRAINT [CK_BanCapNhatDichVu_TrangThaiDuyet] CHECK ([TrangThaiDuyet] IN ('ChoDuyet','DaDuyet','TuChoi','CanSua')),
    CONSTRAINT [FK_BanCapNhatDichVu_DiaDiemDuLich_MaDiaDiem] FOREIGN KEY ([MaDiaDiem]) REFERENCES [DiaDiemDuLich] ([MaDiaDiem]) ON DELETE NO ACTION,
    CONSTRAINT [FK_BanCapNhatDichVu_DichVuDuLich_MaDichVu] FOREIGN KEY ([MaDichVu]) REFERENCES [DichVuDuLich] ([MaDichVu]) ON DELETE NO ACTION,
    CONSTRAINT [FK_BanCapNhatDichVu_TaiKhoan_MaAdminDuyet] FOREIGN KEY ([MaAdminDuyet]) REFERENCES [TaiKhoan] ([MaTaiKhoan]) ON DELETE NO ACTION
);
GO


CREATE TABLE [HoatDongLichTrinh] (
    [MaHoatDong] bigint NOT NULL IDENTITY,
    [MaKeHoach] bigint NOT NULL,
    [Ngay] date NOT NULL,
    [Gio] time NULL,
    [ThuTu] int NOT NULL,
    [MaDiaDiem] bigint NULL,
    [MaDichVu] bigint NULL,
    [NoiDung] nvarchar(300) NOT NULL,
    [ChiPhiDuKien] decimal(18,2) NULL,
    CONSTRAINT [PK_HoatDongLichTrinh] PRIMARY KEY ([MaHoatDong]),
    CONSTRAINT [CK_HoatDongLichTrinh_ChiPhiDuKien] CHECK ([ChiPhiDuKien] >= 0),
    CONSTRAINT [CK_HoatDongLichTrinh_MotMuc] CHECK (MaDiaDiem IS NULL OR MaDichVu IS NULL),
    CONSTRAINT [CK_HoatDongLichTrinh_ThuTu] CHECK ([ThuTu] >= 1),
    CONSTRAINT [FK_HoatDongLichTrinh_DiaDiemDuLich_MaDiaDiem] FOREIGN KEY ([MaDiaDiem]) REFERENCES [DiaDiemDuLich] ([MaDiaDiem]) ON DELETE NO ACTION,
    CONSTRAINT [FK_HoatDongLichTrinh_DichVuDuLich_MaDichVu] FOREIGN KEY ([MaDichVu]) REFERENCES [DichVuDuLich] ([MaDichVu]) ON DELETE NO ACTION,
    CONSTRAINT [FK_HoatDongLichTrinh_KeHoachChuyenDi_MaKeHoach] FOREIGN KEY ([MaKeHoach]) REFERENCES [KeHoachChuyenDi] ([MaKeHoach]) ON DELETE NO ACTION
);
GO


CREATE TABLE [YeuCauDatDichVu] (
    [MaYeuCau] bigint NOT NULL IDENTITY,
    [MaTaiKhoan] bigint NOT NULL,
    [MaDichVu] bigint NOT NULL,
    [NgayBatDau] date NOT NULL,
    [NgayKetThuc] date NULL,
    [ThoiGianDenDi] nvarchar(100) NULL,
    [SoNguoi] int NOT NULL,
    [SoLuong] int NOT NULL,
    [NoiDungLuaChon] nvarchar(1000) NULL,
    [GhiChu] nvarchar(1000) NULL,
    [ChiPhiDuKien] decimal(18,2) NULL,
    [DieuKienDeXuat] nvarchar(2000) NULL,
    [PhienBan] int NOT NULL,
    [ThoiDiemGui] datetime2 NOT NULL,
    [ThoiDiemPhanHoi] datetime2 NULL,
    [LyDo] nvarchar(500) NULL,
    [TrangThai] varchar(30) NOT NULL,
    [MaLuotGui] uniqueidentifier NOT NULL,
    [RowVersion] rowversion NOT NULL,
    CONSTRAINT [PK_YeuCauDatDichVu] PRIMARY KEY ([MaYeuCau]),
    CONSTRAINT [CK_YeuCauDatDichVu_ChiPhiDuKien] CHECK ([ChiPhiDuKien] >= 0),
    CONSTRAINT [CK_YeuCauDatDichVu_DeXuat] CHECK (TrangThai <> 'DeXuatKhac' OR (DieuKienDeXuat IS NOT NULL AND LEN(LTRIM(DieuKienDeXuat)) > 0)),
    CONSTRAINT [CK_YeuCauDatDichVu_LyDo] CHECK (TrangThai <> 'TuChoi' OR (LyDo IS NOT NULL AND LEN(LTRIM(LyDo)) > 0)),
    CONSTRAINT [CK_YeuCauDatDichVu_Ngay] CHECK (NgayKetThuc IS NULL OR NgayKetThuc >= NgayBatDau),
    CONSTRAINT [CK_YeuCauDatDichVu_PhanHoi] CHECK (TrangThai NOT IN ('DeXuatKhac', 'DaXacNhan', 'TuChoi') OR ThoiDiemPhanHoi IS NOT NULL),
    CONSTRAINT [CK_YeuCauDatDichVu_PhienBan] CHECK ([PhienBan] >= 1),
    CONSTRAINT [CK_YeuCauDatDichVu_SoLuong] CHECK ([SoLuong] BETWEEN 1 AND 100),
    CONSTRAINT [CK_YeuCauDatDichVu_SoNguoi] CHECK ([SoNguoi] BETWEEN 1 AND 100),
    CONSTRAINT [CK_YeuCauDatDichVu_TrangThai] CHECK ([TrangThai] IN ('ChoPhanHoi','DeXuatKhac','DaXacNhan','TuChoi','KhongTiepTuc','DaHuy','HoanThanh','ThucHienMotPhan','KhongThucHien','ChoKiemTra')),
    CONSTRAINT [FK_YeuCauDatDichVu_DichVuDuLich_MaDichVu] FOREIGN KEY ([MaDichVu]) REFERENCES [DichVuDuLich] ([MaDichVu]) ON DELETE NO ACTION,
    CONSTRAINT [FK_YeuCauDatDichVu_TaiKhoan_MaTaiKhoan] FOREIGN KEY ([MaTaiKhoan]) REFERENCES [TaiKhoan] ([MaTaiKhoan]) ON DELETE NO ACTION
);
GO


CREATE TABLE [TaiLieuGiaiTrinh] (
    [MaTaiLieu] bigint NOT NULL IDENTITY,
    [MaGiaiTrinh] bigint NOT NULL,
    [TenTepGoc] nvarchar(255) NOT NULL,
    [DuongDan] nvarchar(400) NOT NULL,
    [LoaiTep] varchar(30) NOT NULL,
    [KichThuoc] int NOT NULL,
    [ThoiDiemTai] datetime2 NOT NULL,
    CONSTRAINT [PK_TaiLieuGiaiTrinh] PRIMARY KEY ([MaTaiLieu]),
    CONSTRAINT [CK_TaiLieuGiaiTrinh_KichThuoc] CHECK ([KichThuoc] BETWEEN 1 AND 5242880),
    CONSTRAINT [CK_TaiLieuGiaiTrinh_LoaiTep] CHECK ([LoaiTep] IN ('pdf','jpg','png')),
    CONSTRAINT [CK_TaiLieuGiaiTrinh_TenTepGoc_KhongRong] CHECK (LEN(LTRIM([TenTepGoc])) > 0),
    CONSTRAINT [FK_TaiLieuGiaiTrinh_GiaiTrinhNhaCungCap_MaGiaiTrinh] FOREIGN KEY ([MaGiaiTrinh]) REFERENCES [GiaiTrinhNhaCungCap] ([MaGiaiTrinh]) ON DELETE NO ACTION
);
GO


CREATE TABLE [TinhHuongHoatDong] (
    [MaTinhHuong] bigint NOT NULL,
    [MaHoatDong] bigint NOT NULL,
    CONSTRAINT [PK_TinhHuongHoatDong] PRIMARY KEY ([MaTinhHuong], [MaHoatDong]),
    CONSTRAINT [FK_TinhHuongHoatDong_HoatDongLichTrinh_MaHoatDong] FOREIGN KEY ([MaHoatDong]) REFERENCES [HoatDongLichTrinh] ([MaHoatDong]) ON DELETE NO ACTION,
    CONSTRAINT [FK_TinhHuongHoatDong_TinhHuongPhatSinh_MaTinhHuong] FOREIGN KEY ([MaTinhHuong]) REFERENCES [TinhHuongPhatSinh] ([MaTinhHuong]) ON DELETE NO ACTION
);
GO


CREATE TABLE [DeNghiDieuChinhDichVu] (
    [MaDeNghi] bigint NOT NULL IDENTITY,
    [MaYeuCau] bigint NOT NULL,
    [LoaiDeNghi] varchar(30) NOT NULL,
    [DieuKienCu] nvarchar(2000) NOT NULL,
    [NgayBatDauMoi] date NULL,
    [NgayKetThucMoi] date NULL,
    [SoNguoiMoi] int NULL,
    [SoLuongMoi] int NULL,
    [DieuKienMoi] nvarchar(2000) NULL,
    [LyDo] nvarchar(500) NOT NULL,
    [ThoiDiemGui] datetime2 NOT NULL,
    [QuyetDinh] nvarchar(500) NULL,
    [DieuKienDeXuat] nvarchar(2000) NULL,
    [ThoiDiemPhanHoi] datetime2 NULL,
    [TrangThai] varchar(30) NOT NULL,
    [RowVersion] rowversion NOT NULL,
    CONSTRAINT [PK_DeNghiDieuChinhDichVu] PRIMARY KEY ([MaDeNghi]),
    CONSTRAINT [CK_DeNghiDieuChinhDichVu_DeXuat] CHECK (TrangThai <> 'DeXuatKhac' OR (DieuKienDeXuat IS NOT NULL AND LEN(LTRIM(DieuKienDeXuat)) > 0)),
    CONSTRAINT [CK_DeNghiDieuChinhDichVu_DieuKienMoi] CHECK (LoaiDeNghi <> 'ThayDoi' OR NgayBatDauMoi IS NOT NULL OR NgayKetThucMoi IS NOT NULL OR SoNguoiMoi IS NOT NULL OR SoLuongMoi IS NOT NULL OR (DieuKienMoi IS NOT NULL AND LEN(LTRIM(DieuKienMoi)) > 0)),
    CONSTRAINT [CK_DeNghiDieuChinhDichVu_Huy] CHECK (LoaiDeNghi <> 'Huy' OR (NgayBatDauMoi IS NULL AND NgayKetThucMoi IS NULL AND SoNguoiMoi IS NULL AND SoLuongMoi IS NULL)),
    CONSTRAINT [CK_DeNghiDieuChinhDichVu_LoaiDeNghi] CHECK ([LoaiDeNghi] IN ('ThayDoi','Huy')),
    CONSTRAINT [CK_DeNghiDieuChinhDichVu_LyDo] CHECK ((LyDo IS NOT NULL AND LEN(LTRIM(LyDo)) > 0)),
    CONSTRAINT [CK_DeNghiDieuChinhDichVu_NgayMoi] CHECK (NgayBatDauMoi IS NULL OR NgayKetThucMoi IS NULL OR NgayKetThucMoi >= NgayBatDauMoi),
    CONSTRAINT [CK_DeNghiDieuChinhDichVu_PhanHoi] CHECK ((TrangThai = 'ChoPhanHoi' AND ThoiDiemPhanHoi IS NULL) OR (TrangThai <> 'ChoPhanHoi' AND ThoiDiemPhanHoi IS NOT NULL)),
    CONSTRAINT [CK_DeNghiDieuChinhDichVu_SoLuongMoi] CHECK ([SoLuongMoi] BETWEEN 1 AND 100),
    CONSTRAINT [CK_DeNghiDieuChinhDichVu_SoNguoiMoi] CHECK ([SoNguoiMoi] BETWEEN 1 AND 100),
    CONSTRAINT [CK_DeNghiDieuChinhDichVu_TrangThai] CHECK ([TrangThai] IN ('ChoPhanHoi','DeXuatKhac','ChapNhan','TuChoi','DaRut')),
    CONSTRAINT [CK_DeNghiDieuChinhDichVu_TuChoi] CHECK (TrangThai <> 'TuChoi' OR (QuyetDinh IS NOT NULL AND LEN(LTRIM(QuyetDinh)) > 0)),
    CONSTRAINT [FK_DeNghiDieuChinhDichVu_YeuCauDatDichVu_MaYeuCau] FOREIGN KEY ([MaYeuCau]) REFERENCES [YeuCauDatDichVu] ([MaYeuCau]) ON DELETE NO ACTION
);
GO


CREATE TABLE [KetQuaCungCapDichVu] (
    [MaKetQua] bigint NOT NULL IDENTITY,
    [MaYeuCau] bigint NOT NULL,
    [HangMuc] nvarchar(200) NOT NULL,
    [KetQuaThucHien] varchar(30) NOT NULL,
    [GhiChu] nvarchar(1000) NULL,
    [ThoiDiemGhi] datetime2 NOT NULL,
    [NoiDungPhanAnh] nvarchar(2000) NULL,
    [ThoiDiemPhanAnh] datetime2 NULL,
    [TrangThaiKiemTra] varchar(30) NOT NULL,
    [ThoiDiemKiemTra] datetime2 NULL,
    [RowVersion] rowversion NOT NULL,
    CONSTRAINT [PK_KetQuaCungCapDichVu] PRIMARY KEY ([MaKetQua]),
    CONSTRAINT [CK_KetQuaCungCapDichVu_ChoKiemTra] CHECK (TrangThaiKiemTra <> 'ChoKiemTra' OR NoiDungPhanAnh IS NOT NULL OR KetQuaThucHien = 'ChuaXacDinh'),
    CONSTRAINT [CK_KetQuaCungCapDichVu_ChuaXacDinh] CHECK (KetQuaThucHien <> 'ChuaXacDinh' OR TrangThaiKiemTra = 'ChoKiemTra'),
    CONSTRAINT [CK_KetQuaCungCapDichVu_DaKiemTra] CHECK ((TrangThaiKiemTra = 'DaKiemTra' AND ThoiDiemKiemTra IS NOT NULL) OR (TrangThaiKiemTra <> 'DaKiemTra' AND ThoiDiemKiemTra IS NULL)),
    CONSTRAINT [CK_KetQuaCungCapDichVu_HangMuc_KhongRong] CHECK (LEN(LTRIM([HangMuc])) > 0),
    CONSTRAINT [CK_KetQuaCungCapDichVu_KetQuaThucHien] CHECK ([KetQuaThucHien] IN ('DayDu','MotPhan','KhongThucHien','KhachKhongDen','ChuaXacDinh')),
    CONSTRAINT [CK_KetQuaCungCapDichVu_PhanAnh] CHECK ((NoiDungPhanAnh IS NULL AND ThoiDiemPhanAnh IS NULL) OR (NoiDungPhanAnh IS NOT NULL AND ThoiDiemPhanAnh IS NOT NULL)),
    CONSTRAINT [CK_KetQuaCungCapDichVu_TrangThaiKiemTra] CHECK ([TrangThaiKiemTra] IN ('DaGhiNhan','ChoKiemTra','DaKiemTra')),
    CONSTRAINT [FK_KetQuaCungCapDichVu_YeuCauDatDichVu_MaYeuCau] FOREIGN KEY ([MaYeuCau]) REFERENCES [YeuCauDatDichVu] ([MaYeuCau]) ON DELETE NO ACTION
);
GO


CREATE INDEX [IX_BanCapNhatDichVu_MaAdminDuyet] ON [BanCapNhatDichVu] ([MaAdminDuyet]);
GO


CREATE INDEX [IX_BanCapNhatDichVu_MaDiaDiem] ON [BanCapNhatDichVu] ([MaDiaDiem]);
GO


CREATE UNIQUE INDEX [UX_BanCapNhatDichVu_ChoDuyet] ON [BanCapNhatDichVu] ([MaDichVu]) WHERE TrangThaiDuyet = 'ChoDuyet';
GO


CREATE UNIQUE INDEX [UX_BanCapNhatDichVu_PhienBan] ON [BanCapNhatDichVu] ([MaDichVu], [SoPhienBan]);
GO


CREATE UNIQUE INDEX [UX_DeNghiDieuChinhDichVu_Cho] ON [DeNghiDieuChinhDichVu] ([MaYeuCau]) WHERE TrangThai IN ('ChoPhanHoi', 'DeXuatKhac');
GO


CREATE INDEX [IX_DeNghiKetNoiDongHanh_MaNhuCau] ON [DeNghiKetNoiDongHanh] ([MaNhuCau]);
GO


CREATE UNIQUE INDEX [UX_DeNghiKetNoiDongHanh_HieuLuc] ON [DeNghiKetNoiDongHanh] ([MaNguoiGui], [MaNhuCau]) WHERE TrangThai IN ('ChoPhanHoi', 'DaChapNhan');
GO


CREATE INDEX [IX_DichVuDuLich_MaDiaDiem] ON [DichVuDuLich] ([MaDiaDiem]);
GO


CREATE INDEX [IX_DichVuDuLich_MaNhaCungCap] ON [DichVuDuLich] ([MaNhaCungCap]);
GO


CREATE INDEX [IX_DichVuDuLich_MaQuyetDinhKhongTiepNhan] ON [DichVuDuLich] ([MaQuyetDinhKhongTiepNhan]);
GO


CREATE INDEX [IX_GiaiTrinhNhaCungCap_MaAdminXemXet] ON [GiaiTrinhNhaCungCap] ([MaAdminXemXet]);
GO


CREATE INDEX [IX_GiaiTrinhNhaCungCap_MaQuyetDinh] ON [GiaiTrinhNhaCungCap] ([MaQuyetDinh]);
GO


CREATE INDEX [IX_HoatDongLichTrinh_MaDiaDiem] ON [HoatDongLichTrinh] ([MaDiaDiem]);
GO


CREATE INDEX [IX_HoatDongLichTrinh_MaDichVu] ON [HoatDongLichTrinh] ([MaDichVu]);
GO


CREATE INDEX [IX_HoatDongLichTrinh_MaKeHoach] ON [HoatDongLichTrinh] ([MaKeHoach]);
GO


CREATE UNIQUE INDEX [UX_HoSoNguoiDung_MaTaiKhoan] ON [HoSoNguoiDung] ([MaTaiKhoan]);
GO


CREATE UNIQUE INDEX [UX_HoSoXacMinh_DangXuLy] ON [HoSoXacMinhNhaCungCap] ([MaNhaCungCap]) WHERE TrangThaiXuLy IN ('ChoXacMinh', 'CanBoSung');
GO


CREATE INDEX [IX_KeHoachChuyenDi_MaTaiKhoan] ON [KeHoachChuyenDi] ([MaTaiKhoan]);
GO


CREATE UNIQUE INDEX [UX_KetQuaCungCapDichVu_HangMuc] ON [KetQuaCungCapDichVu] ([MaYeuCau], [HangMuc]);
GO


CREATE UNIQUE INDEX [UX_NhaCungCapDichVu_MaTaiKhoan] ON [NhaCungCapDichVu] ([MaTaiKhoan]);
GO


CREATE INDEX [IX_NhatKyThaoTac_MaTaiKhoan] ON [NhatKyThaoTac] ([MaTaiKhoan]);
GO


CREATE INDEX [IX_NhuCauDongHanh_MaTaiKhoan] ON [NhuCauDongHanh] ([MaTaiKhoan]);
GO


CREATE UNIQUE INDEX [UX_PhuongAnXuLy_HienHanh] ON [PhuongAnXuLy] ([MaTinhHuong]) WHERE LaHienHanh = 1;
GO


CREATE INDEX [IX_QuyetDinhQuyenHoatDong_MaAdmin] ON [QuyetDinhQuyenHoatDong] ([MaAdmin]);
GO


CREATE INDEX [IX_QuyetDinhQuyenHoatDong_MaNhaCungCap] ON [QuyetDinhQuyenHoatDong] ([MaNhaCungCap]);
GO


CREATE INDEX [IX_QuyetDinhXacMinh_MaAdminDuyet] ON [QuyetDinhXacMinh] ([MaAdminDuyet]);
GO


CREATE UNIQUE INDEX [UX_QuyetDinhXacMinh_LanXuLy] ON [QuyetDinhXacMinh] ([MaHoSo], [LanXuLy]);
GO


CREATE UNIQUE INDEX [UX_TaiKhoan_Email] ON [TaiKhoan] ([Email]);
GO


CREATE UNIQUE INDEX [UX_TaiKhoan_SoDienThoai] ON [TaiKhoan] ([SoDienThoai]) WHERE SoDienThoai IS NOT NULL;
GO


CREATE INDEX [IX_TaiLieuGiaiTrinh_MaGiaiTrinh] ON [TaiLieuGiaiTrinh] ([MaGiaiTrinh]);
GO


CREATE UNIQUE INDEX [UX_TaiLieuGiaiTrinh_DuongDan] ON [TaiLieuGiaiTrinh] ([DuongDan]);
GO


CREATE INDEX [IX_TaiLieuXacMinh_MaHoSo] ON [TaiLieuXacMinh] ([MaHoSo]);
GO


CREATE UNIQUE INDEX [UX_TaiLieuXacMinh_DuongDan] ON [TaiLieuXacMinh] ([DuongDan]);
GO


CREATE INDEX [IX_ThoaThuanDongHanh_MaNguoiDeXuat] ON [ThoaThuanDongHanh] ([MaNguoiDeXuat]);
GO


CREATE INDEX [IX_ThoaThuanDongHanh_MaNguoiKetThuc] ON [ThoaThuanDongHanh] ([MaNguoiKetThuc]);
GO


CREATE INDEX [IX_ThoaThuanDongHanh_MaNguoiXacNhan] ON [ThoaThuanDongHanh] ([MaNguoiXacNhan]);
GO


CREATE UNIQUE INDEX [UX_ThoaThuanDongHanh_ChoXacNhan] ON [ThoaThuanDongHanh] ([MaDeNghi]) WHERE TrangThai = 'ChoXacNhan';
GO


CREATE UNIQUE INDEX [UX_ThoaThuanDongHanh_DaXacNhan] ON [ThoaThuanDongHanh] ([MaDeNghi]) WHERE TrangThai = 'DaXacNhan';
GO


CREATE UNIQUE INDEX [UX_ThoaThuanDongHanh_PhienBan] ON [ThoaThuanDongHanh] ([MaDeNghi], [PhienBan]);
GO


CREATE INDEX [IX_ThongBao_MaNguoiNhan] ON [ThongBao] ([MaNguoiNhan]);
GO


CREATE INDEX [IX_TinhHuongHoatDong_MaHoatDong] ON [TinhHuongHoatDong] ([MaHoatDong]);
GO


CREATE INDEX [IX_TinhHuongPhatSinh_MaKeHoach] ON [TinhHuongPhatSinh] ([MaKeHoach]);
GO


CREATE INDEX [IX_YeuCauDatDichVu_MaDichVu] ON [YeuCauDatDichVu] ([MaDichVu]);
GO


CREATE UNIQUE INDEX [UX_YeuCauDatDichVu_LuotGui] ON [YeuCauDatDichVu] ([MaTaiKhoan], [MaLuotGui]);
GO


