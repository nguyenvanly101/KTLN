using System.ComponentModel.DataAnnotations;
namespace HoTroDuLich.Web.Models;
public class LoginInput {
 [Required,EmailAddress] [Display(Name="Email")] public string Email {get;set;}="";
 [Required,DataType(DataType.Password)] [Display(Name="Mật khẩu")] public string Password {get;set;}="";
 public string? ReturnUrl {get;set;}
}
public class RegisterInput {
 [Required,EmailAddress,MaxLength(254)] [Display(Name="Email")] public string Email {get;set;}="";
 [Required,MinLength(8),MaxLength(100)] [Display(Name="Mật khẩu")] public string Password {get;set;}="";
 [Compare(nameof(Password))] [Display(Name="Xác nhận mật khẩu")] public string ConfirmPassword {get;set;}="";
 [Required,MaxLength(100)] [Display(Name="Tên")] public string Name {get;set;}="";
 [RegularExpression("^0[0-9]{9,10}$")] [Display(Name="Số điện thoại")] public string? Phone {get;set;}
 public string Role {get;set;}="KHACH_DU_LICH";
 [MaxLength(200)] [Display(Name="Tên đơn vị")] public string? Organization {get;set;}
 [MaxLength(300)] [Display(Name="Địa chỉ")] public string? Address {get;set;}
 public List<IFormFile> Documents {get;set;}=[];
}
public class CommandInput {
 public long Id {get;set;} public string Version {get;set;}="";
 [MaxLength(4000)] [Display(Name="Nội dung")] public string Text {get;set;}="";
 [MaxLength(500)] [Display(Name="Lý do")] public string Reason {get;set;}="";
 [MaxLength(500)] [Display(Name="Căn cứ")] public string Evidence {get;set;}="";
 [MaxLength(40)] public string Decision {get;set;}="";
 public DateOnly? Until {get;set;}
 public List<IFormFile> Documents {get;set;}=[];
}
public class PlanInput {
 public long Id {get;set;} public string Version {get;set;}="";
 [Required,MaxLength(150)] [Display(Name="Tên")] public string Name {get;set;}="";
 [Required,MaxLength(200)] [Display(Name="Điểm đến")] public string Destination {get;set;}="";
 [Display(Name="Ngày bắt đầu")] public DateOnly Start {get;set;}=DateOnly.FromDateTime(DateTime.Today.AddDays(7));
 [Display(Name="Ngày kết thúc")] public DateOnly End {get;set;}=DateOnly.FromDateTime(DateTime.Today.AddDays(9));
 [Range(0,100000000000)] [Display(Name="Ngân sách")] public decimal? Budget {get;set;}
 public string Status {get;set;}="Nhap";
}
public class ActivityInput {
 public long Id {get;set;} public long PlanId {get;set;} public string Version {get;set;}="";
 public DateOnly Date {get;set;} public TimeOnly? Time {get;set;}
 [Required,MaxLength(300)] [Display(Name="Nội dung")] public string Content {get;set;}="";
 [Range(0,100000000000)] [Display(Name="Chi phí")] public decimal? Cost {get;set;}
 public long? ServiceId {get;set;} public long? PlaceId {get;set;}
}
public class NeedInput {
 public long Id {get;set;} public string Version {get;set;}="";
 [Required,MaxLength(200)] [Display(Name="Điểm đến")] public string Destination {get;set;}="";
 [Required,MaxLength(2000)] [Display(Name="Nội dung")] public string Content {get;set;}="";
 [Display(Name="Ngày bắt đầu")] public DateOnly Start {get;set;}=DateOnly.FromDateTime(DateTime.Today.AddDays(7));
 [Display(Name="Ngày kết thúc")] public DateOnly End {get;set;}=DateOnly.FromDateTime(DateTime.Today.AddDays(9));
 [Range(0,100000000000)] [Display(Name="Ngân sách")] public decimal? Budget {get;set;}
 [MaxLength(50)] [Display(Name="Hình thức du lịch")] public string? Style {get;set;}
 [MaxLength(1000)] [Display(Name="Mong muốn đồng hành")] public string? Wishes {get;set;}
 public string Privacy {get;set;}="CongKhai";
}
public class AgreementInput : PlanInput {
 public long ConnectionId {get;set;}
 [MaxLength(1000)] [Display(Name="Phạm vi đi cùng")] public string? Scope {get;set;}
 public string Kind {get;set;}="NoiDung";
 [MaxLength(500)] [Display(Name="Lý do")] public string? Reason {get;set;}
}
public class ServiceInput {
 public long Id {get;set;} public string Version {get;set;}="";
 [Required,MaxLength(200)] [Display(Name="Tên")] public string Name {get;set;}="";
 [Required,MaxLength(50)] [Display(Name="Loại hình")] public string Type {get;set;}="Lưu trú";
 [Required,MaxLength(200)] [Display(Name="Khu vực")] public string Region {get;set;}="";
 [MaxLength(4000)] [Display(Name="Mô tả")] public string? Description {get;set;}
 [Range(0,100000000000)] [Display(Name="Giá")] public decimal? Price {get;set;}
 [MaxLength(200)] [Display(Name="Thời gian phục vụ")] public string? Hours {get;set;}
 [MaxLength(2000)] [Display(Name="Điều kiện phục vụ")] public string? Terms {get;set;}
 public DateOnly? PauseFrom {get;set;} public DateOnly? PauseTo {get;set;}
 [MaxLength(500)] [Display(Name="Lý do tạm ngừng")] public string? PauseReason {get;set;}
}
public class BookingInput {
 public long Id {get;set;} public long ServiceId {get;set;} public string Version {get;set;}="";
 public Guid SubmissionId {get;set;}=Guid.NewGuid();
 [Display(Name="Ngày bắt đầu")] public DateOnly Start {get;set;}=DateOnly.FromDateTime(DateTime.Today.AddDays(7));
 [Display(Name="Ngày kết thúc")] public DateOnly? End {get;set;}
 [Range(1,100)] [Display(Name="Số người")] public int People {get;set;}=1;
 [Range(1,100)] [Display(Name="Số lượng")] public int Quantity {get;set;}=1;
 [MaxLength(1000)] public string? Notes {get;set;}
}
public class ChangeInput : BookingInput {
 public string Kind {get;set;}="ThayDoi";
 [Required,MaxLength(500)] [Display(Name="Lý do")] public string Reason {get;set;}="";
 [MaxLength(2000)] [Display(Name="Điều kiện phục vụ")] public string? Terms {get;set;}
}
public class IncidentInput {
 public long PlanId {get;set;}
 [Required,MaxLength(50)] [Display(Name="Loại hình")] public string Type {get;set;}="Thời tiết";
 [Required,MaxLength(2000)] [Display(Name="Mô tả")] public string Description {get;set;}="";
 [MaxLength(300)] [Display(Name="Vị trí")] public string? Location {get;set;}
 public long? ActivityId {get;set;}
}
public class ProfileInput {
 public string Version {get;set;}="";
 [Required,MaxLength(100)] [Display(Name="Tên")] public string Name {get;set;}="";
 [RegularExpression("^0[0-9]{9,10}$")] [Display(Name="Số điện thoại")] public string? Phone {get;set;}
 [MaxLength(2000)] [Display(Name="Giới thiệu")] public string? Bio {get;set;}
 [MaxLength(200)] [Display(Name="Nơi sinh sống")] public string? City {get;set;}
 [MaxLength(1000)] [Display(Name="Sở thích")] public string? Interests {get;set;}
 public string Privacy {get;set;}="CongKhai";
}
