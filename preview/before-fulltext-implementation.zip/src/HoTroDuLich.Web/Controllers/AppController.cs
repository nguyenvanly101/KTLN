using HoTroDuLich.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
namespace HoTroDuLich.Web.Controllers;
public abstract class AppController(TravelService service):Controller {
 protected readonly TravelService S=service;
 public override async Task OnActionExecutionAsync(ActionExecutingContext context,ActionExecutionDelegate next){
  if(!ModelState.IsValid){Response.StatusCode=400;ViewData["Message"]="Vui lòng kiểm tra dữ liệu: "+string.Join(" · ",ModelState.Values.SelectMany(x=>x.Errors).Select(x=>string.IsNullOrWhiteSpace(x.ErrorMessage)?"Giá trị nhập không hợp lệ":x.ErrorMessage));context.Result=View("Failure");return;}
  var executed=await next();
  if(executed.Exception is BusinessException b){Response.StatusCode=b.Status;ViewData["Message"]=b.Message;executed.Result=View("Failure");executed.ExceptionHandled=true;}
  else if(executed.Exception is DbUpdateConcurrencyException){Response.StatusCode=409;ViewData["Message"]="Dữ liệu vừa được cập nhật. Hãy tải lại trước khi thực hiện.";executed.Result=View("Failure");executed.ExceptionHandled=true;}
  else if(executed.Exception is DbUpdateException){Response.StatusCode=409;ViewData["Message"]="Không thể lưu vì dữ liệu bị trùng hoặc không còn hợp lệ. Thao tác chưa có hiệu lực. Vui lòng tải lại và kiểm tra.";executed.Result=View("Failure");executed.ExceptionHandled=true;}
 }
 protected IActionResult Done(string url,string message="Đã lưu thay đổi thành công."){TempData["Success"]=message;return LocalRedirect(url);}
}
