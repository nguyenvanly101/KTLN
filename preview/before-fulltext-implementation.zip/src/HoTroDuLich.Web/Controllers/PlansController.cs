using HoTroDuLich.Web.Models;
using HoTroDuLich.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
namespace HoTroDuLich.Web.Controllers;
[Authorize(Roles=TravelService.Traveler)]
[SucAuthorize(SucAccess.TripPlan)]
public class PlansController(TravelService s):AppController(s){
 public async Task<IActionResult> Index()=>View(await S.Plans());
 public async Task<IActionResult> Detail(long id){ViewBag.Activities=await S.Activities(id);return View(await S.OwnPlan(id));}
 [HttpGet] public async Task<IActionResult> Edit(long id=0){if(id==0)return View(new PlanInput());var p=await S.OwnPlan(id);return View(new PlanInput{Id=id,Version=TravelService.Token(p.RowVersion),Name=p.TenKeHoach,Destination=p.NoiDen,Start=p.NgayBatDau,End=p.NgayKetThuc,Budget=p.NganSachDuKien,Status=p.TrangThai});}
 [HttpPost] public async Task<IActionResult> Edit(PlanInput i)=>Done("/Plans/Detail/"+await S.SavePlan(i));
 [HttpGet] public async Task<IActionResult> Activity(long id,long activityId=0,long? serviceId=null,long? placeId=null){var p=await S.OwnPlan(id);var i=new ActivityInput{PlanId=id,Version=TravelService.Token(p.RowVersion),Date=p.NgayBatDau};ViewBag.Plan=p;if(activityId>0){var a=(await S.Activities(id)).Single(x=>x.MaHoatDong==activityId);i.Id=a.MaHoatDong;i.Date=a.Ngay;i.Time=a.Gio;i.Content=a.NoiDung;i.Cost=a.ChiPhiDuKien;i.ServiceId=a.MaDichVu;i.PlaceId=a.MaDiaDiem;}else if(serviceId!=null){var v=await S.PublicService(serviceId.Value);i.ServiceId=v.MaDichVu;i.Content=v.TenDichVu;i.Cost=v.GiaThamKhao;}else if(placeId!=null){var v=await S.Place(placeId.Value);i.PlaceId=v.MaDiaDiem;i.Content=v.TenDiaDiem;}return View(i);}
 [HttpPost] public async Task<IActionResult> Activity(ActivityInput i){await S.SaveActivity(i);return Done("/Plans/Detail/"+i.PlanId);}
 [HttpPost] public async Task<IActionResult> DeleteActivity(CommandInput i,long planId){await S.DeleteActivity(i);return Done("/Plans/Detail/"+planId);}
 public async Task<IActionResult> Select(long? serviceId,long? placeId){ViewBag.ServiceId=serviceId;ViewBag.PlaceId=placeId;return View(await S.Plans());}
}
