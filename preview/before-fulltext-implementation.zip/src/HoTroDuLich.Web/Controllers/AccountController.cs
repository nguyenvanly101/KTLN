using HoTroDuLich.Web.Models;
using HoTroDuLich.Web.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using System.Security.Claims;
namespace HoTroDuLich.Web.Controllers;
public class AccountController(TravelService s,IConfiguration config):AppController(s){
 [SucAuthorize(SucAccess.Login),HttpGet] public IActionResult Login(string? returnUrl){ViewBag.Demo=config.GetValue<bool>("Demo:Enabled");return View(new LoginInput{ReturnUrl=returnUrl});}
 [SucAuthorize(SucAccess.Login),HttpPost,EnableRateLimiting("auth")] public async Task<IActionResult> Login(LoginInput i){var a=await S.Authenticate(i);var claims=new[]{new Claim(ClaimTypes.NameIdentifier,a.MaTaiKhoan.ToString()),new Claim(ClaimTypes.Name,a.Email),new Claim(ClaimTypes.Role,a.VaiTro),new Claim("stamp",a.DauPhien.ToString()),new Claim("issued",DateTime.UtcNow.Ticks.ToString())};await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,new ClaimsPrincipal(new ClaimsIdentity(claims,CookieAuthenticationDefaults.AuthenticationScheme)));return LocalRedirect(Url.IsLocalUrl(i.ReturnUrl)?i.ReturnUrl!:a.VaiTro==TravelService.AdminRole?"/Admin":a.VaiTro==TravelService.ProviderRole?"/Provider":"/Plans");}
 [SucAuthorize(SucAccess.Registration),HttpGet] public IActionResult Register(string? accountType)=>View(new RegisterInput{Role=accountType=="provider"?TravelService.ProviderRole:TravelService.Traveler});
 [SucAuthorize(SucAccess.Registration),HttpPost,EnableRateLimiting("auth")] public async Task<IActionResult> Register(RegisterInput i){await S.Register(i);return Done("/Account/Login","Đăng ký thành công. Bạn có thể đăng nhập; nhà cung cấp cần chờ xác minh để gửi dịch vụ.");}
 [Authorize,HttpPost] public async Task<IActionResult> Logout(){await HttpContext.SignOutAsync();return RedirectToAction("Index","Explore");}
 [SucAuthorize(SucAccess.Profile),HttpGet] public async Task<IActionResult> Profile(){var p=await S.Profile();var a=await S.Find<HoTroDuLich.Web.Domain.TaiKhoan>(S.UserId);return View(new ProfileInput{Version=TravelService.Token(p.RowVersion),Name=p.TenHienThi,Phone=a.SoDienThoai,Bio=p.GioiThieu,City=p.NoiSinhSong,Interests=p.SoThich,Privacy=p.ThongTinChiaSe});}
 [SucAuthorize(SucAccess.Profile),HttpPost] public async Task<IActionResult> Profile(ProfileInput i){await S.SaveProfile(i);return Done("/Account/Profile");}
 [SucAuthorize(SucAccess.Deactivation),HttpGet] public IActionResult Deactivate()=>View();
 [SucAuthorize(SucAccess.Deactivation),HttpPost] public async Task<IActionResult> Deactivate(string password,string confirmation){S.Require(confirmation=="NGỪNG TÀI KHOẢN","Hãy nhập chính xác NGỪNG TÀI KHOẢN để xác nhận.",400);await S.Deactivate(password);await HttpContext.SignOutAsync();return Done("/Account/Login","Đã ngừng sử dụng tài khoản và kết thúc phiên.");}
 public IActionResult Denied(){Response.StatusCode=403;ViewBag.Message="Bạn không có quyền truy cập chức năng này.";return View("Failure");}
 [Authorize] public async Task<IActionResult> Notifications()=>View(await S.Notifications());
 [Authorize,HttpPost] public async Task<IActionResult> Read(long id){await S.MarkRead(id);return RedirectToAction("Notifications");}
 [Authorize] public async Task<IActionResult> Download(string kind,long id){var f=await S.AuthorizedFile(kind,id);return PhysicalFile(f.Path,f.ContentType,f.Name);}
}
