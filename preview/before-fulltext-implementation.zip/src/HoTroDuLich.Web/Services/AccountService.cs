using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
namespace HoTroDuLich.Web.Services;
public partial class TravelService {
 public async Task<TaiKhoan> Authenticate(LoginInput i){
  var email=i.Email.Trim().ToLowerInvariant();var a=await db.TaiKhoan.SingleOrDefaultAsync(x=>x.Email==email);
  Require(a!=null && new PasswordHasher<TaiKhoan>().VerifyHashedPassword(a,a.MatKhauBam,i.Password)!=PasswordVerificationResult.Failed,"Thông tin đăng nhập không đúng.",400);
  Require(a!.TrangThai=="HoatDong","Tài khoản đã ngừng sử dụng.");a.ThoiDiemDangNhapCuoi=DateTime.UtcNow;Audit("DangNhap","TaiKhoan",a.MaTaiKhoan,null,"ThanhCong");await db.SaveChangesAsync();return a;
 }
 public async Task Register(RegisterInput i){
  Require(new[]{Traveler,ProviderRole}.Contains(i.Role),"Loại tài khoản không hợp lệ.",400);
  Require(i.Password.Length>=8&&i.Password==i.ConfirmPassword,"Mật khẩu tối thiểu 8 ký tự và xác nhận phải khớp.",400);
  var email=i.Email.Trim().ToLowerInvariant();Require(!await db.TaiKhoan.AnyAsync(x=>x.Email==email||(i.Phone!=null&&x.SoDienThoai==i.Phone)),"Email hoặc số điện thoại đã được sử dụng.",409);
  if(i.Role==ProviderRole)Require(!string.IsNullOrWhiteSpace(i.Organization)&&!string.IsNullOrWhiteSpace(i.Address)&&!string.IsNullOrWhiteSpace(i.Phone),"Nhà cung cấp cần nhập tên đơn vị, địa chỉ và số điện thoại.",400);
  var files=await StoreFiles(i.Documents);
  await Execute(async()=>{
   var a=new TaiKhoan{Email=email,SoDienThoai=i.Phone,VaiTro=i.Role,TrangThai="HoatDong"};a.MatKhauBam=new PasswordHasher<TaiKhoan>().HashPassword(a,i.Password);db.Add(a);await db.SaveChangesAsync();
   db.Add(new HoSoNguoiDung{MaTaiKhoan=a.MaTaiKhoan,TenHienThi=i.Name,ThongTinChiaSe="CongKhai"});
   if(i.Role==ProviderRole){var p=new NhaCungCapDichVu{MaTaiKhoan=a.MaTaiKhoan,TenDonVi=i.Organization!,DiaChi=i.Address!,SoDienThoai=i.Phone!,EmailLienHe=email,NguoiLienHe=i.Name,LoaiHinh="Dịch vụ du lịch",TrangThaiXacMinh="ChoXacMinh"};db.Add(p);await db.SaveChangesAsync();var h=new HoSoXacMinhNhaCungCap{MaNhaCungCap=p.MaNhaCungCap,NguoiDaiDien=i.Name,NoiDungDangKy=i.Organization!,TrangThaiXuLy="ChoXacMinh"};db.Add(h);await db.SaveChangesAsync();foreach(var f in files)db.Add(new TaiLieuXacMinh{MaHoSo=h.MaHoSo,TenTepGoc=f.Name,DuongDan=f.Path,LoaiTep=f.Type,KichThuoc=f.Size});}
   Audit("DangKy","TaiKhoan",a.MaTaiKhoan,null,i.Role);
  });
 }
 public async Task<HoSoNguoiDung> Profile()=>await db.HoSoNguoiDung.SingleAsync(x=>x.MaTaiKhoan==UserId);
 public async Task SaveProfile(ProfileInput i){
  RequireUseCase(SucAccess.Profile);
  Require(new[]{"CongKhai","KhiKetNoi","RiengTu"}.Contains(i.Privacy),"Phạm vi chia sẻ không hợp lệ.",400);
  await Execute(async()=>{var p=await Profile();CheckVersion(p,i.Version);var a=await Find<TaiKhoan>(UserId);Require(i.Phone==null||!await db.TaiKhoan.AnyAsync(x=>x.MaTaiKhoan!=UserId&&x.SoDienThoai==i.Phone),"Số điện thoại đã được sử dụng.",409);p.TenHienThi=i.Name;Require(i.Bio==null||i.Bio.Length<=1000,"Giới thiệu tối đa 1000 ký tự.",400);Require(i.Interests==null||i.Interests.Length<=500,"Sở thích tối đa 500 ký tự.",400);p.GioiThieu=i.Bio;p.NoiSinhSong=i.City;p.SoThich=i.Interests;p.ThongTinChiaSe=i.Privacy;p.ThoiDiemCapNhat=DateTime.UtcNow;a.SoDienThoai=i.Phone;});
 }
 public async Task Deactivate(string password){
  RoleRequired(Traveler,ProviderRole);
  await Execute(async()=>{
   var a=await Find<TaiKhoan>(UserId);Require(new PasswordHasher<TaiKhoan>().VerifyHashedPassword(a,a.MatKhauBam,password)!=PasswordVerificationResult.Failed,"Mật khẩu xác thực lại không đúng.",400);
   var bookings=await AccessibleBookings().AnyAsync(x=>new[]{"ChoPhanHoi","DeXuatKhac","DaXacNhan","ChoKiemTra"}.Contains(x.TrangThai));
   var agreements=await AccessibleAgreements().AnyAsync(x=>x.TrangThai=="DaXacNhan"||x.TrangThai=="ChoXacNhan");
   Require(!bookings&&!agreements,"Còn thỏa thuận hoặc yêu cầu dịch vụ chưa hoàn tất. Hãy xử lý trước khi ngừng tài khoản.");
   a.TrangThai="DaNgung";a.ThoiDiemNgung=DateTime.UtcNow;a.DauPhien=Guid.NewGuid();
   foreach(var n in await db.NhuCauDongHanh.Where(x=>x.MaTaiKhoan==UserId).ToListAsync())n.TrangThaiCongBo="DungCongBo";
   foreach(var c in await db.DeNghiKetNoiDongHanh.Where(x=>x.TrangThai=="ChoPhanHoi"&&(x.MaNguoiGui==UserId||db.NhuCauDongHanh.Any(n=>n.MaNhuCau==x.MaNhuCau&&n.MaTaiKhoan==UserId))).ToListAsync()){c.TrangThai="HetHieuLuc";c.ThoiDiemPhanHoi=DateTime.UtcNow;var n=await Find<NhuCauDongHanh>(c.MaNhuCau);Notify(c.MaNguoiGui==UserId?n.MaTaiKhoan:c.MaNguoiGui,"Đề nghị kết nối hết hiệu lực do tài khoản ngừng hoạt động.","/Companions/Connections");}
   if(Role==ProviderRole){var p=await MyProvider();foreach(var s in await db.DichVuDuLich.Where(x=>x.MaNhaCungCap==p.MaNhaCungCap).ToListAsync())s.TrangThaiTiepNhan="KhongTiepNhanMoi";}
   Audit("NgungTaiKhoan","TaiKhoan",UserId,"HoatDong","DaNgung");
  });
 }
}
