using System.Security.Claims;
using System.Data;
using HoTroDuLich.Web.Data;
using HoTroDuLich.Web.Domain;
using HoTroDuLich.Web.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
namespace HoTroDuLich.Web.Services;
public class BusinessException(string message,int status=422):Exception(message){public int Status{get;}=status;}
public partial class TravelService(AppDbContext db,IHttpContextAccessor http,IWebHostEnvironment env,IConfiguration config) {
 public const string Traveler="KHACH_DU_LICH",ProviderRole="NHA_CUNG_CAP",AdminRole="QUAN_TRI_VIEN";
 public long UserId=>long.TryParse(http.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier),out var id)?id:0;
 public string Role=>http.HttpContext?.User.FindFirstValue(ClaimTypes.Role)??"";
 public static DateOnly Today=>DateOnly.FromDateTime(TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow,"SE Asia Standard Time"));
 public static string Token(byte[] v)=>Convert.ToBase64String(v);
 public void Require(bool valid,string message,int status=422){if(!valid)throw new BusinessException(message,status);}
 public void RoleRequired(params string[] roles)=>Require(UserId>0&&roles.Contains(Role),"Bạn không có quyền thực hiện thao tác này.",403);
 public void RequireUseCase(string useCase)=>Require(SucAccess.Allows(http.HttpContext?.User??new ClaimsPrincipal(),useCase),"Vai trò của bạn không được sử dụng chức năng này.",403);
 public void CheckVersion(object entity,string version){var p=entity.GetType().GetProperty("RowVersion");Require(p!=null&&Token((byte[])p.GetValue(entity)!)==version,"Dữ liệu vừa thay đổi ở phiên khác. Vui lòng tải lại.",409);}
 public async Task<T> Find<T>(long id) where T:class=>await db.Set<T>().FindAsync(id)??throw new BusinessException("Không tìm thấy dữ liệu.",404);
 public void Dates(DateOnly start,DateOnly? end)=>Require(start!=default&&(end==null||end>=start),"Ngày kết thúc phải từ ngày bắt đầu trở đi.",400);
 public async Task Execute(Func<Task> work){await using var tx=await db.Database.BeginTransactionAsync(IsolationLevel.Serializable);await work();await db.SaveChangesAsync();await tx.CommitAsync();}
 public void Notify(long id,string text,string url)=>db.ThongBao.Add(new(){MaNguoiNhan=id,LoaiThongBao="NghiepVu",NoiDung=text,DuongDan=url});
 public void Audit(string kind,string target,long id,string? before,string? after,string? reason=null)=>db.NhatKyThaoTac.Add(new(){MaTaiKhoan=UserId==0?null:UserId,LoaiSuKien=kind,DoiTuong=target,MaDoiTuong=id,TrangThaiTruoc=before,TrangThaiSau=after,LyDo=reason,DiaChiIP=http.HttpContext?.Connection.RemoteIpAddress?.ToString()});
 public async Task<NhaCungCapDichVu> MyProvider()=>await db.NhaCungCapDichVu.SingleOrDefaultAsync(x=>x.MaTaiKhoan==UserId)??throw new BusinessException("Không tìm thấy nhà cung cấp.",403);
 public async Task<bool> ProviderActive(long id)=>await db.NhaCungCapDichVu.AnyAsync(x=>x.MaNhaCungCap==id&&x.TrangThaiXacMinh=="DaXacMinh"&&x.TrangThaiQuyenHoatDong=="DangHoatDong"&&db.TaiKhoan.Any(a=>a.MaTaiKhoan==x.MaTaiKhoan&&a.TrangThai=="HoatDong"));
 public IQueryable<DichVuDuLich> PublicServices()=>db.DichVuDuLich.Where(x=>x.TrangThaiCongBo=="DaDuyet"&&db.NhaCungCapDichVu.Any(p=>p.MaNhaCungCap==x.MaNhaCungCap&&p.TrangThaiQuyenHoatDong!="DaThuHoi"));
 public async Task<(List<DichVuDuLich> Services,List<DiaDiemDuLich> Places)> Explore(string? q,string? region,string? type,decimal? min,decimal? max){
  RequireUseCase(SucAccess.TravelSearch);
  Require(min==null||min>=0,"Giá tối thiểu phải không âm.",400);Require(max==null||max>=0,"Giá tối đa phải không âm.",400);Require(min==null||max==null||min<=max,"Khoảng giá không hợp lệ.",400);
  var s=PublicServices().AsNoTracking();var p=db.DiaDiemDuLich.Where(x=>x.DangHienThi).AsNoTracking();
  if(!string.IsNullOrWhiteSpace(q)){s=s.Where(x=>x.TenDichVu.Contains(q)||x.KhuVucPhucVu.Contains(q));p=p.Where(x=>x.TenDiaDiem.Contains(q)||x.KhuVuc.Contains(q));}
  if(!string.IsNullOrEmpty(region)){s=s.Where(x=>x.KhuVucPhucVu==region);p=p.Where(x=>x.KhuVuc==region);}
  if(!string.IsNullOrEmpty(type)){s=s.Where(x=>x.LoaiDichVu==type);if(type!="Địa điểm")p=p.Where(x=>false);else s=s.Where(x=>false);}
  if(min!=null)s=s.Where(x=>x.GiaThamKhao>=min);if(max!=null)s=s.Where(x=>x.GiaThamKhao<=max);if(min!=null||max!=null)p=p.Where(x=>false);
  return(await s.OrderBy(x=>x.TenDichVu).Take(100).ToListAsync(),await p.OrderBy(x=>x.TenDiaDiem).Take(100).ToListAsync());
 }
 public async Task<List<ThongBao>> Notifications()=>await db.ThongBao.Where(x=>x.MaNguoiNhan==UserId).OrderByDescending(x=>x.ThoiDiemTao).Take(100).ToListAsync();
 public async Task MarkRead(long id){var n=await Find<ThongBao>(id);Require(n.MaNguoiNhan==UserId,"Không có quyền.",403);n.DaDoc=true;await db.SaveChangesAsync();}
 private async Task<List<(string Name,string Path,string Type,int Size)>> StoreFiles(List<IFormFile> files){
  Require(files.Count<=5,"Tối đa 5 tệp.",400);var result=new List<(string,string,string,int)>();var bytes=new List<(IFormFile File,byte[] Data,string Extension)>();
  foreach(var f in files){var ext=Path.GetExtension(f.FileName).ToLowerInvariant();Require(new[]{".pdf",".jpg",".jpeg",".png"}.Contains(ext)&&f.Length>0&&f.Length<=5242880,"Chỉ nhận PDF/JPG/PNG, tối đa 5 MB mỗi tệp.",400);using var ms=new MemoryStream();await f.CopyToAsync(ms);var a=ms.ToArray();Require((ext==".pdf"&&a.Length>4&&System.Text.Encoding.ASCII.GetString(a,0,5)=="%PDF-")||((ext==".jpg"||ext==".jpeg")&&a.Length>3&&a[0]==255&&a[1]==216&&a[2]==255)||(ext==".png"&&a.Length>8&&a.Take(8).SequenceEqual(new byte[]{137,80,78,71,13,10,26,10})),"Nội dung tệp không đúng định dạng.",400);bytes.Add((f,a,ext==".jpeg"?"jpg":ext[1..]));}
  Directory.CreateDirectory(Path.Combine(env.ContentRootPath,"App_Data","uploads"));foreach(var f in bytes){var name=Guid.NewGuid()+"."+f.Extension;await File.WriteAllBytesAsync(Path.Combine(env.ContentRootPath,"App_Data","uploads",name),f.Data);result.Add((Path.GetFileName(f.File.FileName),name,f.Extension,f.Data.Length));}return result;
 }
}
