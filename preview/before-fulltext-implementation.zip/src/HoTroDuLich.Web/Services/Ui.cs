using Microsoft.AspNetCore.Html;
using HoTroDuLich.Web.Domain;
namespace HoTroDuLich.Web.Services;

public static class Ui
{
    public static IHtmlContent Icon(string name) => new HtmlString($"<svg class=\"icon\" aria-hidden=\"true\"><use href=\"/images/icons.svg#{name}\"></use></svg>");
    public static string DestinationImage(string region) => region.Contains("Hội An") ? "/images/hoian.jpg" : region.Contains("Hải Phòng") || region.Contains("Lan Hạ") || region.Contains("Hạ Long") ? "/images/vietnam-bay.jpg" : "/images/dalat.jpg";
    public static string ServiceImage(DichVuDuLich s) => s.LoaiDichVu == "Lưu trú" ? "/images/stay.jpg" : s.LoaiDichVu == "Ăn uống" ? "/images/food.jpg" : DestinationImage(s.KhuVucPhucVu);
    public static string CategoryIcon(string type) => type switch { "Lưu trú" => "bed", "Ăn uống" => "food", "Phương tiện" => "car", "Hoạt động" => "compass", _ => "pin" };
}
