using HoTroDuLich.Web.Data;
using HoTroDuLich.Web.Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.RateLimiting;
using System.Security.Claims;
var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews(o => {
 o.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());
 o.ModelMetadataDetailsProviders.Add(new HoTroDuLich.Web.Models.VietnameseMetadataProvider());
 o.ModelBindingMessageProvider.SetAttemptedValueIsInvalidAccessor((v,f)=>$"Giá trị nhập cho {f} không hợp lệ.");
 o.ModelBindingMessageProvider.SetValueMustNotBeNullAccessor(_=>"Vui lòng nhập thông tin bắt buộc.");
 o.ModelBindingMessageProvider.SetValueMustBeANumberAccessor(f=>$"{f} phải là một số hợp lệ.");
});
builder.Services.AddDbContext<AppDbContext>(o => o.UseSqlServer(builder.Configuration.GetConnectionString("HoTroDuLich")));
builder.Services.AddHttpContextAccessor(); builder.Services.AddScoped<TravelService>();
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(o => {
 o.LoginPath="/Account/Login"; o.AccessDeniedPath="/Account/Denied"; o.ExpireTimeSpan=TimeSpan.FromMinutes(30); o.SlidingExpiration=true;
 o.Cookie.HttpOnly=true; o.Cookie.SameSite=SameSiteMode.Lax;
 o.Events.OnRedirectToAccessDenied=c=>{c.Response.StatusCode=StatusCodes.Status403Forbidden;c.Response.ContentType="text/plain; charset=utf-8";return c.Response.WriteAsync("Bạn không có quyền truy cập chức năng này theo vai trò hiện tại.");};
 o.Events.OnValidatePrincipal=async c => {
  var id=long.TryParse(c.Principal?.FindFirstValue(ClaimTypes.NameIdentifier),out var v)?v:0;
  var db=c.HttpContext.RequestServices.GetRequiredService<AppDbContext>();
  var a=await db.TaiKhoan.AsNoTracking().SingleOrDefaultAsync(x=>x.MaTaiKhoan==id);
  if(a==null || a.TrangThai!="HoatDong" || a.DauPhien.ToString()!=c.Principal?.FindFirstValue("stamp") || !long.TryParse(c.Principal?.FindFirstValue("issued"),out var issued) || DateTime.UtcNow.Ticks-issued>TimeSpan.FromHours(8).Ticks) c.RejectPrincipal();
 };
});
builder.Services.AddAuthorization(SucAccess.Configure);
builder.Services.AddRateLimiter(o=>{o.RejectionStatusCode=429;o.AddPolicy("auth",c=>RateLimitPartition.GetFixedWindowLimiter(c.Connection.RemoteIpAddress?.ToString()??"local",_=>new FixedWindowRateLimiterOptions{PermitLimit=10,Window=TimeSpan.FromMinutes(1),QueueLimit=0}));});
builder.Services.AddHostedService<SuspensionReminder>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.Use(async (c,next)=>{c.Response.Headers["X-Content-Type-Options"]="nosniff";c.Response.Headers["X-Frame-Options"]="DENY";c.Response.Headers["Referrer-Policy"]="strict-origin-when-cross-origin";c.Response.Headers["Content-Security-Policy"]="default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'";await next();});
app.UseStaticFiles();
app.UseRouting();

app.UseRateLimiter(); app.UseAuthentication();
app.Use(async (c,next)=>{
 if(c.Request.Path=="/" && c.User.Identity?.IsAuthenticated==true){
  var role=c.User.FindFirstValue(ClaimTypes.Role)??"";
  if(role==TravelService.ProviderRole||role==TravelService.AdminRole){c.Response.Redirect(SucAccess.Home(role));return;}
 }
 await next();
});
app.UseAuthorization();

app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Explore}/{action=Index}/{id?}")
    .WithStaticAssets();


if(args.Contains("--initialize") || app.Environment.IsDevelopment()) {using var scope=app.Services.CreateScope();await Seed.Initialize(scope.ServiceProvider,app.Environment.ContentRootPath);if(args.Contains("--initialize"))return;}
app.Run();
