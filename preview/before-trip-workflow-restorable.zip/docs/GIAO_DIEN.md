# Giao diện Hành Trình — Open Atlas

Bản hiện hành ngày 04/11/2026 dùng xanh biển, xanh đậm, nền trắng và điểm nhấn vàng xanh. Trang khám phá kết hợp ảnh lớn, bưu thiếp điểm đến, tuyến đi ba bước và tìm kiếm ngay phần đầu. Trang quản lý dùng thẻ, lưới, trạng thái và thao tác rõ ràng cùng một hệ thống thiết kế.

Quy tắc đầy đủ và các truy vấn ui-ux-pro-max đã sử dụng nằm trong [MASTER.md](../design-system/hanh-trinh/MASTER.md). CSS hiện hành nằm ở `wwwroot/css/experience.css`; không tải font hay thư viện giao diện ngoài.

## Menu theo nhóm

| Nhóm | Chức năng |
|---|---|
| Khám phá | Điểm đến; lưu trú; ăn uống; di chuyển; hoạt động |
| Chuyến đi | Lịch trình cá nhân; đặt dịch vụ; hỗ trợ chuyến đi |
| Đặt dịch vụ | Tab yêu cầu đặt; thay đổi/hủy; kết quả phục vụ |
| Đồng hành | Tìm người; bài đăng của tôi; kết nối của tôi |
| Nhà cung cấp | Dịch vụ & đặt chỗ; hồ sơ đối tác; tài khoản |
| Quản trị | Tổng quan; duyệt & xác minh; quyền nhà cung cấp; nhật ký; tài khoản |

Trang công khai có ba menu nhóm. Trong không gian cá nhân, nhà cung cấp và quản trị, thanh bên tự mở nhóm đang sử dụng. Các bước xử lý của đặt dịch vụ được gom trong cùng một trang có tab; không tách chúng thành mục ngang hàng trên menu chính. Chi tiết một yêu cầu vẫn giữ tab riêng theo đúng mã yêu cầu.

## Các bố cục chính

- Khám phá: hero và tìm kiếm; điểm đến; hướng dẫn xây lịch trình; dịch vụ; kết nối đồng hành. Kết quả tìm kiếm bỏ hero để dành chỗ cho bộ lọc và kết quả. Chuyển loại dịch vụ giữ từ khóa, khu vực và khoảng giá.
- Chuyến đi: banner, lối tắt công việc liên quan, số liệu thật, tìm theo tên/điểm đến không dấu, lọc bản nháp/đã xác nhận, thẻ có ảnh và ngày khởi hành. Không có JavaScript thì vẫn xem được toàn bộ danh sách.
- Đồng hành: ảnh điểm đến, nơi đến và ngày đi hiển thị trước; ngân sách và hình thức đi nằm trong bộ lọc mở thêm. Nút tìm người dẫn thẳng tới biểu mẫu; sau tìm kiếm bỏ phần giới thiệu lớn để ưu tiên bộ lọc và kết quả. Bộ lọc phụ đã dùng tự mở và giữ giá trị. Thẻ vẫn tuân thủ phạm vi chia sẻ của từng nhu cầu.
- Đối tác: khu vực dịch vụ, lối tắt yêu cầu/hồ sơ/quyền, trạng thái xác minh và hoạt động, ảnh minh họa từng dịch vụ.
- Quản trị: tổng quan công việc, số liệu liên kết tới danh sách, nhóm xét duyệt/xác minh và các thẻ nghiệp vụ.

## Thao tác và khả năng truy cập

Menu dùng nhấp/bàn phím; Escape đóng và trả focus. Trên điện thoại, menu có nền phủ, khóa nội dung phía sau và giữ Tab trong vùng điều hướng; mục đang đóng không tham gia vòng Tab. Breakpoint JavaScript/CSS thống nhất 1000px. Điều khiển chính tối thiểu 44px, ô nhập văn bản trên điện thoại 16px; có focus ring, skip link, nhãn rõ ràng, trạng thái trống và hỗ trợ giảm chuyển động.

Danh sách đặt dịch vụ chuyển từ bảng sang thẻ có nhãn trên điện thoại. Các biểu mẫu, bảng quản trị, thông báo, kết quả phục vụ và vùng ngừng tài khoản dùng cùng token và khoảng cách. Không thêm số lượng người dùng, đánh giá hay xác nhận dịch vụ giả.

## Nghiệp vụ FullText

Giữ nguyên database, API, service, phân quyền và trạng thái nghiệp vụ. Lịch trình xác nhận riêng; yêu cầu đặt và nhu cầu đồng hành có bước xem trước; kết quả phục vụ, thay đổi/hủy và thỏa thuận tiếp tục làm việc theo đúng đối tượng. Chức năng ghi của khách du lịch không hiện với nhà cung cấp/quản trị. Thông báo tiếp tục dùng POST khi mở để đánh dấu đã đọc.

Kiểm tra HTTP theo bốn vai trò, giá trị tìm kiếm, tài nguyên và các trang: `tests/navigation-redesign.cjs`. Kết quả ở `tests/navigation-redesign-results.json`. Kiểm tra tương tác trình duyệt và ảnh của bản mới dùng tiền tố `preview/navigation-`.

Bản này build thành công với 0 lỗi, 0 cảnh báo; 102 kiểm tra HTTP và 23 kiểm tra tương tác trình duyệt đạt. Kết quả trình duyệt nằm ở `tests/navigation-browser-results.json`, gồm tìm kiếm không dấu, trạng thái trống, menu bàn phím, nhóm đang đóng, tab nghiệp vụ, giữ bộ lọc và bố cục ở 375px, 768px, 1024px, 1280px cùng điện thoại ngang 812×375. Các luồng được quan sát không ghi nhận lỗi/warning console.

Ảnh xem trước: [Trang chủ](../preview/navigation-home-desktop.png), [menu nhóm](../preview/navigation-menu-desktop.png), [điện thoại](../preview/navigation-home-mobile.png), [chuyến đi](../preview/navigation-plans-mobile.png), [nhà cung cấp](../preview/navigation-provider-desktop.png), [quản trị](../preview/navigation-admin-desktop.png).
