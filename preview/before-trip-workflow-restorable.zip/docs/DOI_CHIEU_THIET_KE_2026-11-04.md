> **Báo cáo lịch sử trước khi sửa mã.** Các F01–F15/T01–T13 dưới đây mô tả phiên bản được audit ban đầu, không phải kết luận hiện tại. Xem [báo cáo thực thi và kết quả mới](THUC_THI_FULLTEXT_2026-11-04.md). Mã nguồn gốc đã được lưu trong `preview/before-fulltext-implementation.zip`.

# Đối chiếu website Hành Trình với tài liệu thiết kế

Ngày kiểm tra: 04/11/2026.

**Kết luận: website có màn hình và xử lý cho cả 18 SUC, nhưng chưa được lập trình đúng nguyên trạng thiết kế.** Nền tảng công nghệ và bộ thực thể khá sát. Các khác biệt còn lại bao gồm lỗi vòng đời nghiệp vụ, thiếu luồng và trường dữ liệu, cấu trúc phần mềm, bảo mật và cấu hình vận hành. Giao diện được làm mới không làm những khác biệt nghiệp vụ này tự biến mất.

## Nguồn và phương pháp

- Tài liệu gốc: [bản FullText do người dùng cung cấp](<C:/Users/vanly/Downloads/26271.3-FullText-XayDungHeThongHoTroKhachDuLichTuTuc (4).docx>).
- Đối chiếu đặc tả SUC ở Chương 2, kiến trúc và các bảng thiết kế ở Chương 4; kiểm tra các hình kiến trúc và tư liệu HSKS trong Phụ lục. Trích dẫn theo mục/bảng của tài liệu, không suy đoán số trang Word.
- Đọc Controller, Service, ViewModel, Razor View, cấu hình EF Core, script SQL và các bộ kiểm thử hiện có. README chỉ dùng để tìm đường chạy, không dùng làm bằng chứng rằng phần mềm đã đúng.
- So sánh tên bảng/cột từ 25 bảng vật lý trong Word với `Database/schema.sql` hiện tại.
- Chạy các ca HTTP tái hiện trên **localhost:5218**, cơ sở dữ liệu riêng **HoTroDuLich_Audit_20261104_Design**. Không gửi các ca tạo/sửa dữ liệu tới website chính ở cổng 5216.
- Bằng chứng máy đọc được: [kết quả tái hiện](/D:/KLTN/preview/design-audit/probe-results.json), [đối chiếu lược đồ](/D:/KLTN/preview/design-audit/schema-comparison.json). Các ca này xác nhận các trường hợp cụ thể, không phải bộ chứng nhận đầy đủ 18 SUC.
- Các ca tái hiện tạo và đổi dữ liệu trong môi trường audit. Muốn chạy lại từ đầu cần một cơ sở dữ liệu kiểm tra mới có dữ liệu mẫu; tệp `supplement.cjs` dựa trên dữ liệu của lần chạy `probes.cjs`, không phải bộ test độc lập để chạy trên dữ liệu đang sử dụng.

## Phần đã bám thiết kế

| Hạng mục | Kết quả kiểm tra |
| --- | --- |
| Công nghệ, mô hình triển khai ứng dụng | ASP.NET Core MVC .NET 10, Razor, Bootstrap, EF Core, SQL Server; ứng dụng web đơn khối, có lớp xử lý nghiệp vụ và truy cập dữ liệu. Phù hợp hướng tổng thể ở 4.1–4.2. |
| Phạm vi sản phẩm | Có khám phá, lịch trình, đồng hành, tình huống phát sinh, dịch vụ, đặt/điều chỉnh/kết quả, tài khoản, xác minh và quản trị. Không thêm thanh toán trực tuyến hoặc hệ thống đặt chỗ ngoài phạm vi. |
| Dữ liệu nền | Khớp tên 25 bảng và 267 cột; có 38 khóa ngoại, 117 CHECK, 18 chỉ mục duy nhất. Không thiếu cột so với các bảng vật lý đã trích. Khớp số lượng chưa có nghĩa mọi biểu thức, mặc định và chỉ mục đều khớp. |
| Kiểm soát truy cập | Có chặn theo vai trò, chủ sở hữu/bên liên quan và trạng thái nhà cung cấp; Admin không tự kế thừa thao tác ghi của khách hoặc nhà cung cấp. Có khác biệt quyền đọc/hồ sơ cần chốt ở phần dưới. |
| An toàn cơ bản | Băm mật khẩu bằng PasswordHasher, Antiforgery toàn cục, Razor mã hóa HTML, CSP, giới hạn tần suất đăng nhập/đăng ký; tài liệu xác minh lưu ngoài wwwroot và tải qua kiểm tra quyền. |
| Phiên và đồng thời | Có kiểm tra DauPhien, trạng thái tài khoản, tối đa phiên 8 giờ, RowVersion, chỉ mục chống trùng và giao dịch nhiều bảng. |
| Nội dung dịch vụ | Bản cập nhật lưu riêng và không tự thay bản đã công bố trước khi Admin duyệt. Có lưu quyết định xác minh và quyền hoạt động. |

## Các lỗi cần sửa trước khi xác nhận đúng thiết kế

Mức **cao** là sai khác làm thay đổi hiệu lực thỏa thuận, quyết định hoặc điều kiện nghiệp vụ. Mức **vừa** là thiếu luồng, thông tin hoặc kiểm tra đã được đặc tả. “Tái hiện” nghĩa đã gửi yêu cầu và xem kết quả; “mã nguồn” nghĩa kết luận từ nhánh xử lý hiện có.

### F01 Thỏa thuận đồng hành đã kết thúc có thể sống lại

**Mức cao — đã tái hiện.** Mục 4.9.8, Bảng 4.198, 4.199 và 4.202 yêu cầu: một bên rút thì bản đang chờ phải thành `DaThayThe`; kết nối không nhận đề xuất mới khi thỏa thuận nội dung đã `DaNgung` hoặc `MotBenDaRut`.

Thực tế: xác nhận bản 1 → gửi bản 2 đang chờ → rút bản 1 → bên kia vẫn xác nhận bản 2 thành công (HTTP 302). Sau khi rút tiếp, gửi một bản mới cũng thành công. `AgreementAction` chỉ kết thúc bản được chọn; `ProposeAgreement` không kiểm tra thỏa thuận đã kết thúc. Đây là sai hiệu lực nghiệp vụ, không chỉ sai nhãn hiển thị.

Nguồn: [CompanionService.cs:20](/D:/KLTN/src/HoTroDuLich.Web/Services/CompanionService.cs:20). Cần kết thúc bản chờ trong cùng giao dịch với thao tác rút và kiểm tra trạng thái kết thúc ở mọi nhánh tạo/xác nhận.

### F02 Sửa hoạt động không hủy sự chấp nhận của lịch trình cũ

**Mức cao — đã tái hiện.** Mục 4.9.4, Bảng 4.181–4.184 quy định thay đổi nội dung kế hoạch `DaChapNhan` phải đưa về `Nhap` để khách chấp nhận lại.

Thực tế: tạo kế hoạch đã chấp nhận rồi thêm hoạt động, mở lại vẫn thấy `DaChapNhan`. `SaveActivity` và `DeleteActivity` chỉ đổi thời điểm cập nhật. `SavePlan` nhận trực tiếp trạng thái biểu mẫu nên sửa nội dung vẫn có thể giữ chấp nhận cũ.

Nguồn: [PlanService.cs:9](/D:/KLTN/src/HoTroDuLich.Web/Services/PlanService.cs:9). Cần gắn việc chấp nhận với nội dung đã xem, không chỉ với mã kế hoạch.

### F03 Thiếu chặn thời hạn sửa hoặc hủy dịch vụ

**Mức cao — đã tái hiện trường hợp ngày phục vụ.** Mục 4.9.13, Bảng 4.227–4.228 yêu cầu thỏa thuận đã xác nhận chỉ nhận đề nghị thay đổi/hủy khi `NgayBatDau > hôm nay` và chưa có kết quả. Sửa trực tiếp yêu cầu chỉ được khi `ChoPhanHoi`.

Thực tế: yêu cầu đã xác nhận có ngày phục vụ 04/11/2026 vẫn nhận đề nghị thay đổi trong chính ngày 04/11/2026 (302). `ChangeBooking` không kiểm tra mốc ngày/chưa có kết quả; `EditPendingBooking` còn cho sửa cả `DeXuatKhac` và không chặn ngày mới trong quá khứ.

Nguồn: [BookingService.cs:17](/D:/KLTN/src/HoTroDuLich.Web/Services/BookingService.cs:17). Cần kiểm tra lại toàn bộ điều kiện trong giao dịch ghi, không chỉ ẩn nút.

### F04 Cho tạo dữ liệu chuyến đi trong quá khứ và hiển thị nhu cầu đã hết ngày

**Mức vừa — đã tái hiện.** Bảng 4.179, 4.191–4.192 và điều kiện `NguoiXemThayDuoc` ở 4.9.1 yêu cầu ngày tạo mới không ở quá khứ, kết quả nhu cầu có `NgayKetThuc >= hôm nay`.

Thực tế: kế hoạch 01–02/01/2000 được lưu thành công; nhu cầu cùng khoảng ngày vẫn xuất hiện cho khách vãng lai. `Dates` chỉ kiểm tra thứ tự ngày; `VisibleNeeds` không lọc ngày hết hạn.

Nguồn: [TravelService.cs:21](/D:/KLTN/src/HoTroDuLich.Web/Services/TravelService.cs:21), [CompanionService.cs:7](/D:/KLTN/src/HoTroDuLich.Web/Services/CompanionService.cs:7). Thỏa thuận đề xuất mới cũng thiếu kiểm tra ngày đi không ở quá khứ trong mã nguồn.

### F05 Luồng phiên bản đồng hành chưa đúng thiết kế

**Mức vừa — xác nhận từ mã nguồn.** Bảng 4.199 cho phép bên còn lại đề xuất khác khi đang có bản nội dung `ChoXacNhan`, thay bản chờ bằng bản mới và kiểm tra `phienBanCoSo`.

Thực tế: có bản chờ là chặn mọi đề xuất mới; biểu mẫu dùng RowVersion của kết nối, không dùng phiên bản cơ sở mới nhất của thỏa thuận. Chưa kiểm tra nội dung đề xuất trùng bản đang hiệu lực. Cần xử lý đầy đủ nhánh “Đề xuất khác”, không chỉ tạo sau khi người kia từ chối.

Nguồn: [CompanionService.cs:20](/D:/KLTN/src/HoTroDuLich.Web/Services/CompanionService.cs:20), [Agreement.cshtml](/D:/KLTN/src/HoTroDuLich.Web/Views/Companions/Agreement.cshtml).

### F06 Nhà cung cấp tự đổi tiếp nhận và thiếu nhánh lưu nháp dịch vụ

**Mức vừa — nút thao tác và nhánh xử lý đã xác nhận.** Mục 4.9.10, BR06.01-5 quy định `TrangThaiTiepNhan` do hệ thống đổi, nhà cung cấp chỉ xem. Bảng 4.212 có hai thao tác `LuuNhap` và `GuiDang`.

Thực tế có `/Provider/Reception` cho nhà cung cấp tự tắt/mở. `SaveService` luôn gửi chờ duyệt; chưa có lưu nháp, chưa cho chọn `MaDiaDiem`. Bản mới của dịch vụ chưa từng duyệt cũng chưa đồng bộ đầy đủ các cột nội dung của `DichVuDuLich` theo Bảng 4.214.

Nguồn: [ProviderService.cs:11](/D:/KLTN/src/HoTroDuLich.Web/Services/ProviderService.cs:11), [ProviderController.cs:17](/D:/KLTN/src/HoTroDuLich.Web/Controllers/ProviderController.cs:17). Cần chốt theo BR06.01-5 trước khi giữ chức năng bổ sung ngoài thiết kế.

### F07 Tạm ngừng phục vụ chưa kiểm tra đủ điều kiện

**Mức vừa — đã tái hiện.** Bảng 4.212–4.214 yêu cầu có ngày bắt đầu và lý do; ngày kết thúc nếu có phải hợp lệ và không trước hôm nay.

Thực tế: gửi bản cập nhật có khoảng tạm ngừng nhưng không có lý do vẫn thành công (302). `SaveService` chỉ kiểm tra thứ tự ngày và có ngày bắt đầu khi có ngày kết thúc.

Nguồn: [ProviderService.cs:11](/D:/KLTN/src/HoTroDuLich.Web/Services/ProviderService.cs:11).

### F08 Thương lượng đặt dịch vụ chưa thay đổi điều kiện có cấu trúc

**Mức vừa — xác nhận từ mã nguồn.** Mục 4.9.12, Bảng 4.225 yêu cầu nhà cung cấp đề xuất các điều kiện mới gồm ngày, số người, số lượng, chi phí…, tăng phiên bản và lưu điều kiện cũ.

Thực tế: `BookingAction` chỉ nhận `CommandInput.Text` cho đề xuất khác; ngày/số người/số lượng/chi phí không đổi. Phía khách xác nhận một đoạn văn trong khi dữ liệu điều kiện vẫn là giá trị cũ. `ChangeAction` cũng chỉ nhận đề xuất văn bản, chưa cập nhật các trường mới theo Bảng 4.230. Chưa có trường giờ đến/đi và danh sách hạng mục lựa chọn trong biểu mẫu đặt.

Nguồn: [BookingService.cs:11](/D:/KLTN/src/HoTroDuLich.Web/Services/BookingService.cs:11), [Inputs.cs](/D:/KLTN/src/HoTroDuLich.Web/Models/Inputs.cs). Cần ViewModel riêng cho đề xuất điều kiện, không dùng một ô văn bản thay cho toàn bộ thỏa thuận.

### F09 Chưa ghi kết quả theo từng hạng mục

**Mức vừa — xác nhận từ mã nguồn.** Mục 4.9.14, Bảng 4.232–4.235 yêu cầu một kết quả cho từng hạng mục chính/chọn thêm và tổng hợp trạng thái yêu cầu bằng thuật toán `TongHop`.

Thực tế `RecordResult` tạo một dòng cho cả dịch vụ và chặn nếu yêu cầu đã có bất kỳ kết quả nào. Chưa dựng hạng mục từ `NoiDungLuaChon`, chưa có danh sách nhập từng hạng mục, chưa có thuật toán tổng hợp nhiều kết quả. Đã có phản ánh và nhánh đối chiếu một kết quả, nhưng chưa đủ thiết kế.

Nguồn: [BookingService.cs:27](/D:/KLTN/src/HoTroDuLich.Web/Services/BookingService.cs:27), [Outcome.cshtml](/D:/KLTN/src/HoTroDuLich.Web/Views/Bookings/Outcome.cshtml).

### F10 Đăng ký và đăng nhập thiếu kiểm tra và chức năng đã đặc tả

**Mức vừa — đã tái hiện một phần.** Bảng 4.238 yêu cầu mật khẩu có chữ và số, không chứa email; nhà cung cấp nộp 1–5 tài liệu, nhập loại hình/người liên hệ/thông tin hồ sơ riêng. Bảng 4.245–4.247 có đăng nhập bằng email hoặc số điện thoại, cập nhật băm khi cần và đổi mật khẩu bắt buộc cho Admin lần đầu.

Thực tế: mật khẩu `abcdefgh` được chấp nhận; đăng ký nhà cung cấp không có tài liệu cũng thành công. Một số trường đơn vị/hồ sơ được tự gán từ tên/email thay vì cho nhập. Chỉ đăng nhập email; chưa có action đổi mật khẩu, chưa dùng `PhaiDoiMatKhau`, chưa xử lý `SuccessRehashNeeded` và chưa xác minh với băm giả khi định danh không tồn tại.

Nguồn: [AccountService.cs:7](/D:/KLTN/src/HoTroDuLich.Web/Services/AccountService.cs:7), [AccountController.cs:11](/D:/KLTN/src/HoTroDuLich.Web/Controllers/AccountController.cs:11), [Register.cshtml](/D:/KLTN/src/HoTroDuLich.Web/Views/Account/Register.cshtml).

### F11 Quyền riêng tư mặc định và thông tin đồng hành chưa khớp

**Mức vừa — xác nhận từ mã nguồn.** Bảng 4.238 tạo hồ sơ với `RiengTu`; Bảng 4.190 mở nhu cầu mặc định `KhiKetNoi`. Mục 4.9.5 yêu cầu vẫn cho khách đã đăng nhập thấy phần tóm tắt nhu cầu `KhiKetNoi`, ẩn các trường nhạy cảm trước khi kết nối; tên hiển thị vẫn có ngay cả hồ sơ riêng tư. Liên hệ chỉ hiện sau kết nối đã chấp nhận.

Thực tế đăng ký đặt hồ sơ `CongKhai`, nhu cầu mới cũng mặc định `CongKhai`; nhu cầu `KhiKetNoi` bị ẩn toàn bộ với người chưa kết nối, gây khó gửi lời mời. `DisplayNames` còn ẩn tên hồ sơ riêng tư và các trang chưa có dữ liệu liên hệ sau kết nối. Đây là thiếu phép chiếu dữ liệu đúng thiết kế; không kết luận rằng hiện đang làm lộ email/số điện thoại.

Nguồn: [AccountService.cs:20](/D:/KLTN/src/HoTroDuLich.Web/Services/AccountService.cs:20), [CompanionService.cs:7](/D:/KLTN/src/HoTroDuLich.Web/Services/CompanionService.cs:7), [PageData.cs:10](/D:/KLTN/src/HoTroDuLich.Web/Services/PageData.cs:10).

### F12 Ngừng tài khoản chặn cả đề xuất chưa xác nhận và thiếu bước xác nhận cuối

**Mức vừa — đã tái hiện việc chặn.** Mục 4.9.20, Bảng 4.260–4.261 chỉ coi thỏa thuận đồng hành `DaXacNhan` là nghĩa vụ chặn; các bản `ChoXacNhan` được thay thế khi ngừng. Thiết kế có xác thực lại, hiển thị hệ quả và mã xác nhận Data Protection hạn 5 phút.

Thực tế một tài khoản chỉ còn bản thỏa thuận đang chờ vẫn bị 422, chưa ngừng được. `Deactivate` gộp mật khẩu và ngừng trong một POST, không có mã xác nhận hạn 5 phút hoặc trang liệt kê nghĩa vụ/hệ quả cụ thể. Chưa có thao tác xử lý các bản chờ thành `DaThayThe` như đặc tả.

Nguồn: [AccountService.cs:31](/D:/KLTN/src/HoTroDuLich.Web/Services/AccountService.cs:31), [Deactivate.cshtml](/D:/KLTN/src/HoTroDuLich.Web/Views/Account/Deactivate.cshtml).

### F13 Thiếu các bước xem trước và giữ biểu mẫu khi lỗi

**Mức vừa — đã tái hiện việc trả trang lỗi thay biểu mẫu.** SUC03.02 có `xemTruoc` trước công bố (Bảng 4.191); SUC07.01 có `kiemTraTruocGui` và trang xác nhận (Bảng 4.219). Quy ước 4.9.1 và các nhánh E3 yêu cầu lỗi nhập/lỗi ghi giữ nội dung để sửa và thử lại.

Thực tế hai chức năng gửi thẳng từ biểu mẫu tới lưu. Khi POST kế hoạch thiếu tên, trả 400 nhưng là View `Failure`, không có ô điểm đến và các trường đã nhập để sửa ngay. Nút quay lại bằng lịch sử trình duyệt không tương đương server dựng lại biểu mẫu với lỗi từng trường.

Nguồn: [AppController.cs:8](/D:/KLTN/src/HoTroDuLich.Web/Controllers/AppController.cs:8), [CompanionsController.cs](/D:/KLTN/src/HoTroDuLich.Web/Controllers/CompanionsController.cs), [BookingsController.cs](/D:/KLTN/src/HoTroDuLich.Web/Controllers/BookingsController.cs).

### F14 Tình huống phát sinh chưa đủ thao tác đầu vào

**Mức vừa — xác nhận từ mã nguồn.** Bảng 4.206 nhận danh sách hoạt động bị ảnh hưởng; Bảng 4.209 có lựa chọn `ChuaGiaiQuyet` và không bắt buộc kết quả thực tế cho mọi trường hợp.

Thực tế `IncidentInput` chỉ có một `ActivityId`, loại tình huống là văn bản tự do; `IncidentAction` không nhận `ChuaGiaiQuyet` và bắt buộc nội dung cho cả dừng xử lý. Phần chọn phương án, giữ lịch sử và khóa tình huống đã kết thúc đã có.

Nguồn: [PlanService.cs:17](/D:/KLTN/src/HoTroDuLich.Web/Services/PlanService.cs:17), [Support/Create.cshtml](/D:/KLTN/src/HoTroDuLich.Web/Views/Support/Create.cshtml).

### F15 Quyền hoạt động còn thiếu xử lý hệ quả chi tiết

**Mức vừa — xác nhận từ mã nguồn.** Bảng 4.252 yêu cầu hiển thị số dịch vụ/yêu cầu bị ảnh hưởng trước quyết định; Bảng 4.254–4.255 cập nhật giải trình đang chờ khi khôi phục/thu hồi; Bảng 4.217 mở tiếp nhận khi duyệt lại dịch vụ sau xác minh lại.

Thực tế trang quyết định chỉ có giải thích chung, chưa có trang tính số lượng hệ quả. `SetProviderRights` chưa đóng các giải trình đang chờ tương ứng; thu hồi gán mọi dịch vụ `NgungCongBo` thay vì phân biệt đã duyệt và chưa từng duyệt. `ReviewService` sau xác minh lại chưa đưa tiếp nhận từ `KhongTiepNhanMoi` về `TiepNhan`/xóa mã quyết định như Bảng 4.217. `Explain` chưa bảo đảm gắn quyết định mới nhất và chưa gửi thông báo cho mọi Admin.

Nguồn: [ProviderService.cs:23](/D:/KLTN/src/HoTroDuLich.Web/Services/ProviderService.cs:23), [Admin/Provider.cshtml](/D:/KLTN/src/HoTroDuLich.Web/Views/Admin/Provider.cshtml).

## Các phần triển khai khác thiết kế kỹ thuật

| Mã | Thiết kế | Hiện trạng và ảnh hưởng |
| --- | --- | --- |
| T01 | 4.3: 19 component nghiệp vụ, 43 package luồng, 19 giao diện Service và 11 giao diện liên component. Controller chỉ phụ thuộc giao diện của component. | Đăng ký một `TravelService`, chia thành các tệp `partial`, các Controller gọi lớp cụ thể. Chưa có kiến trúc component/contracts như sơ đồ. Đây là khác biệt cấu trúc lớn, dù một phần hành vi vẫn tương đương. |
| T02 | 4.3, 4.6: lớp miền có enum và chuyển trạng thái; View dùng ViewModel, không đưa trực tiếp thực thể ra View. | Trạng thái là chuỗi; nhiều View nhận `List<...Entity>`, dùng ViewBag/tuple; luật trạng thái tập trung trong TravelService. Cần tách dần, không chỉ đổi tên thư mục. |
| T03 | 4.8.9: database-first, script là nguồn chuẩn, thay đổi bằng ALTER đánh phiên bản. | `Seed.Initialize` sinh `schema.sql` từ EF và chạy `EnsureCreatedAsync`; có tự thêm CHECK/index trong Development. Hướng định nghĩa lược đồ đang ngược với thiết kế. |
| T04 | 4.8: 34 chỉ mục truy vấn, 4 view, kiểu `datetime2(0)`/`time(0)`, các DEFAULT theo bảng. | Script hiện có 26 chỉ mục thường, 0 view, 0 mệnh đề DEFAULT; thời điểm/giờ dùng độ chính xác mặc định. Nhiều chỉ mục hiện tại chỉ phục vụ FK, không thay các chỉ mục ghép/lọc cho tìm kiếm và hàng đợi. |
| T05 | 4.8.1, 4.8.7–4.8.8: collation tiếng Việt, READ_COMMITTED_SNAPSHOT, quyền ứng dụng tối thiểu, sao lưu/khôi phục. | Chưa có script thiết lập tương ứng trong dự án được kiểm tra. Chưa xác minh cấu hình máy chủ hay lịch tác vụ ngoài dự án. Không coi môi trường LocalDB Development là bằng chứng vận hành đã đạt. |
| T06 | 4.5.6, 4.9.1: thử lại toàn bộ giao dịch tối đa 3 lần khi deadlock/timeout; phân loại lỗi 400/403/404/409/422/503/500. | `Execute` dùng Serializable, không có vòng thử lại. `AppController` gộp mọi DbUpdateException thành 409; đối tượng không thuộc mình nhiều nơi trả 403 thay vì 404 theo thiết kế. Chưa có danh mục 98 mã lỗi trong tệp tài nguyên. |
| T07 | 4.4: cookie Secure Always, HTTPS redirection, cấu hình khóa Data Protection rõ ràng, bắt buộc đổi mật khẩu Admin, nhật ký bảo mật. | Chưa cấu hình `Cookie.SecurePolicy=Always`, `UseHttpsRedirection`, lưu/bảo vệ khóa theo cấu hình thiết kế và luồng đổi mật khẩu. Có HSTS ngoài Development nhưng thời lượng dùng mặc định. Chưa đủ nhật ký đăng nhập thất bại, đăng xuất, từ chối quyền, CSRF/rate limit như SK01–SK10. Đây là khoảng trống trong cấu hình mã nguồn, chưa phải kiểm toán môi trường Production. |
| T08 | 4.9.1: tệp lưu trước giao dịch; nếu giao dịch lỗi thì xóa bù. | `StoreFiles` lưu tệp thật trước khi ghi; các nhánh đăng ký/bổ sung/giải trình chưa có xóa bù khi rollback. Có thể để lại tệp không gắn bản ghi. |
| T09 | 4.9.1: mọi danh sách 20 dòng/trang và thứ tự ổn định. | Chỉ một số danh sách Admin có phân trang; khám phá/nhu cầu lấy tối đa 100, nhiều danh sách cá nhân lấy toàn bộ. Chưa đạt phân trang theo từng action. |
| T10 | 4.9.3: khu vực lấy từ dữ liệu, tìm từ khóa trong tên/mô tả; chi tiết địa điểm kèm dịch vụ liên quan. | Trang khám phá hardcode ba khu vực; tìm tên/khu vực, chưa tìm mô tả; trang địa điểm chưa nạp danh sách dịch vụ cùng MaDiaDiem. |
| T11 | 4.9.18: ảnh đại diện, hồ sơ đọc và thông tin liên hệ nhà cung cấp được sửa theo vai trò. | Chưa có tải ảnh đại diện hoặc các trường liên hệ NCC riêng trong ProfileInput; chưa có đầy đủ thông tin chỉ đọc theo thiết kế. |
| T12 | 4.9.21: loại thông báo theo nghiệp vụ, huy hiệu số chưa đọc, mở thông báo dẫn tới đối tượng; nhắc hạn quyết định hiện hành. | `Notify` dùng chung loại `NghiepVu`; thanh điều hướng chưa có số chưa đọc; `Read` về danh sách thay vì đối tượng. Nhắc hạn chạy chu kỳ 30 phút sau 7 giờ, chưa lọc quyết định đình chỉ mới nhất nên có thể nhắc cả quyết định cũ khi NCC bị đình chỉ lần khác. |
| T13 | 4.2, 4.8.10: kiểm thử đơn vị/tích hợp và xác nhận từng CHECK, cấu hình SQL Server, hành vi đồng thời. | Có các script HTTP và kết quả cũ (193, 286, 89 kiểm tra). Chưa có bộ xUnit/WebApplicationFactory và bộ kiểm tra toàn bộ ràng buộc/đồng thời tương ứng trong dự án. Không dùng kết quả cũ để khẳng định bản hiện tại đúng toàn bộ thiết kế. |

Nguồn tiêu biểu: [Program.cs](/D:/KLTN/src/HoTroDuLich.Web/Program.cs), [TravelService.cs](/D:/KLTN/src/HoTroDuLich.Web/Services/TravelService.cs), [Seed.cs](/D:/KLTN/src/HoTroDuLich.Web/Data/Seed.cs), [schema.sql](/D:/KLTN/src/HoTroDuLich.Web/Database/schema.sql), [SuspensionReminder.cs](/D:/KLTN/src/HoTroDuLich.Web/Services/SuspensionReminder.cs).

## Ma trận bao phủ 18 SUC

“Có” ở đây là đã có màn hình/xử lý tương ứng, không phải đã đạt mọi luồng.

| SUC | Màn hình và luồng cốt lõi | Phần chưa đạt cần đối chiếu tiếp |
| --- | --- | --- |
| 01.01 Tìm thông tin | Có bộ lọc, danh sách, chi tiết | T09–T10; quyền công khai ở phần cần chốt |
| 02.01 Lập kế hoạch | Có tạo/sửa, hoạt động, cảnh báo giờ/ngân sách, chấp nhận | F02, F04; thứ tự hoạt động/ngày rỗng/phân trang chưa đúng đầy đủ Bảng 4.180–4.183 |
| 03.01 Tìm người đồng hành | Có tiêu chí và chi tiết nhu cầu | F04, F11; bộ lọc ngân sách chưa giữ nhu cầu có ngân sách NULL theo Bảng 4.188 |
| 03.02 Công bố nhu cầu | Có đăng/sửa/dừng, phạm vi chia sẻ | F04, F11, F13 |
| 04.01 Kết nối | Có gửi, chấp nhận, từ chối, rút, chống trùng | F11; thiếu chi tiết/liên hệ theo Bảng 4.196; lời nhắn đang bắt buộc thay vì tùy chọn |
| 04.02 Thỏa thuận đồng hành | Có phiên bản, xác nhận/từ chối, rút/cùng ngừng | F01, F05 |
| 05.01 Tình huống phát sinh | Có tình huống, phương án, lịch sử/kết quả | F14 |
| 06.01 Quản lý dịch vụ | Có gửi bản mới/cập nhật, tạm ngừng, lịch sử | F06–F07 |
| 06.02 Xét duyệt dịch vụ | Có duyệt/từ chối/cần sửa đúng bản | F15, T09; chưa đủ so sánh từng trường và mở lại tiếp nhận sau xác minh lại |
| 07.01 Đặt dịch vụ | Có gửi, chống gửi lặp tuần tự, phản hồi, xác nhận đề xuất | F08, F13; chưa xác nhận hành vi idempotency khi gửi đồng thời |
| 08.01 Thay đổi hoặc hủy | Có đề nghị riêng, phản hồi, giữ điều kiện cũ | F03, F08 |
| 09.01 Kết quả dịch vụ | Có kết quả, phản ánh và đối chiếu | F09 |
| 10.01 Đăng ký | Có hai loại tài khoản, chặn đăng ký Admin | F10–F11 |
| 10.02 Xác minh NCC | Có hồ sơ, tài liệu, quyết định, bổ sung/nộp lại | F10, T08; cần đủ đầu vào tài liệu/người đại diện theo Bảng 4.243 |
| 11.01 Đăng nhập | Có cookie, phân vai, đăng xuất, giới hạn tần suất | F10, T07 |
| 12.01 Cập nhật hồ sơ | Có thông tin cơ bản/phạm vi chia sẻ | T11; quyền Admin khác Chương 4 |
| 13.01 Quyền hoạt động | Có đình chỉ/khôi phục/thu hồi/giải trình | F15, T12 |
| 14.01 Ngừng tài khoản | Có mật khẩu xác thực, kiểm tra nghĩa vụ, thu hồi phiên | F12 |

## Điểm cần thống nhất trong tài liệu và quyền truy cập

1. **Quyền đọc công khai khác ma trận hiện tại.** Bảng 4.34 cho cả khách, NCC và Admin xem SUC01.01/03.01; mục 4.9.5 còn nêu người đăng nhập không phải khách xem nhu cầu `CongKhai`. `SucAccess.Rules` hiện chỉ cho vai trò khách khi đã đăng nhập. Đã thử `/Explore/Index`: NCC và Admin đều 403. Đây là khác biệt rõ với Chương 4; cần thống nhất với danh sách actor ở đặc tả SUC Chương 2 trước khi thay quyền.
2. **Hồ sơ Admin.** Bảng 4.1, 4.34, policy `DaXacThuc` và mục 4.9.18 cho Admin cập nhật hồ sơ; ma trận SUC hiện tại của dự án cấm. Đã thử Admin `/Account/Profile`: 403. Tài liệu có chỗ liệt kê actor hồ sơ chỉ gồm khách/NCC. Cần chọn một yêu cầu chuẩn và cập nhật đồng bộ tài liệu, code và test; không suy luận Admin có mọi quyền.
3. **Số action.** Mục 4.9.2 ghi 88 action nghiệp vụ; 4.3/4.10 ghi 91. Có thể 91 là 88 cộng ba action dùng chung ở 4.9.21, cần nói rõ. Không lấy chênh lệch số Controller/action gộp làm bằng chứng duy nhất rằng thiếu chức năng.
4. **Mô hình phân tích cũ.** Bảng quan hệ ở 3.1 còn “Mục thông tin tham khảo”, trong khi BR01.01-4 và Chương 4 loại bỏ bộ sưu tập tham khảo. Không yêu cầu lập trình thêm bộ sưu tập chỉ để khớp dòng cũ này.
5. **Giá trị đề xuất chưa chốt.** Mục 4.10.5 ghi tiêu chí tài liệu xác minh, thời hạn phản hồi, hạn phản ánh 30 ngày và giờ nhắc 07:00 còn cần chốt. Tuy vậy Bảng 4.238/4.243 đã quy định đầu vào 1–5 tệp; hiện trạng chấp nhận không có tệp vẫn khác đặc tả xử lý đang viết.

Nguồn quyền hiện tại: [SucAccess.cs](/D:/KLTN/src/HoTroDuLich.Web/Services/SucAccess.cs), [ma trận của dự án](/D:/KLTN/docs/MA_TRAN_QUYEN_SUC.md). Các test đang kỳ vọng 403 phải được cập nhật nếu chọn Chương 4 làm chuẩn.

## Giao diện và phần đã cải thiện

Các hình HSKS ở Phụ lục là tư liệu khảo sát: bảng tổng hợp, lịch trình bảng tính, Travel Buddy, trang Booking.com và các phiếu nghiệp vụ. Chúng không phải bộ mockup hoàn chỉnh của Hành Trình để so giống từng pixel. Tiêu chí đối chiếu UI là trường nhập, thông tin hiển thị, bước xác nhận, quyền và trạng thái trong các SUC.

Đã áp dụng ui-ux-pro-max để làm mới phần trình bày:

- Trang chủ kiểu tạp chí du lịch: nền kem, xanh rừng, cam đất, tiêu đề có điểm nhấn serif, ảnh lớn và bố cục điểm đến bất đối xứng.
- Thanh tìm kiếm có nhãn rõ, gợi ý điểm đến; chuyển loại dịch vụ giữ từ khóa/khu vực/khoảng giá; thẻ dịch vụ có nút Chi tiết bằng chữ.
- Trang đồng hành có hướng dẫn kết nối, biểu mẫu dễ đọc, giữ hình thức đi khi tìm; thẻ hiển thị người đăng, nơi đến, ngày/ngân sách. Phần hướng dẫn phụ được lược trên điện thoại để ưu tiên bộ lọc.
- Trang nhà cung cấp tách rõ trạng thái xác minh/quyền hoạt động và số liệu dịch vụ; danh sách có phân cấp nội dung/hành động.
- Danh sách đặt dịch vụ là bảng trên desktop, thẻ có nhãn trên điện thoại, giữ ngữ nghĩa bảng cho công nghệ hỗ trợ.
- Chữ nhập liệu 16 px, nút chính tối thiểu 44 px, focus rõ, menu trả focus khi Escape, hỗ trợ reduced-motion; màu/kiểu chữ áp dụng cho cả khu vực cá nhân và quản trị.

Các thay đổi này không phải xác nhận đã hoàn tất các bước xem trước, lỗi tại trường, trường hồ sơ và quyền còn thiếu trong F01–T13. Chưa thay chính sách phân quyền hoặc tự sửa toàn bộ nghiệp vụ trong lần làm giao diện/đối chiếu này.

## Kiểm tra bản giao diện sau chỉnh sửa

- `dotnet build src/HoTroDuLich.Web --no-restore`: thành công, 0 cảnh báo, 0 lỗi; `node --check src/HoTroDuLich.Web/wwwroot/js/site.js`: đạt.
- Kiểm tra trực tiếp các trang khám phá, kết quả tìm kiếm, đồng hành, đăng nhập/đăng ký, danh sách/chi tiết đặt dịch vụ, nhà cung cấp và quản trị. Kích thước gồm điện thoại 375 × 812, xoay ngang 812 × 375 và desktop 1366 × 900 theo các lượt lưu ở [ui-checks.json](/D:/KLTN/preview/design-audit/ui-checks.json).
- Trong các lượt đã lưu: không tràn ngang toàn trang, không có ảnh đã tải bị hỏng, ô nhập đang hiện có chữ từ 16 px và mỗi trang có một h1. Bảng quản trị vẫn cuộn trong khung riêng khi cần; danh sách đặt dịch vụ chuyển thành thẻ trên điện thoại.
- Thử menu bằng Escape: menu đóng và focus về nút mở. Thử đổi loại dịch vụ sau lọc: vẫn giữ Đà Lạt và giá từ 200.000 ₫. Thử tìm đồng hành: giữ hình thức đi đã chọn và tab đang hoạt động.
- Các cặp màu chính đã tính tỷ lệ tương phản: chữ chính/nền kem 11,33:1; chữ phụ/nền kem 5,37:1; cam đất/nền kem 5,16:1; chữ trắng/nút xanh 7,88:1. Không coi các phép đo này là chứng nhận toàn bộ website đạt WCAG.

Ảnh xem trước được lưu trong `preview/` cho trang chủ, đồng hành, nhà cung cấp và danh sách đặt dịch vụ. Website chính chạy tại [localhost:5216](http://localhost:5216); môi trường audit dùng cơ sở dữ liệu khác.

## Thứ tự hoàn thiện đề nghị

1. Sửa F01–F03 và bổ sung kiểm thử trạng thái kết thúc, hủy bản chờ, yêu cầu đúng phiên bản và mốc ngày phục vụ.
2. Sửa ngày quá khứ/hết hạn, quyền riêng tư mặc định, điều kiện tài liệu và mật khẩu; chốt hai điểm phân quyền Chương 2/4.
3. Hoàn thiện xem trước, xác nhận, giữ biểu mẫu khi lỗi; điều kiện thương lượng có cấu trúc; kết quả theo từng hạng mục; ngừng tài khoản theo hai bước.
4. Bổ sung phân trang, thông báo, nhật ký, giao dịch thử lại và xử lý tệp lỗi.
5. Nếu mục tiêu là bám nguyên trạng bản thiết kế để bảo vệ đồ án: tách contracts/components/ViewModel, chuyển enum, dùng script database-first và bổ sung cấu hình vận hành/kiểm thử như Chương 4. Nếu chủ động dùng kiến trúc đơn giản hơn, cần sửa tài liệu và ghi rõ quyết định thay thế.

Không gán một tỷ lệ phần trăm “đúng thiết kế” khi chưa có tiêu chí chấm từng luồng và trọng số thống nhất. Kết luận có thể kiểm chứng hiện tại là: **bao phủ các nhóm chức năng, cấu trúc dữ liệu nền khá sát, nhưng còn những sai khác nghiệp vụ và kỹ thuật quan trọng nên chưa đạt nguyên trạng thiết kế.**

