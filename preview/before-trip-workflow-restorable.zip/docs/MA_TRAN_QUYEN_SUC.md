# Phân quyền theo FullText, Chương 4

Nguồn hiện hành: bản FullText người dùng cung cấp, đặc biệt Bảng 4.86 và các action ở mục 4.9. Khi phần actor ở Chương 2 khác với thiết kế chi tiết Chương 4, hợp đồng action của Chương 4 được dùng để triển khai.

Vai trò không kế thừa nhau. Ngoài policy của route, Service tiếp tục kiểm tra chủ sở hữu/bên liên quan, trạng thái đối tượng, trạng thái nhà cung cấp và RowVersion.

| SUC | Chưa đăng nhập | Khách du lịch | Nhà cung cấp | Quản trị viên |
| --- | --- | --- | --- | --- |
| 01.01 Tra cứu | Nội dung công khai | Nội dung công khai | Nội dung công khai | Nội dung công khai |
| 02.01 Kế hoạch | Đăng nhập trước | Chỉ kế hoạch của mình | Không | Không |
| 03.01 Tìm đồng hành | Chỉ nhu cầu công khai | Theo phạm vi chia sẻ/kết nối | Phạm vi như khách vãng lai | Phạm vi như khách vãng lai |
| 03.02 Công bố nhu cầu | Đăng nhập trước | Quản lý bài của mình | Không | Không |
| 04.01 Kết nối | Không | Gửi/rút của mình, nhận/từ chối lời mời gửi tới mình | Không | Không |
| 04.02 Thỏa thuận | Không | Chỉ trong kết nối của mình, đúng bên và phiên bản | Không | Không |
| 05.01 Tình huống | Không | Chỉ trong kế hoạch của mình | Không | Không |
| 06.01 Quản lý dịch vụ | Không | Không | Dịch vụ của mình, gửi đăng/cập nhật khi đủ quyền | Không |
| 06.02 Xét duyệt | Không | Không | Nhận kết quả | Quyết định đúng phiên bản |
| 07.01 Đặt dịch vụ | Đăng nhập trước | Gửi, theo dõi, rút và phản hồi yêu cầu của mình | Phản hồi yêu cầu cho dịch vụ mình sở hữu | Không |
| 08.01 Thay đổi/hủy | Không | Gửi/rút đề nghị hoặc chấp thuận đề xuất trong yêu cầu của mình | Phản hồi đề nghị thuộc dịch vụ mình | Không |
| 09.01 Kết quả | Không | Xem và phản ánh yêu cầu của mình | Ghi nhận/đối chiếu dịch vụ mình cung cấp | Không |
| 10.01 Đăng ký | Khách hoặc NCC | Chuyển về khu vực cá nhân | Chuyển về khu vực đối tác | Không đăng ký Admin qua web |
| 10.02 Xác minh | Không | Không | Xem/bổ sung/nộp lại hồ sơ của mình | Xem và quyết định xác minh |
| 11.01 Phiên | Đăng nhập | Đăng xuất, đổi mật khẩu | Đăng xuất, đổi mật khẩu | Đăng xuất, đổi mật khẩu |
| 12.01 Hồ sơ | Không | Hồ sơ của mình | Hồ sơ và trường liên hệ được phép của mình | Hồ sơ của mình |
| 13.01 Quyền hoạt động | Không | Không | Xem quyết định và gửi giải trình của mình | Xem hệ quả, đình chỉ/khôi phục/thu hồi, xét giải trình |
| 14.01 Ngừng tài khoản | Không | Tự yêu cầu khi đủ điều kiện | Tự yêu cầu khi đủ điều kiện | Không |

## Chính sách và dữ liệu riêng

Năm policy chuẩn: `LaKhachDuLich`, `LaNhaCungCap`, `LaQuanTriVien`, `LaKhachHoacNCC`, `DaXacThuc`. Các route công khai dùng `AllowAnonymous`; đăng ký/đăng nhập được chuyển về trang vai trò khi đã có phiên.

Nhu cầu `KhiKetNoi` chỉ trả phần tóm tắt cho khách du lịch chưa kết nối. Nội dung, ngân sách và mong muốn được che. Nhà cung cấp và Admin được xem nhu cầu công khai như khách vãng lai. Email/số điện thoại cá nhân chỉ được chia sẻ sau khi kết nối đã chấp nhận; tên hiển thị vẫn công khai.

Thông báo chỉ thuộc người nhận. Tệp xác minh/giải trình chỉ chủ hồ sơ và Admin được tải; mã của người khác trả 404. Ảnh đại diện tuân theo phạm vi hồ sơ. Nhật ký chỉ Admin xem. Tài khoản đã ngừng hoặc dấu phiên cũ không được tiếp tục dùng cookie.

HTTP 302 chuyển tới đăng nhập khi chưa xác thực; 403 cho sai vai trò/thao tác trên đối tượng được thấy; 404 cho đối tượng ngoài phạm vi sở hữu. POST phải có antiforgery. Nhật ký `TuChoiQuyen` và `AntiforgeryKhongHopLe` được ghi bằng ngữ cảnh riêng.

## Bằng chứng

`tests/fulltext-access-results.json`: 91 route × 4 nhóm người dùng, gồm policy, CSRF và phản hồi giới hạn tần suất ở các route xác thực. POST trong ma trận này cố ý thiếu CSRF nên không thay đổi dữ liệu nghiệp vụ. Kiểm tra quyền trên bản ghi và thao tác thành công thuộc `fulltext-workflow-results.json`; nhật ký quyền/CSRF thuộc `fulltext-security-results.json`.
