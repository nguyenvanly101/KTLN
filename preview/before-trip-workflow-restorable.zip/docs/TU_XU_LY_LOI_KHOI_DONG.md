# Tự xử lý lỗi khởi động Hành Trình

Hướng dẫn cho bản dự án tại `D:\KLTN`, ASP.NET Core .NET 10, SQL Server LocalDB `MSSQLLocalDB`, database `HoTroDuLich`, địa chỉ `http://localhost:5216`. Chạy các lệnh trong PowerShell bằng tài khoản Windows đang sở hữu database; trên máy hiện tại là `vanly`.

**1. Cách chạy hằng ngày**

```powershell
cd D:\KLTN
.\start.ps1 -Dev
```

`start.ps1` là script của dự án. `-Dev` làm script gọi `dotnet watch`, giúp cập nhật khi sửa mã. Nếu chỉ muốn chạy bình thường, dùng `.\start.ps1`.

Lệnh đầy đủ tương đương, dùng cả khi PowerShell không cho chạy file `.ps1`:

```powershell
dotnet watch --project D:\KLTN\src\HoTroDuLich.Web run --launch-profile http
```

Profile `http` trong `src\HoTroDuLich.Web\Properties\launchSettings.json` đặt môi trường `Development` và cổng 5216. `dev` ở cuối `dotnet run dev` được truyền vào ứng dụng; nó không phải cờ bật môi trường Development. `dotnet watch` là công cụ theo dõi thay đổi của .NET. [Microsoft: dotnet run](https://learn.microsoft.com/en-us/dotnet/core/tools/dotnet-run), [dotnet watch](https://learn.microsoft.com/en-us/dotnet/core/tools/dotnet-watch).

Dấu hiệu khởi động thành công:

```text
Now listening on: http://localhost:5216
Application started. Press Ctrl+C to shut down.
Hosting environment: Development
```

Giữ terminal đó mở và truy cập địa chỉ trên. Nhấn **Ctrl+C trong chính terminal ấy** khi muốn dừng web. Đóng tab trình duyệt không dừng tiến trình máy chủ. Chỉ mở một phiên chạy dự án trên cổng 5216.

**2. Đọc đúng vị trí lỗi**

Quá trình chạy gồm: tìm project → build → khởi tạo/kết nối database → mở cổng HTTP.

| Dòng báo lỗi hoặc trạng thái | Cần kiểm tra |
|---|---|
| `Couldn't find a project to run` | Thư mục hiện tại và đường dẫn `.csproj` |
| `Build FAILED`, `error CS...`, `error RZ...` | Dòng lỗi đầu tiên có tên file/số dòng; chưa đến bước chạy web |
| `MSB3021`, `MSB3027`, `file is being used by another process` | Bản web/tiến trình cũ đang giữ file build |
| `SqlException`, `error: 50`, `SQL Server process failed to start` | Trạng thái/kết nối LocalDB |
| `Address already in use`, `Failed to bind`, `10048` | Tiến trình khác đang giữ cổng 5216 |
| `FileLoadException`, `0x800711C7`, `Application Control policy has blocked this file` | Chính sách kiểm soát ứng dụng của Windows |
| `Now listening on...` | Web đã mở cổng; tiếp tục kiểm tra bằng trình duyệt/HTTP |

`Build succeeded` chỉ xác nhận biên dịch thành công. Sau đó ứng dụng vẫn có thể dừng do database, chính sách Windows hoặc cổng. Với `dotnet watch`, `Hot reload enabled` và `Waiting for changes` cũng chưa đủ để kết luận web đang chạy: tìm dòng `Now listening` và xem có exception ở phía trên không.

**3. Không tìm thấy project**

Thư mục `D:\KLTN` không chứa `.csproj`. File dự án ở `D:\KLTN\src\HoTroDuLich.Web\HoTroDuLich.Web.csproj`.

Kiểm tra:

```powershell
Get-Location
Test-Path D:\KLTN\src\HoTroDuLich.Web\HoTroDuLich.Web.csproj
```

`Test-Path` phải trả về `True`. Chạy bằng `start.ps1` như mục 1 hoặc chỉ rõ project:

```powershell
dotnet run --project D:\KLTN\src\HoTroDuLich.Web --launch-profile http
```

Nếu đã chuyển vào `D:\KLTN\src\HoTroDuLich.Web`, có thể dùng `dotnet run --launch-profile http` hoặc `dotnet watch run --launch-profile http`.

**4. Cổng 5216 bị chiếm hoặc file build bị khóa**

Trước hết tìm terminal đang chạy web hoặc `dotnet watch`, rồi nhấn **Ctrl+C** ở đó. Kiểm tra lại cổng:

```powershell
Get-NetTCPConnection -State Listen |
    Where-Object LocalPort -eq 5216 |
    Select-Object LocalAddress, LocalPort, OwningProcess
```

`OwningProcess` là mã tiến trình (PID), không phải mã cổng. Hai dòng IPv4/IPv6 có cùng PID thường thuộc cùng một tiến trình. Nếu không có kết quả và lệnh không báo lỗi quyền truy cập, hiện không có listener trên cổng này. Không giấu lỗi quyền truy cập bằng `SilentlyContinue` rồi kết luận cổng trống. Nếu cmdlet báo thiếu quyền, dùng `netstat -ano | findstr :5216` và tìm các dòng `LISTENING` có cổng cục bộ 5216. [Microsoft: Get-NetTCPConnection](https://learn.microsoft.com/en-us/powershell/module/nettcpip/get-nettcpconnection).

Nếu mất terminal cũ, **thay `12345` bằng PID vừa đọc được**, rồi xem tiến trình trước:

```powershell
Get-CimInstance Win32_Process -Filter 'ProcessId=12345' |
    Select-Object ProcessId, Name, ExecutablePath, CommandLine
```

Chỉ dừng khi đã xác nhận đường dẫn hoặc dòng lệnh thuộc dự án Hành Trình tại `D:\KLTN`. Ví dụ tên tiến trình là `HoTroDuLich.Web.exe`, đường dẫn ở `D:\KLTN\src\HoTroDuLich.Web\bin\...`. Sau khi xác nhận:

```powershell
Stop-Process -Id 12345
```

Lệnh này kết thúc tiến trình; chỉ dùng cho bản web phát triển đang cần dừng. Không dừng toàn bộ `dotnet` hoặc `sqlservr`, vì các tiến trình ấy có thể thuộc dự án/instance khác. Ưu tiên Ctrl+C trong terminal của watcher để dừng cả phiên theo dõi. [Microsoft: Stop-Process](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.management/stop-process).

Chạy lại mục 1. Lỗi file đang bị khóa mà không có listener có thể do bản chạy cũ chưa mở được cổng; xem các tiến trình `HoTroDuLich.Web` trong Task Manager và xác nhận đường dẫn tương tự.

**5. SQL Server LocalDB không chạy**

Dừng web bằng Ctrl+C trước khi làm các bước dưới đây. Đóng các ứng dụng đang dùng cùng instance nếu cần khởi động lại SQL. LocalDB gắn với tài khoản Windows của người sở hữu; đổi sang một tài khoản Windows khác có thể cho thấy instance/database khác. [Microsoft: LocalDB](https://learn.microsoft.com/en-us/sql/database-engine/configure-windows/sql-server-express-localdb?view=sql-server-ver17).

Kiểm tra:

```powershell
SqlLocalDB info MSSQLLocalDB
```

- `State: Running`: instance được báo là đang chạy; kiểm tra kết nối bên dưới.
- `State: Stopped`: chạy `SqlLocalDB start MSSQLLocalDB`, sau đó kiểm tra lại.
- Không tìm thấy `SqlLocalDB`: kiểm tra cài đặt SQL Server Express LocalDB và PATH; không tự tạo database rỗng để thay thế dữ liệu cũ.

Nếu instance đang lỗi, thử khởi động lại cùng instance sau khi đã dừng các ứng dụng dùng nó:

```powershell
SqlLocalDB stop MSSQLLocalDB
SqlLocalDB start MSSQLLocalDB
SqlLocalDB info MSSQLLocalDB
```

Phải đọc thông báo thực tế: `started`, `State: Running` và `Instance pipe name`. Trong lần lỗi trên máy này, mã thoát của một số lệnh native không phản ánh đầy đủ lỗi, nên không chỉ dựa vào việc PowerShell trả về dấu nhắc. Không thêm `-k` hoặc `-i` vào lệnh dừng SQL trong quy trình này. [Microsoft: SqlLocalDB utility](https://learn.microsoft.com/en-us/sql/tools/sqllocaldb-utility?view=sql-server-ver17).

Kiểm tra database hiện có bằng truy vấn chỉ đọc:

```powershell
sqlcmd -S '(localdb)\MSSQLLocalDB' -d master -E -C -b -l 10 -t 10 -Q "SET NOCOUNT ON; SELECT name,state_desc FROM sys.databases WHERE name=N'HoTroDuLich';"
```

Kết quả cần có `HoTroDuLich` và `ONLINE`. Nếu không có dòng database này, kiểm tra tài khoản Windows và chuỗi kết nối trước; chưa nên chạy web để nó tạo một database mới rỗng. Cấu hình mặc định nằm ở `src\HoTroDuLich.Web\appsettings.json`, khóa `ConnectionStrings:HoTroDuLich`; cấu hình môi trường có thể ghi đè giá trị này.

Nếu công cụ báo `Stopped` nhưng SQL vẫn còn tiến trình, đó có thể là tình trạng lệch thông tin instance như lần vừa xử lý. Chỉ nhìn tên `sqlservr.exe` chưa đủ để biết nó thuộc instance nào. Cách tự phục hồi đơn giản trên máy phát triển cá nhân: lưu công việc, đóng ứng dụng đang dùng database, **Restart Windows**, rồi chạy lại `SqlLocalDB start MSSQLLocalDB`, `info` và truy vấn kiểm tra trên. Không đóng cưỡng bức mọi tiến trình SQL.

Nếu vẫn lỗi, đọc log để lấy nguyên nhân cụ thể:

```powershell
$travelSqlLog = Join-Path $env:LOCALAPPDATA 'Microsoft\Microsoft SQL Server Local DB\Instances\MSSQLLocalDB\error.log'
Get-Content -LiteralPath $travelSqlLog -Tail 60
```

Nếu log không cập nhật hoặc không có lỗi mới, mở **Event Viewer → Windows Logs → Application**, xem sự kiện `SQLLocalDB` cùng thời điểm thất bại. Phân biệt lỗi quyền truy cập, file bị giữ, phiên bản hoặc tiến trình khởi động thất bại; không áp dụng cách sửa của một loại lỗi cho loại khác.

Giữ nguyên các tệp `.mdf`, `.ldf`, database `HoTroDuLich` và instance hiện có. **Không dùng `SqlLocalDB delete`, không xóa thư mục Instances, không chạy `DROP DATABASE` để chữa lỗi khởi động.** Các thao tác tạo lại/phục hồi database thuộc quy trình có sao lưu riêng ở `VAN_HANH.md`.

Ca đã xử lý trên máy này: engine SQL vẫn trả được `HoTroDuLich ONLINE`, nhưng LocalDB báo `Stopped` và các lần kết nối mới thất bại. Đã dừng bản web cũ, dừng engine SQL có kiểm soát và khởi động lại đúng instance; database vẫn có 25 bảng. Tên pipe thay đổi khi SQL khởi động lại, nên không sao chép tên pipe cũ vào cấu hình web.

**6. Windows chặn DLL — `0x800711C7`**

Lỗi nêu rõ `Application Control policy has blocked this file` thuộc lớp kiểm soát thực thi của Windows. Trên máy này trước đó đã xác nhận Smart App Control chặn DLL ứng dụng tự biên dịch. Nếu gặp lại, xác nhận nguyên nhân trong **Event Viewer → Applications and Services Logs → Microsoft → Windows → CodeIntegrity → Operational** tại đúng thời điểm chạy.

Xem **Windows Security → App & browser control → Smart App Control settings**. Nếu log xác nhận Smart App Control đang chặn bản build do chính bạn tạo, các lựa chọn gồm dùng bản được ký bằng chứng chỉ đáng tin cậy, hoặc cân nhắc chuyển riêng Smart App Control sang **Off** trên máy phát triển cá nhân. Việc tắt làm giảm khả năng chặn ứng dụng không đáng tin trên toàn máy; không phải ngoại lệ riêng cho dự án. Microsoft hiện không cung cấp ngoại lệ theo từng ứng dụng trong Smart App Control. [Microsoft: Smart App Control FAQ](https://support.microsoft.com/en-us/windows/security/threat-malware-protection/smart-app-control-frequently-asked-questions).

Nếu máy do tổ chức quản lý hoặc log cho thấy chính sách App Control khác, dùng quy trình cho phép ứng dụng của quản trị viên. Không sửa registry/xóa chính sách hoặc tắt toàn bộ Defender để thử chạy web.

**7. Kiểm tra sau khi sửa**

Chạy lại đúng một phiên:

```powershell
cd D:\KLTN
.\start.ps1 -Dev
```

Sau khi thấy `Now listening`, mở một terminal khác để kiểm tra:

```powershell
(Invoke-WebRequest -Uri 'http://localhost:5216/' -UseBasicParsing -TimeoutSec 10).StatusCode
```

`200` xác nhận trang chủ phản hồi HTTP. Nếu cần lưu toàn bộ lỗi của một lần chạy thường để tự đọc lại:

```powershell
cd D:\KLTN
.\start.ps1 2>&1 | Tee-Object -FilePath .\preview\khoi-dong.log
```

Đọc từ dòng lỗi đầu tiên trong `preview\khoi-dong.log`. Thực hiện từng cách sửa, chạy lại và kiểm tra kết quả trước khi chuyển sang cách tiếp theo.
