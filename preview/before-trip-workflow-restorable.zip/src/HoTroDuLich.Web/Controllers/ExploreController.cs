using HoTroDuLich.Web.Services;
using Microsoft.AspNetCore.Mvc;
namespace HoTroDuLich.Web.Controllers;
[SucAuthorize(SucAccess.TravelSearch)]
public class ExploreController(TravelService s):AppController(s){
 public async Task<IActionResult> Index(string? q,string? region,string? type,decimal? min,decimal? max){ViewBag.Regions=await S.Regions();ViewBag.Query=q;ViewBag.Region=region;ViewBag.Type=type;ViewBag.Min=min;ViewBag.Max=max;var r=await S.Explore(q,region,type,min,max);ViewBag.Places=r.Places;return View(r.Services);}
 public async Task<IActionResult> Detail(long id){ViewBag.Provider=await S.ServiceProvider(id);return View(await S.PublicService(id));}
 public async Task<IActionResult> Place(long id){var result=await HttpContext.RequestServices.GetRequiredService<ITimKiemThongTinService>().XemChiTietAsync("DiaDiem",id);ViewBag.Services=result.DichVuTaiDiem;return View(result.DiaDiem);}
}
