[CmdletBinding()]
param([switch]$Dev)

$ErrorActionPreference = 'Stop'
$travelProject = Join-Path $PSScriptRoot 'src\HoTroDuLich.Web\HoTroDuLich.Web.csproj'
if ($Dev) {
    dotnet watch --project $travelProject run --launch-profile http
} else {
    dotnet run --project $travelProject --launch-profile http
}
exit $LASTEXITCODE
