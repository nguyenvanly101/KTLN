# Luồng sử dụng xoay quanh chuyến đi

Người dùng chấp thuận triển khai đề xuất cải thiện quy trình sau đợt đối chiếu FullText. Đây là phần mở rộng sản phẩm, không phải nội dung được trích từ thiết kế gốc. Thiết kế nền vẫn giữ 25 bảng, 43 controller và 91 action chuẩn; bổ sung một quan hệ tùy chọn và thao tác sắp xếp yêu cầu vào chuyến đi.

## Quy trình hiện hành

1. Khám phá địa điểm hoặc dịch vụ. Chọn **Thêm vào lịch trình**.
2. Chọn chuyến đã có, hoặc **Tạo chuyến đi mới**. Lựa chọn được giữ qua bước tạo và cả khi biểu mẫu báo lỗi; nơi đến được điền sẵn từ thông tin công bố.
3. Tạo xong sẽ vào ngay bước xếp trải nghiệm đã chọn vào lịch. Thêm hoạt động không tự tạo yêu cầu đặt.
4. Mở chuyến đi để xem tổng quan, việc cần xử lý, lịch trình từng ngày, dự trù, dịch vụ đã gắn và hỗ trợ.
5. **Tìm trải nghiệm** từ chuyến đi giữ ngữ cảnh qua bộ lọc, thẻ kết quả và chi tiết. Thêm trải nghiệm tiếp theo đi thẳng vào chuyến đang chọn.
6. Gửi yêu cầu từ hoạt động điền sẵn ngày hoạt động và chuyến đi. Với lưu trú, ngày kết thúc mặc định theo ngày về nếu phù hợp. Người dùng kiểm tra, sửa và xem trước trước khi gửi.
7. Có thể gửi yêu cầu riêng không gắn chuyến. Yêu cầu cũ được gắn/gỡ/chuyển chuyến bằng lựa chọn rõ ràng trong trang chi tiết; không tự ghép vì trùng ngày hoặc dịch vụ.

Đồng hành là bước tùy chọn: liên kết trong chuyến đi mở tìm kiếm đã điền điểm đến và ngày đi/ngày về. Chưa tạo quan hệ thành viên chuyến đi hay tự chia sẻ lịch trình với người đã kết nối.

## Tổng quan và thao tác theo ngữ cảnh

- Hiển thị đề xuất điều kiện dịch vụ cần khách xem lại, tình huống chưa đóng, hoạt động trùng giờ, ngày dịch vụ nằm ngoài chuyến, dự trù vượt ngân sách và lịch trình chưa xác nhận. Mỗi mục có liên kết xử lý đúng đối tượng.
- Số dịch vụ xác nhận/chờ phản hồi được tính từ dữ liệu của yêu cầu đã gắn; chưa có dữ liệu thì hiển thị trạng thái trống.
- Yêu cầu bị từ chối/hủy/không tiếp tục có đường tìm lựa chọn khác cho chuyến đi. Thao tác thay đổi/hủy/kết quả vẫn ở chi tiết yêu cầu và dùng quy trình FullText.
- Ngân sách tổng hợp chi phí dự kiến của hoạt động. Giá trên yêu cầu đặt hiển thị riêng, tránh cộng hai lần. Có nhắc số hoạt động chưa có chi phí; chưa triển khai sổ chi tiêu thực tế.
- Hoạt động chỉ có nút yêu cầu đặt khi dịch vụ còn được công bố, tiếp nhận và nhà cung cấp đang hoạt động. Máy chủ kiểm tra lại khi mở/gửi yêu cầu.
- Chuyến dài trên 31 ngày hiển thị ngày bắt đầu và các ngày đã có hoạt động, tránh tạo hàng nghìn khối ngày rỗng.

## Bản đồ

Liên kết Google Maps tra theo tên/địa chỉ/khu vực đã công bố. Có địa chỉ thì mở chỉ đường; chưa có địa chỉ thì mở tìm kiếm, không dựng tọa độ hoặc ước lượng thời gian di chuyển. Dịch vụ chỉ có khu vực dùng nhãn **Tìm khu vực trên Google Maps**. Hoạt động nhập tự do chưa có địa điểm không được gán vị trí suy đoán.

URL dùng tham số đã mã hóa, đích HTTPS cố định và `api=1`; mở tab mới với `noopener noreferrer`. Không nhúng bản đồ hoặc yêu cầu quyền vị trí trong website. Cú pháp dựa trên [tài liệu Maps URLs của Google](https://developers.google.com/maps/documentation/urls/get-started).

## Bổ sung thiết kế dữ liệu

Script `src/HoTroDuLich.Web/Database/002_LienKetYeuCauChuyenDi.sql` thực hiện trong transaction, có khóa chống hai tiến trình cập nhật đồng thời và có thể chạy lại.

| Thành phần bổ sung | Thiết kế |
|---|---|
| `YeuCauDatDichVu.MaKeHoach` | `bigint NULL`; bản ghi cũ giữ `NULL` |
| Khóa ngoại | `FK_YeuCauDatDichVu_MaKeHoach` → `KeHoachChuyenDi.MaKeHoach`; `NO ACTION` |
| Index | `IX_YeuCau_KeHoach(MaKeHoach, ThoiDiemGui DESC) INCLUDE(MaDichVu, TrangThai)` |

Sau mở rộng: **25 bảng, 268 cột, 39 khóa ngoại, 117 CHECK, 18 unique index và 35 query index**. Không sửa định nghĩa các cột, enum, CHECK, index, 4 view hoặc 91 route chuẩn của FullText. `schema.sql` tiếp tục là bản nền; khởi tạo database mới chạy bản nền rồi script 002.

Service kiểm tra chủ sở hữu của cả yêu cầu và chuyến đi. FK bảo đảm chuyến đi tồn tại; quyền sở hữu được kiểm tra ở tầng nghiệp vụ. Gắn/gỡ không thay đổi ngày, điều kiện và phiên bản thương lượng của yêu cầu; có kiểm tra `RowVersion`, CSRF, vai trò và ghi nhật ký. Liên kết chuyến đi không được hiển thị trong giao diện nhà cung cấp.

## Bổ sung API và hàm

| Điểm vào | Thay đổi |
|---|---|
| `GET /Plans/Detail/{id}`, `GET /ke-hoach/{maKeHoach}` | Hiển thị `TripWorkspace` do `TripWorkspaceService.Open` tổng hợp, kiểm tra chủ chuyến trước khi truy vấn chi tiết |
| `GET /Plans/Edit?serviceId=…` hoặc `?placeId=…` | Điền nơi đến, giữ trải nghiệm để tiếp tục |
| Tạo kế hoạch qua route chuẩn/route cũ | `PlanInput` bổ sung `ContinueServiceId`, `ContinuePlaceId`; kiểm tra mục công bố trước khi lưu; trả về bước hoạt động nếu có lựa chọn |
| Tra cứu/chi tiết | Nhận `planId` tùy chọn, chỉ tải chuyến thuộc khách đang đăng nhập; giữ qua tìm kiếm và thẻ kết quả |
| Mở yêu cầu dịch vụ | `planId` tùy chọn; route giao diện nhận thêm `activityId` và kiểm tra hoạt động thuộc đúng chuyến/dịch vụ |
| Xem trước/gửi yêu cầu | `BookingInput.PlanId` tùy chọn; kiểm tra sở hữu ở cả xem trước và gửi; lưu cùng transaction tạo yêu cầu |
| `POST /Bookings/Trip` | `id`, `version`, `planId` nullable; chủ yêu cầu gắn/gỡ/chuyển vào chuyến mình sở hữu |

`TripWorkspaceService` chỉ tổng hợp và kết nối các tác vụ; phản hồi nhà cung cấp, xác nhận điều kiện, điều chỉnh/hủy, ghi nhận kết quả và xử lý tình huống vẫn chạy qua các component FullText hiện có.

## Cập nhật và kiểm chứng

Trong môi trường Development hoặc khi chạy `--initialize`, `SchemaDatabase.Initialize` áp dụng script 002 sau khởi tạo nền. Khi triển khai môi trường khác cần sao lưu rồi chạy script trước khi mở phiên bản mới. Không xóa LocalDB, database hoặc tệp MDF/LDF.

Đã sao lưu database chính trước khi thay đổi: `preview/backups/HoTroDuLich_before_trip_20261104_235610.bak`, đã `RESTORE VERIFYONLY … WITH CHECKSUM`. Mã nguồn trước đợt sửa được giữ với đường dẫn đầy đủ trong `preview/before-trip-workflow-restorable.zip`.

Các ca ghi thử chạy ở `http://localhost:5219`, database **HoTroDuLich_TripFlow_20261104**, tách với database chính. Không đổi bộ thử sang database chính.

| Bộ kiểm tra | Đạt | Phạm vi |
|---|---:|---|
| `tests/trip-workflow-results.json` | 82 | Người mới/chuyến có sẵn, giữ trải nghiệm khi lỗi, xem trước/sửa/gửi yêu cầu, gửi lặp, gắn/gỡ, xung đột phiên bản, CSRF, quyền chéo tài khoản, tình huống, ngân sách, URL bản đồ, migration chạy lại |
| `tests/trip-contract-results.json` | 1700 | Tất cả cấu trúc FullText nền và phần bổ sung được khai báo riêng |
| `tests/trip-schema-results.json` | 1479 | Lược đồ SQL vật lý gồm phần mở rộng; đối chiếu kiểu, default, FK, CHECK, index, 4 view và cấu hình SQL |
| `tests/fulltext-smoke-results.json` | 41 | Trang và quyền theo vai trò qua route chuẩn |
| `tests/navigation-redesign-results.json` | 102 | Điều hướng, tìm kiếm, hiển thị trang và vai trò |
| `tests/trip-browser-results.json` | 13 | Bố cục 375/768/812/1024/1280px, giữ ngày/chuyến đi qua xem trước và sửa lại, liên kết quay về, bản đồ và console |
| `tests/trip-main-schema-results.json` | 1479 | Đối chiếu lại lược đồ database chính sau cập nhật |

Cập nhật database chính đã hoàn tất; số bản ghi của cả 25 bảng trước/sau script 002 bằng nhau, lưu tại `preview/trip-main-rows-before.json` và `preview/trip-main-rows-after.json`. Build cuối đạt 0 lỗi, 0 cảnh báo; `start.ps1` đã khởi động được website chính. Bộ thử ghi dữ liệu chỉ chạy trên database thử nghiệm; trên bản chính chỉ kiểm tra xem trước/sửa lại, không gửi yêu cầu thử cho nhà cung cấp.

`start.ps1 -Dev` cũng đã khởi động được bản chính và trả HTTP 200 (`tests/trip-startup-results.json`). Sau kiểm tra đã dừng các tiến trình do phiên làm việc tạo; cổng 5216/5219 được trả lại để người dùng tự chạy. Đối chiếu số bản ghi và bản sao lưu được tổng hợp tại `tests/trip-upgrade-results.json`.

Chế độ kiểm chứng phần mở rộng được chọn rõ bằng `--trip-extension` ở công cụ C# và `TRAVEL_TRIP_EXTENSION=1` ở bộ kiểm tra SQL. Chế độ nền vẫn giữ số lượng gốc 267 cột/38 FK; không âm thầm nới mọi kiểm tra để bỏ qua thay đổi.

Những đề xuất để sau: bộ sưu tập lưu lựa chọn, mẫu lịch trình, chi tiêu thực tế, lịch trình dùng chung, chat, đánh giá, AI và thanh toán. Chúng chưa được thêm vào giao diện dưới dạng chức năng giả.
